# Moschee-Takvim — Etappe 6

Version **1.6.0** · Arbeitsstand abgeschlossen und getestet.

Diese Etappe setzt den Übergabe-Auftrag um: **System-Automatisierung,
Offline-Persistenz, dynamisches Wartungsfenster** sowie **Update- und
Rollback-Logik** zwischen dem Raspberry Pi (Anzeige) und der
Takvim-Manager-App (Büro-Laptop). Bestehende Daten bleiben unangetastet
(Sperrzone `data/` im Manager, `takvim-data/` + `mediathek/` auf dem Pi).

---

## Modul 1 · Permanente Persistenz & Offline-First (Pi)

- **Sofort-Persistenz:** Alle eingehenden Daten werden weiterhin atomar auf
  die SD-Karte geschrieben (`atomic_write`: Temp-Datei → `fsync` →
  `os.replace`). Dadurch kann ein plötzlicher Stromausfall keine halb
  geschriebene Datei hinterlassen — es liegt immer entweder die alte oder die
  vollständige neue Datei vor. Es verbleiben keine Nutzdaten nur im RAM.
- **Offline-First-Boot:** Beim Systemstart lädt der Pi-Dienst die lokal
  gespeicherte Konfiguration und Gebetszeiten aus `takvim-data/` — ganz ohne
  Netzwerk. Der `systemd`-Dienst startet automatisch beim Booten
  (`Restart=always`); der Kiosk-Browser startet per Desktop-Autostart.

## Modul 2 · Dynamisches Wartungsfenster (Pi)

Neuer Dienst **`wartung.py`** (läuft im grafischen Login per Autostart, damit
er Zugriff auf Bildschirm/HDMI-CEC und die Chromium-Instanz hat).

- **Trigger-Logik:** Berechnet täglich dynamisch die Startzeit aus der lokalen
  Gebetszeiten-Tabelle: **Start = Isha-Gebetszeit + 60 Minuten**.
- **Sequentieller Ablauf (5 Schritte):**

  ```
  [Isha + 60 Min] → 1. TV-Standby (CEC) → 2. Cache löschen
                  → 3. Staged Update → 4. Browser-Neustart
                  → 5. TV-Aufwachen (Fajr − 30 Min)
  ```

  1. **TV-Standby (HDMI-CEC):** `cec-client` schaltet den Fernseher in den
     stromsparenden Standby.
  2. **Cache-Säuberung:** Der Chromium-Cache im Benutzerprofil
     (`Cache`, `Code Cache`, `GPUCache`, `~/.cache/chromium` …) wird radikal
     geleert — gegen Speicherlecks und Ruckler im Dauerbetrieb.
  3. **Staged Update:** Liegt in `/updates/` ein Paket (loser Ordner **oder**
     `.zip`), wird die aktuelle `takvim-app/` als Backup nach
     `backup_previous/` gesichert (altes Backup wird ersetzt) und das Update
     atomar nach `takvim-app/` eingespielt; `/updates/` wird geleert.
  4. **Browser-Neustart:** Chromium wird beendet und im Kiosk-Vollbild mit der
     aktualisierten App neu gestartet.
  5. **Aufwach-Timer (HDMI-CEC):** Aufwachzeit = **Fajr-Gebet − 30 Minuten**
     (Fajr-Gebetszeit = CSV-Spalte „Sabah", identisch zur Athan-Zeit der
     TV-App). Zu diesem Zeitpunkt schaltet `cec-client` den TV wieder ein.

  Die Schritte 1–4 laufen am Fensterstart sofort hintereinander; danach bleibt
  der TV bis zur Aufwachzeit im Standby. Jeder Schritt ist fehlerisoliert —
  fehlt z. B. `cec-client`, wird dies protokolliert und der Ablauf fortgesetzt.
- **Protokoll:** `takvim-data/wartung.log` (zusätzlich im Journal).
- **Robustheit:** Der zuletzt berechnete Zustand wird persistiert
  (`wartung_state.json`), sodass das Fenster pro Kalendertag genau einmal
  ausgelöst wird.

## Modul 3 · Update-Installation & Notfall-Rollback

### 3.1 In-App-Update des Managers (Laptop)

- **Quelle:** Unter ⚙️ **System → Software & Updates** wird eine Manifest-URL
  hinterlegt (JSON: `{ "version", "url", "notes" }`).
- **Prüfen / Herunterladen:** `check_update()` vergleicht die Versionen
  (numerisch, d. h. `1.10.0 > 1.9.0`); `download_update()` lädt das ZIP atomar
  nach `temp_update/`.
- **Installieren:** „Jetzt installieren" prüft das Archiv, startet
  **`installer.bat`** abgekoppelt und beendet die App. `installer.bat`:
  1. wartet auf das Ende der App,
  2. entpackt das ZIP,
  3. überschreibt `app/` (und übrige Programmdateien) — die **Sperrzone
     `data/` bleibt unberührt** (kein Löschen dank `robocopy /E`),
  4. startet die App automatisch neu.

  > **Hinweis zur Umsetzung:** Die Übergabe nannte ein `installer.js`. Da die
  > App eine Python-/pywebview-Anwendung ohne Node.js-Laufzeit ist, wurde der
  > Tausch als **Windows-natives `installer.bat`** umgesetzt (keine zusätzliche
  > Abhängigkeit, nutzt nur PowerShell/robocopy). Funktion und Ablauf sind
  > identisch zur Vorgabe.

### 3.2 Express-Rollback (Fail-Safe)

- **Vorbereitung:** Vor jeder nächtlichen TV-Update-Installation sichert der Pi
  die laufende Version nach `backup_previous/` (Modul 2.2, Schritt 3).
- **Notfall-Button:** Im Manager unter ⚙️ **System → 🛟 Notfall** wählbar:
  „Letzte stabile Version wiederherstellen". Der Status (Backup vorhanden?
  Update wartend?) wird live angezeigt.
- **Verarbeitung:** Der Klick sendet ein hochpriorisiertes Signal an den Pi
  (`POST /api/rollback`). Der Pi stoppt den aktuellen Zustand, kopiert
  `backup_previous/ → takvim-app/` und beauftragt über eine Steuerdatei
  (`control.json`) den Wartungs-Dienst, der den TV nötigenfalls einschaltet und
  den Browser **in unter 5 Sekunden** neu startet — die alte, stabile Anzeige
  läuft wieder.

---

## Neue / geänderte Dateien

| Datei | Status | Inhalt |
|-------|--------|--------|
| `raspberry-pi/wartung.py` | **neu** | Wartungsfenster-Daemon + Rollback-Ausführung |
| `raspberry-pi/pi_server.py` | geändert | `POST /api/update`, `POST /api/rollback`, `GET /api/update`, Steuerdatei, Status-Felder |
| `raspberry-pi/install_pi.sh` | geändert | kopiert `wartung.py`, richtet Autostart ein, installiert `cec-utils` |
| `Moschee-Takvim-Manager/Takvim-Manager.py` | geändert | `check_/download_/install_update`, `rollback_pi`, `push_tv_update`, `get_pi_update_status` |
| `Moschee-Takvim-Manager/installer.bat` | **neu** | Self-Update-Tausch unter Windows |
| `Moschee-Takvim-Manager/app/index.html` | geändert | Update-Box + Notfall-Karte im System-Reiter |
| `Moschee-Takvim-Manager/app/main.js` | geändert | Handler für Update/Installation/Rollback |
| `Moschee-Takvim-Manager/app/style.css` | geändert | Stil für Update-Box und Notfall-Karte |

## Neue Schnittstellen (Pi)

| Methode/Endpunkt | Zweck |
|------------------|-------|
| `POST /api/update?name=….zip` | TV-App-Update-Paket nach `/updates/` ablegen |
| `POST /api/rollback` | Express-Rollback (Backup → App + Browser-Neustart) |
| `GET  /api/update` | Backup-/Update-Status (`backup_present`, `update_pending`) |
| `/api/status` (erweitert) | zusätzlich `backup_present`, `update_pending` |

---

## Getestet

- **pi_server** (HTTP-Integration): `GET /api/status` (neue Felder),
  `POST /api/update` (ZIP angenommen, Nicht-ZIP → HTTP 422),
  `POST /api/rollback` (App aus Backup wiederhergestellt, `control.json`
  geschrieben), `GET /api/update`.
- **pi_server** (Einheit): `express_rollback`, `write_control` (seq-Inkrement),
  `backup_present`/`update_pending`, `safe_update_name` (Pfad-Ausbruch
  abgewehrt).
- **wartung.py** (Einheit): `isha_start_for` (Isha + 60 Min),
  `fajr_wake_after` (Folgetag Fajr − 30 Min), `staged_update` (Backup +
  atomarer Tausch + `/updates/`-Leerung), `handle_control_file`
  (Express-Rollback, einmalige Ausführung dank seq-Deduplizierung).
- **Takvim-Manager** (Logik): `_version_gt` inkl. `1.10 > 1.9`,
  `check_update`/`install_update`/`rollback_pi`-Fehlerpfade.
- Alle Dateien: Python `ast.parse` & Node `--check` fehlerfrei.

## Hinweise zur Inbetriebnahme

- Auf dem Pi nach dem Update einmal `bash install_pi.sh` ausführen. Kiosk und
  Wartungs-Dienst starten beim nächsten Desktop-Login (Neustart empfohlen).
- HDMI-CEC muss am Fernseher aktiviert sein (je nach Hersteller „Anynet+",
  „Bravia Sync", „Simplink", „Viera Link" …), damit TV ein/aus funktioniert.
- Der Express-Rollback funktioniert erst, wenn mindestens einmal ein Update
  installiert (und damit ein Backup angelegt) wurde — bis dahin meldet der
  Manager „Kein Backup vorhanden" und der Notfall-Button bleibt inaktiv.
