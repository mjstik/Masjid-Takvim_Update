# Moschee-Takvim — v1.9

Version **1.9.0** · baut direkt auf dem stabilen Stand v1.8.0 auf.

Diese Etappe setzt drei gezielte Anpassungen am Design-Studio um:
**exakte 1:1-Positionskalibrierung** zwischen Editor und TV, die **Uhrzeit als
vollwertiges Textelement** und ein **element-basiertes Bearbeitungskonzept**.
Bestehende Daten und Konfigurationen bleiben unberührt; ältere Presets und
`override_layout`-Strukturen funktionieren ohne Eingriff weiter (kein
Schema-Bruch, nur additive Erweiterungen).

---

## 1 · Exakte Positionskalibrierung (Editor → TV)

Zwei Rest-Ursachen aus v1.8 wurden gefunden und behoben. Beide führten dazu,
dass ein im Editor angeordnetes Element auf dem TV leicht versetzt bzw. anders
groß erschien.

### Positions-Offsets der Sub-Elemente
Kernursache: Die per Stil-Editor gespeicherten Innen-Versätze (`pos_*`, z. B.
Verschieben des Symbols oder der Zeit innerhalb der Kachel) wurden auf dem TV
als `translate()` angewandt, in der **Editor-Vorschau aber komplett ignoriert**.

- `applyTileStylesTo` (Manager) wendet die `pos_*`-Offsets jetzt mit **demselben
  `tvScale`-Faktor** (`Bühnenbreite ÷ 1920`) an wie die TV-Anzeige. Symbol,
  Name-DE, Name-AR und Uhrzeit sitzen damit im Editor exakt dort, wo sie auf
  dem TV landen.

### Default-Schriftgrößen im Frei-Modus
Kernursache: Der Editor skalierte die unveränderten Standard-Schriftgrößen mit
abweichenden Steigungen (`.ds-ptime` = `2.71cqw`) gegenüber den `cqi`-Werten
der TV (`body.free-layout .ptime` = `clamp(20px,15cqi,90px)`). Maßstabstreue
galt damit nur, sobald explizit eine Pixel-Größe gesetzt war.

- Die Editor-Bühne (`.ds-stage.free`) nutzt jetzt **exakt dieselben
  `clamp(...cqi...)`-Werte** wie `body.free-layout` der TV — für Zeit, Name-DE,
  Name-AR, Uhr, Beginn/Aufgang und die Hadith-Box. Da jede Kachel in beiden
  Welten ihr eigener `container-type:inline-size` ist, lösen die `cqi`-Einheiten
  gegen dieselbe relative Basis auf.
- Inline-Stile aus dem Stil-Editor überschreiben diese Defaults weiterhin;
  gesetzte px-Werte (× `tvScale`) waren bereits 1:1 und bleiben es.

**Ergebnis:** reproduzierbare, maßstabsgetreue 1:1-Darstellung ohne Versatz —
unabhängig von 1280, 1920 oder 4K (der bestehende Resize-Listener rechnet das
Frei-Layout bei Auflösungswechsel neu).

---

## 2 · Uhrzeit als vollwertiges Textelement

Bisher brach der Kachel-Editor beim Anklicken der Uhr ab — sie war zwar
verschiebbar, aber nicht gestaltbar.

- `openTileEditor` hat einen eigenen **Uhr-Zweig**. Beim Doppelklick auf die
  Uhr lassen sich **Schriftgröße, Farbe und Position** bearbeiten; die
  Ausrichtung erfolgt — wie bei allen Elementen — über Drag mit Snap-Linien.
- Die TV-Anzeige (`applyTileStyle` in `kiosk-logic.js`) stylt die Uhr
  (`.time-big`) jetzt analog. Die **Sekundenanzeige** (`.secs`) skaliert
  proportional (~0,46 ≙ CSS-Verhältnis 4vw/8,6vw) mit der eingestellten Größe.
- Die Uhr wird damit wie ein normales Textelement behandelt — kein Sonderfall
  mehr. Persistenz: `timeFontSize`/`timeColor`/`pos_*` für den `clock`-Schlüssel
  laufen unverändert durch `_clean_override_obj` und den Pi-Top-Level-Merge
  (keine Server-Änderung nötig).

---

## 3 · Element-basiertes Bearbeiten (kontextbezogen statt global)

Das Milchglas-Overlay bleibt erhalten, arbeitet aber jetzt auf **Element-Ebene**
statt eine globale Parameterliste der ganzen Kachel zu zeigen.

- **Hover** über ein Element: Hervorhebung wie bisher (unverändert).
- **Einfacher Klick** auf ein Element im Canvas → nur **dieses** Element wird
  aktiv ausgewählt (`teSelectSub`); links erscheinen ausschließlich dessen
  Eigenschaften. Über „alle anzeigen" (`teShowAll`) geht es zurück zur
  Gesamtansicht.
- **Doppelklick** öffnet den Editor wie bisher.
- **Jedes Sub-Element** ist einzeln anklickbar: Symbol, Name (DE), Name (AR),
  Uhrzeit, Beginn/Aufgang — bei der Infobox Arabisch, Übersetzung, Quelle.
- Klick und Verschieben werden über eine **3-px-Schwelle** sauber getrennt
  (kein versehentliches Mini-Drag beim Auswählen). Das Verschieben der Elemente
  bleibt vollständig erhalten.
- Die Regler-Gruppen tragen `data-sub` (Element-Kennung); der reine Kachel-/
  Box-Hintergrund (`bgOpacity`) ist als „ganze Kachel/Box" gekennzeichnet und
  bleibt in der Gesamtansicht sichtbar.

**Ergebnis:** ein moderner visueller Editor mit direkter Elementbearbeitung
statt globaler Pegel-Liste — bei unveränderter Hover- und Verschiebe-Logik.

---

## Geänderte Dateien

- `Moschee-Takvim-Manager/app/main.js` — `applyTileStylesTo` (Offsets + Uhr),
  `openTileEditor` (Uhr-Zweig, `data-sub`-Gruppen), `teSelectSub`/`teShowAll`,
  Klick-vs-Drag-Erkennung, `teApplyAll` (Uhr-Sekunden).
- `Moschee-Takvim-Manager/app/style.css` — `.ds-stage.free`-Defaults 1:1 zur TV,
  `.te-selected`/`.te-subhint`/`.te-showall`/`.te-clock-*`.
- `raspberry-pi/takvim-app/kiosk-logic.js` — `applyTileStyle` Uhr-Behandlung
  (`.time-big` + proportionale `.secs`).
- Versionsangaben → **1.9.0** (Manager, Pi-Server, Splash/Footer/System,
  `config.json`).
