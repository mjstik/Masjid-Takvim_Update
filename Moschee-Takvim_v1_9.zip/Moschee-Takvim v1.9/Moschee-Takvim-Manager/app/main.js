/* ============================================================================
   TAKVIM-MANAGER v1.1 — Oberflächen-Logik (Etappe 2)
   Kommunikation mit Python über window.pywebview.api.*
   ========================================================================== */
"use strict";

const $ = s => document.querySelector(s);

let CFG        = null;
let LIB        = null;          // hadith_bibliothek.json (gecacht)
let PI_ONLINE  = false;
let PI_BASE    = null;
let pingTimer  = null;
let csvPendingText = null;      // geladener CSV-Inhalt vor dem Senden

/* ── Brücke abwarten ─────────────────────────────────────────────────────── */
if (window.pywebview && window.pywebview.api) {
  init();
} else {
  window.addEventListener("pywebviewready", init);
}

/* ════════════════════════ MASKE 1 · SPLASH ════════════════════════ */
async function init() {
  const t0 = Date.now();
  const MIN_SPLASH = 1600;

  try {
    const info = await pywebview.api.get_info();
    $("#splashVersion").textContent = "v" + info.version;
    $("#footVersion").textContent   = "v" + info.version;
    $("#sysVersion").textContent    = "v" + info.version;
    $("#sysBase").textContent       = info.base;

    CFG = await pywebview.api.get_config();
    const res = await pywebview.api.startup();

    splashCheck("chkUpdate",
      !res.update.available,
      res.update.available
        ? "Update verfügbar!"
        : "Software ist aktuell (v" + res.update.current + ")");

    applyPiResult(res.pi);
    splashCheck("chkPi",
      res.pi.online,
      res.pi.online
        ? "Raspberry Pi verbunden (" + res.pi.ip + ", " + res.pi.latency_ms + " ms)"
        : (res.pi.configured === false
            ? "Pi noch nicht konfiguriert → ⚙️ System"
            : "Pi nicht erreichbar: " + (res.pi.error || "")));
  } catch (e) {
    splashCheck("chkUpdate", false, "Prüfung fehlgeschlagen");
    splashCheck("chkPi",    false, "Brücke zu Python gestört");
  }

  const rest = Math.max(0, MIN_SPLASH - (Date.now() - t0));
  setTimeout(enterMain, rest + 450);
}

function splashCheck(id, ok, text) {
  const li = $("#" + id);
  li.querySelector(".chk-ico").className = "chk-ico " + (ok ? "ok" : "err");
  li.querySelector(".chk-txt").textContent = text;
}

/* ════════════════════════ MASKE 2 · MAIN ════════════════════════ */
function enterMain() {
  $("#main").classList.remove("hidden");
  $("#splash").classList.add("fade");
  setTimeout(() => $("#splash").remove(), 650);

  initNav();
  initSystemPanel();
  initInfoPanel();
  initTerminePanel();
  initPrayerPanel();
  initDashboard();
  initDesignStudio();
  initStages();

  $("#btnPreviewReload").addEventListener("click", () => { reloadPreview(); loadDashIframe(); });

  refreshDashboard();
  pingTimer = setInterval(pingLoop, 10000);
}

/* ── Navigation ──────────────────────────────────────────────────────────── */
function initNav() {
  document.querySelectorAll(".nav-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      $("#panel-" + btn.dataset.panel).classList.add("active");
      if (btn.dataset.panel === "dashboard")   refreshDashboard();
      if (btn.dataset.panel === "infotexte")   loadLibrary();
      if (btn.dataset.panel === "termine")     loadEvents();
      if (btn.dataset.panel === "gebetszeiten") refreshPrayerStatus();
      if (btn.dataset.panel === "hintergruende") loadDesignStudio();
    });
  });
}

/* ── Verbindungs-Status ──────────────────────────────────────────────────── */
function applyPiResult(pi) {
  const wasOnline = PI_ONLINE;
  PI_ONLINE = !!pi.online;

  const box = $("#piStatus");
  const txt = box.querySelector(".pi-status-text");

  if (pi.configured === false) {
    box.className = "pi-status offline";
    txt.innerHTML = "TV nicht konfiguriert<small>IP unter ⚙️ System eintragen</small>";
  } else if (PI_ONLINE) {
    box.className = "pi-status online";
    txt.innerHTML = "TV Online<small>" + esc(pi.ip) + ":" + pi.port + "</small>";
  } else {
    box.className = "pi-status offline";
    txt.innerHTML = "TV Offline<small>" + esc(pi.ip || "") + "</small>";
  }

  $("#tvLed").className = "tv-led" + (PI_ONLINE ? " on" : "");
  if (PI_ONLINE) {
    $("#tvOverlay").classList.add("hidden");
    if (!wasOnline) { reloadPreview(); loadDashIframe(); }
  } else {
    $("#tvOverlay").classList.remove("hidden");
    $("#tvOverlayText").textContent = pi.configured === false
      ? "Pi-Adresse fehlt — unter ⚙️ System eintragen"
      : "Keine Verbindung zum TV";
  }
}

async function pingLoop() {
  try { applyPiResult(await pywebview.api.ping_pi()); } catch (e) {}
}

/* ── Dashboard ───────────────────────────────────────────────────────────── */
function initDashboard() {
  // Schnellzugriff: in Bibliothek speichern
  $("#btnDashSaveLib").addEventListener("click", async () => {
    const text = $("#dashQuickText").value.trim();
    if (!text) { setResult("#dashInfoResult", "err", "Bitte einen Text eingeben."); return; }
    setResult("#dashInfoResult", "", "Speichern…");
    try {
      const r = await pywebview.api.save_text({
        titel: text.substring(0, 60),
        text: text,
        kategorie: $("#dashQuickKat").value
      });
      if (r.ok) {
        LIB = r.library;
        setResult("#dashInfoResult", "ok", "✓ In Bibliothek gespeichert.");
        $("#dashQuickText").value = "";
      } else {
        setResult("#dashInfoResult", "err", r.error || "Fehler");
      }
    } catch (e) {
      setResult("#dashInfoResult", "err", "Fehler: " + e.message);
    }
  });

  // Schnellzugriff: direkt senden
  $("#btnDashSendLive").addEventListener("click", async () => {
    const text = $("#dashQuickText").value.trim();
    if (!text) { setResult("#dashInfoResult", "err", "Bitte einen Text eingeben."); return; }
    if (!PI_ONLINE) { setResult("#dashInfoResult", "err", "Pi nicht verbunden."); return; }
    setResult("#dashInfoResult", "", "Sende…");
    // Text temporär senden ohne in Bibliothek zu speichern
    try {
      const r = await pywebview.api.send_config_to_pi({
        infotext: { titel: "", text: text, arabisch: "", kategorie: $("#dashQuickKat").value },
        pool: { aktiv: false, intervall: "30", eintraege: [] }
      });
      if (r.ok) {
        setResult("#dashInfoResult", "ok", "✓ Text ist jetzt auf dem TV aktiv.");
        $("#dashQuickText").value = "";
      } else {
        setResult("#dashInfoResult", "err", r.error || "Fehler beim Senden");
      }
    } catch (e) {
      setResult("#dashInfoResult", "err", "Fehler: " + e.message);
    }
  });

  // Zur Infotext-Bibliothek springen
  $("#btnDashGoInfo").addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    $(".nav-btn[data-panel='infotexte']").classList.add("active");
    $("#panel-infotexte").classList.add("active");
    loadLibrary();
  });
}

async function refreshDashboard() {
  try { applyPiResult(await pywebview.api.ping_pi()); } catch (e) {}
  await refreshPrayerCard();
  updateDashPoolStatus();
  await pullPreviewState();
}

async function reloadPreview() {
  // Studio-Bühne aktualisieren (Design/Layout/Hintergrund)
  try { await pullPreviewState(); } catch (e) {}
  // Dashboard-iframe wird NICHT jedes Mal neu geladen — die eingebettete
  // TV-Seite pollt selbst alle 5 s und zeigt Änderungen automatisch an.
  // Nur bei Erstverbindung oder manuell (⟳) wird der iframe geladen.
}

async function refreshPrayerCard() {
  const ico  = $("#prayerStateIco"),
        main = $("#prayerStateMain"),
        sub  = $("#prayerStateSub");

  if (!PI_ONLINE) {
    ico.textContent  = "📡";
    main.textContent = "Status unbekannt";
    sub.textContent  = "Der Raspberry Pi ist nicht erreichbar.";
    return;
  }
  try {
    const st = await pywebview.api.pi_status();
    if (!st.ok) throw new Error(st.error || "Statusabfrage fehlgeschlagen");
    applyPrayerStatus(ico, main, sub, st);
  } catch (e) {
    ico.textContent  = "⚠️";
    main.textContent = "Status konnte nicht gelesen werden";
    sub.textContent  = String(e.message || e);
  }
}

function applyPrayerStatus(ico, main, sub, st) {
  const p = st.prayer || {};
  if (!p.csv_present) {
    ico.textContent  = "🕓";
    main.textContent = "Noch keine Jahres-Tabelle auf dem Pi";
    sub.textContent  = "Unter 🕌 Gebetszeiten die CSV importieren und übertragen.";
  } else if (p.today_ok) {
    ico.textContent  = "✅";
    main.textContent = "Gebetszeiten für heute geladen";
    sub.textContent  = "Lokale Tabelle mit " + p.rows + " Tagen · zuletzt aktualisiert: "
                       + fmtTime(st.config_updated_at);
  } else {
    ico.textContent  = "⚠️";
    main.textContent = "Tabelle vorhanden, aber kein Eintrag für heute!";
    sub.textContent  = "Bitte aktualisierte Jahres-Tabelle übertragen (" + p.rows + " Tage vorhanden).";
  }
}

function updateDashPoolStatus() {
  const el = $("#dashPoolStatus");
  if (!LIB) { el.textContent = ""; return; }
  const pool = LIB.pool || {};
  if (pool.aktiv) {
    const n = (pool.auswahl || []).length;
    el.innerHTML = "<span class='pool-badge active'>Pool aktiv</span> "
                 + n + " Text" + (n !== 1 ? "e" : "") + " im Pool";
  } else {
    const sel = pool.auswahl || [];
    const lib_texte = LIB.texte || [];
    const erster = sel.length ? lib_texte.find(t => t.id === sel[0]) : null;
    if (erster) {
      el.innerHTML = "<span class='pool-badge inactive'>Einzeltext</span> "
                   + esc(erster.titel || erster.text.substring(0, 60));
    } else {
      el.innerHTML = "<span class='pool-badge inactive'>Pool inaktiv</span> Kein Text ausgewählt";
    }
  }
}

/* ════════════ PANEL: GEBETSZEITEN ════════════ */
function initPrayerPanel() {
  // Status-Button
  $("#btnPrayerRefresh").addEventListener("click", refreshPrayerStatus);

  // URL-Import
  $("#btnImportUrl").addEventListener("click", async () => {
    const url = $("#inpCsvUrl").value.trim();
    if (!url) { setResult("#csvUrlResult", "err", "Bitte eine URL eingeben."); return; }
    const btn = $("#btnImportUrl");
    btn.disabled = true;
    setResult("#csvUrlResult", "", "Lade CSV…");
    try {
      const r = await pywebview.api.import_csv_from_url(url);
      if (r.ok) {
        setResult("#csvUrlResult", "ok",
          "✓ Erfolgreich übertragen — " + r.rows + " Tage (" + r.first + " bis " + r.last + ")");
        refreshPrayerStatus();
        // auch Dashboard-Karte aktualisieren
        await refreshPrayerCard();
      } else {
        setResult("#csvUrlResult", "err", "✕ " + (r.error || "Fehler"));
      }
    } catch (e) {
      setResult("#csvUrlResult", "err", "Fehler: " + (e.message || e));
    }
    btn.disabled = false;
  });

  // Datei-Drop-Area
  const dropArea = $("#csvDropArea");
  const fileInput = $("#csvFileInput");

  dropArea.addEventListener("click", () => fileInput.click());
  dropArea.addEventListener("dragover", e => { e.preventDefault(); dropArea.classList.add("drag-over"); });
  dropArea.addEventListener("dragleave", () => dropArea.classList.remove("drag-over"));
  dropArea.addEventListener("drop", e => {
    e.preventDefault();
    dropArea.classList.remove("drag-over");
    const file = e.dataTransfer.files[0];
    if (file) handleCsvFile(file);
  });
  fileInput.addEventListener("change", () => {
    if (fileInput.files[0]) handleCsvFile(fileInput.files[0]);
    fileInput.value = "";
  });

  $("#btnCsvCancel").addEventListener("click", resetCsvFile);
  $("#btnCsvSend").addEventListener("click", sendCsvFile);
}

async function refreshPrayerStatus() {
  const ico  = $("#prayerStateIco2"),
        main = $("#prayerStateMain2"),
        sub  = $("#prayerStateSub2");
  ico.textContent = "⟳"; main.textContent = "Wird geprüft…"; sub.textContent = "";

  if (!PI_ONLINE) {
    ico.textContent = "📡"; main.textContent = "Pi nicht verbunden";
    sub.textContent = "Verbindung unter ⚙️ System prüfen."; return;
  }
  try {
    const st = await pywebview.api.pi_status();
    if (!st.ok) throw new Error(st.error || "Statusabfrage fehlgeschlagen");
    applyPrayerStatus(ico, main, sub, st);
  } catch (e) {
    ico.textContent = "⚠️"; main.textContent = "Fehler beim Lesen";
    sub.textContent = String(e.message || e);
  }
}

function handleCsvFile(file) {
  setResult("#csvFileResult", "", "");
  const reader = new FileReader();
  reader.onload = async e => {
    const text = e.target.result;
    // Vorschau lokal prüfen
    try {
      const info = await pywebview.api.preview_csv(text);
      const box = $("#csvPreviewBox");
      if (info.ok) {
        box.innerHTML =
          "<div class='csv-pre-ok'>📄 <b>" + esc(file.name) + "</b> · " +
          info.rows + " Tage gefunden (" + esc(info.first) + " bis " + esc(info.last) + ")" +
          "</div>";
        box.classList.remove("hidden");
        csvPendingText = text;
        $("#csvFileBtnRow").style.display = "flex";
        $("#csvDropSub").textContent = file.name;
      } else {
        box.innerHTML = "<div class='csv-pre-err'>⚠️ " + esc(info.error) + "</div>";
        box.classList.remove("hidden");
        csvPendingText = null;
        $("#csvFileBtnRow").style.display = "none";
      }
    } catch (ex) {
      setResult("#csvFileResult", "err", "Vorschau-Fehler: " + (ex.message || ex));
    }
  };
  reader.readAsText(file, "utf-8");
}

async function sendCsvFile() {
  if (!csvPendingText) return;
  if (!PI_ONLINE) { setResult("#csvFileResult", "err", "Pi nicht verbunden."); return; }
  const btn = $("#btnCsvSend");
  btn.disabled = true;
  setResult("#csvFileResult", "", "Übertrage…");
  try {
    const r = await pywebview.api.import_csv_from_text(csvPendingText);
    if (r.ok) {
      setResult("#csvFileResult", "ok",
        "✓ Erfolgreich übertragen — " + r.rows + " Tage (" + r.first + " bis " + r.last + ")");
      resetCsvFile();
      refreshPrayerStatus();
      await refreshPrayerCard();
    } else {
      setResult("#csvFileResult", "err", "✕ " + (r.error || "Fehler"));
    }
  } catch (e) {
    setResult("#csvFileResult", "err", "Fehler: " + (e.message || e));
  }
  btn.disabled = false;
}

function resetCsvFile() {
  csvPendingText = null;
  $("#csvPreviewBox").classList.add("hidden");
  $("#csvFileBtnRow").style.display = "none";
  $("#csvDropSub").textContent = "Unterstützt: .csv, .txt";
  setResult("#csvFileResult", "", "");
}

/* ════════════ PANEL: INFOTEXTE ════════════ */
function initInfoPanel() {
  // Formular-Buttons
  $("#btnEditClear").addEventListener("click", clearEditForm);
  $("#btnSaveText").addEventListener("click", saveText);
  $("#btnSendDirect").addEventListener("click", sendDirect);
  initEmojiBar();

  // Pool-Toggle
  $("#btnPoolToggle").addEventListener("click", togglePool);

  // Intervall-Radios (Auto-Speichern bei Änderung)
  document.querySelectorAll("input[name='intervall']").forEach(r => {
    r.addEventListener("change", savePoolSettings);
  });

  // Live-Senden
  $("#btnSendLive").addEventListener("click", sendLive);

  // Bibliothek-Filter
  $("#libFilter").addEventListener("change", () => renderLibrary());
}

async function loadLibrary() {
  try {
    LIB = await pywebview.api.get_library();
    renderLibrary();
    applyPoolState(LIB.pool || {});
    updateDashPoolStatus();
  } catch (e) {
    console.error("loadLibrary:", e);
  }
}


/* ── Schnelleinfüge-Leiste (Symbole + Fertigtexte) ──────────────────────── */
const EMOJI_SNIPPETS = {
  de: [
    "Der Prophet Muhammed ﷺ sagte:",
    "Allah ﷻ sagt im Koran:",
    "Im Namen Allahs, des Allerbarmers ﷽",
    "Sahih al-Bukhari",
    "Sahih Muslim",
    "Sunan Abu Dawud",
  ],
  al: [
    "Profeti Muhammed ﷺ ka thënë:",
    "Allahu ﷻ thotë në Kuran:",
    "Me emrin e Allahut, Mëshiruesit ﷽",
    "Sahih al-Bukhari",
    "Sahih Muslim",
    "Sunan Ebu Davud",
  ],
  en: [
    "The Prophet Muhammad ﷺ said:",
    "Allah ﷻ says in the Quran:",
    "In the name of Allah, the Most Merciful ﷽",
    "Sahih al-Bukhari",
    "Sahih Muslim",
    "Sunan Abu Dawud",
  ],
  ar: [
    "قال النبي محمد ﷺ:",
    "قال الله ﷻ في القرآن:",
    "بسم الله الرحمن الرحيم ﷽",
    "صحيح البخاري",
    "صحيح مسلم",
    "سنن أبي داود",
  ]
};

let lastFocusedInput = null;  // merkt sich das zuletzt fokussierte Eingabefeld

function initEmojiBar() {
  /* Fokus-Tracking: welches Textfeld war zuletzt aktiv? */
  document.querySelectorAll("#cardEditText input[type=text], #cardEditText textarea").forEach(el => {
    el.addEventListener("focus", () => { lastFocusedInput = el; });
  });

  /* Symbole: Klick fügt ins zuletzt fokussierte Feld ein */
  document.querySelectorAll("#emojiSymbols .eb-btn").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      insertAtCursor(btn.dataset.insert);
    });
  });

  /* Fertigtexte: sprachabhängig rendern */
  renderSnippets();
}

function renderSnippets() {
  const lang = MANAGER_LANG || "de";
  const list = EMOJI_SNIPPETS[lang] || EMOJI_SNIPPETS.de;
  const wrap = document.getElementById("emojiSnippets");
  if (!wrap) return;
  wrap.innerHTML = list.map(s =>
    '<button class="eb-snip" data-insert="' + s.replace(/"/g, "&quot;") + '">' + s.substring(0, 38) + (s.length > 38 ? "…" : "") + '</button>'
  ).join("");
  wrap.querySelectorAll(".eb-snip").forEach(btn => {
    btn.addEventListener("click", e => {
      e.preventDefault();
      insertAtCursor(btn.dataset.insert);
    });
  });
}

function insertAtCursor(text) {
  const el = lastFocusedInput || document.getElementById("inpText");
  if (!el) return;
  el.focus();
  const start = el.selectionStart ?? el.value.length;
  const end   = el.selectionEnd   ?? start;
  el.value = el.value.substring(0, start) + text + el.value.substring(end);
  const pos = start + text.length;
  el.setSelectionRange(pos, pos);
}

function renderLibrary() {
  const filter = $("#libFilter").value;
  const texte  = (LIB && LIB.texte) ? LIB.texte : [];
  const gefiltert = filter ? texte.filter(t => t.kategorie === filter) : texte;

  const list = $("#libList");
  $("#libCount").textContent = gefiltert.length + " Einträge";

  if (!gefiltert.length) {
    list.innerHTML = '<div class="lib-empty">' +
      (filter ? "Keine Einträge in dieser Kategorie." : "Noch keine Einträge in der Bibliothek.") +
      "</div>";
    return;
  }

  const poolAktiv  = (LIB && LIB.pool && LIB.pool.aktiv);
  const poolAuswahl = (LIB && LIB.pool && LIB.pool.auswahl) ? LIB.pool.auswahl : [];

  list.innerHTML = gefiltert.map(t => {
    const checked   = poolAuswahl.includes(t.id) ? "checked" : "";
    const katClass  = "kat-" + (t.kategorie || "").toLowerCase().replace(/[^a-z]/g, "-").replace(/-+/g, "-");
    const vorschau  = (t.arabisch ? "«" + t.arabisch.substring(0, 50) + "» " : "")
                    + (t.text || "").substring(0, 100)
                    + ((t.text || "").length > 100 ? "…" : "")
                    + (t.quelle ? " [" + t.quelle.substring(0, 40) + "]" : "");

    return `<div class="lib-item" data-id="${esc(t.id)}">
      <label class="lib-check-wrap" title="${poolAktiv ? 'In Pool aufnehmen' : 'Als Einzeltext auswählen'}">
        <input type="checkbox" class="lib-checkbox" data-id="${esc(t.id)}" ${checked}>
      </label>
      <div class="lib-item-body" data-id="${esc(t.id)}">
        <div class="lib-item-head">
          <span class="lib-kat ${katClass}">${esc(t.kategorie || "Sonstiges")}</span>
          <span class="lib-titel">${esc(t.titel || "(kein Titel)")}</span>
        </div>
        <div class="lib-vorschau">${esc(vorschau)}</div>
      </div>
      <div class="lib-actions">
        <button class="lib-btn" data-action="edit" data-id="${esc(t.id)}" title="Bearbeiten">✏️</button>
        <button class="lib-btn" data-action="del"  data-id="${esc(t.id)}" title="Löschen">🗑</button>
      </div>
    </div>`;
  }).join("");

  // Event-Listener
  list.querySelectorAll(".lib-checkbox").forEach(cb => {
    cb.addEventListener("change", onLibCheckboxChange);
  });
  list.querySelectorAll("[data-action='edit']").forEach(btn => {
    btn.addEventListener("click", () => loadIntoForm(btn.dataset.id));
  });
  list.querySelectorAll("[data-action='del']").forEach(btn => {
    btn.addEventListener("click", () => deleteText(btn.dataset.id));
  });
  // Klick auf Text-Body → in Formular laden (Komfort)
  list.querySelectorAll(".lib-item-body").forEach(el => {
    el.addEventListener("click", () => loadIntoForm(el.dataset.id));
  });

  updatePoolSelCount();
}

async function onLibCheckboxChange(e) {
  const id = e.target.dataset.id;
  if (!LIB) return;
  const pool = LIB.pool || { aktiv: false, intervall: "30", auswahl: [] };
  let auswahl = [...(pool.auswahl || [])];

  if (pool.aktiv) {
    // Pool-Modus: beliebig viele
    if (e.target.checked) { if (!auswahl.includes(id)) auswahl.push(id); }
    else                   { auswahl = auswahl.filter(a => a !== id); }
  } else {
    // Einzeltext-Modus: nur einer
    if (e.target.checked) {
      auswahl = [id];
      // andere Checkboxen visuell deselektieren
      document.querySelectorAll(".lib-checkbox").forEach(cb => {
        if (cb.dataset.id !== id) cb.checked = false;
      });
    } else {
      auswahl = [];
    }
  }

  try {
    const r = await pywebview.api.set_pool({ auswahl });
    if (r.ok) { LIB = r.library; updatePoolSelCount(); updateDashPoolStatus(); }
  } catch (ex) { console.error("set_pool:", ex); }
}

function updatePoolSelCount() {
  const auswahl = (LIB && LIB.pool && LIB.pool.auswahl) ? LIB.pool.auswahl : [];
  const n = auswahl.length;
  $("#poolSelCount").textContent = n + " Text" + (n !== 1 ? "e" : "") + " ausgewählt";
}

function loadIntoForm(id) {
  if (!LIB) return;
  const t = (LIB.texte || []).find(x => x.id === id);
  if (!t) return;
  $("#inpEditId").value  = t.id;
  $("#inpTitel").value   = t.titel || "";
  $("#inpArabisch").value = t.arabisch || "";
  $("#inpText").value    = t.text || "";
  $("#inpKat").value     = t.kategorie || "Sonstiges";
  $("#inpQuelle").value  = t.quelle || "";
  $("#editCardTitle").textContent = "Eintrag bearbeiten";
  // Scrollen zum Formular
  $("#cardEditText").scrollIntoView({ behavior: "smooth", block: "start" });
  setResult("#editResult", "", "");
}

function clearEditForm() {
  $("#inpEditId").value  = "";
  $("#inpTitel").value   = "";
  $("#inpArabisch").value = "";
  $("#inpText").value    = "";
  $("#inpKat").value     = "Sonstiges";
  $("#inpQuelle").value  = "";
  $("#editCardTitle").textContent = "Neuer Eintrag";
  setResult("#editResult", "", "");
}

async function saveText() {
  const titel = $("#inpTitel").value.trim();
  const text  = $("#inpText").value.trim();
  if (!titel && !text) {
    setResult("#editResult", "err", "Bitte mindestens Titel oder Text ausfüllen.");
    return;
  }
  setResult("#editResult", "", "Speichern…");
  try {
    const r = await pywebview.api.save_text({
      id:       $("#inpEditId").value || undefined,
      titel,
      arabisch: $("#inpArabisch").value.trim(),
      text,
      kategorie: $("#inpKat").value,
      quelle: $("#inpQuelle").value.trim()
    });
    if (r.ok) {
      LIB = r.library;
      renderLibrary();
      updateDashPoolStatus();
      setResult("#editResult", "ok", "✓ Gespeichert.");
      clearEditForm();
    } else {
      setResult("#editResult", "err", r.error || "Fehler");
    }
  } catch (e) {
    setResult("#editResult", "err", "Fehler: " + (e.message || e));
  }
}

async function deleteText(id) {
  if (!confirm("Diesen Eintrag wirklich löschen?")) return;
  try {
    const r = await pywebview.api.delete_text(id);
    if (r.ok) {
      LIB = r.library;
      renderLibrary();
      updateDashPoolStatus();
      if ($("#inpEditId").value === id) clearEditForm();
    }
  } catch (e) {
    console.error("deleteText:", e);
  }
}

async function sendDirect() {
  const text = $("#inpText").value.trim();
  if (!text) { setResult("#editResult", "err", "Kein Text zum Senden."); return; }
  if (!PI_ONLINE) { setResult("#editResult", "err", "Pi nicht verbunden."); return; }
  setResult("#editResult", "", "Sende…");
  try {
    const r = await pywebview.api.send_config_to_pi({
      infotext: {
        titel:    $("#inpTitel").value.trim(),
        text,
        arabisch: $("#inpArabisch").value.trim(),
        kategorie: $("#inpKat").value,
        quelle: $("#inpQuelle").value.trim()
      },
      pool: { aktiv: false, intervall: "30", eintraege: [] }
    });
    if (r.ok) setResult("#editResult", "ok", "✓ Text ist jetzt auf dem TV aktiv.");
    else      setResult("#editResult", "err", r.error || "Fehler beim Senden");
  } catch (e) {
    setResult("#editResult", "err", "Fehler: " + (e.message || e));
  }
}

/* ── Pool-Schalter & Einstellungen ───────────────────────────────────────── */
function applyPoolState(pool) {
  const aktiv = !!pool.aktiv;
  const btn   = $("#btnPoolToggle");
  btn.dataset.on = String(aktiv);
  btn.querySelector(".toggle-track").classList.toggle("on", aktiv);
  $("#toggleLabel").textContent = aktiv ? "AKTIV" : "INAKTIV";
  $("#poolMasterSub").textContent = aktiv
    ? "aktiv — Rotation aus Bibliothek"
    : "inaktiv — 1 fixer Text";
  $("#poolSettings").classList.toggle("hidden", !aktiv);

  // Intervall-Radio setzen
  const iv = pool.intervall || "day";
  const radio = document.querySelector(`input[name='intervall'][value='${iv}']`);
  if (radio) radio.checked = true;
}

async function togglePool() {
  if (!LIB) return;
  const neuAktiv = !(LIB.pool && LIB.pool.aktiv);
  try {
    const r = await pywebview.api.set_pool({ aktiv: neuAktiv });
    if (r.ok) {
      LIB = r.library;
      applyPoolState(LIB.pool || {});
      renderLibrary();
      updateDashPoolStatus();
    }
  } catch (e) {
    console.error("togglePool:", e);
  }
}

async function savePoolSettings() {
  if (!LIB) return;
  const iv = document.querySelector("input[name='intervall']:checked");
  try {
    const r = await pywebview.api.set_pool({ intervall: iv ? iv.value : "day" });
    if (r.ok) { LIB = r.library; }
  } catch (e) { console.error("savePoolSettings:", e); }
}

async function sendLive() {
  if (!PI_ONLINE) {
    setResult("#poolResult", "err", "Pi nicht verbunden. Verbindung unter ⚙️ System prüfen.");
    return;
  }
  const btn = $("#btnSendLive");
  btn.disabled = true;
  setResult("#poolResult", "", "Sende…");
  try {
    const r = await pywebview.api.send_live();
    if (r.ok) {
      setResult("#poolResult", "ok", "✓ Erfolgreich gesendet — TV zeigt jetzt die neue Konfiguration.");
      reloadPreview();
    } else {
      setResult("#poolResult", "err", "✕ " + (r.error || "Fehler beim Senden"));
    }
  } catch (e) {
    setResult("#poolResult", "err", "Fehler: " + (e.message || e));
  }
  btn.disabled = false;
}

/* ════════════════════════════════════════════════════════════════════════════
   SPRACHEN  (Manager-UI + Takvim-TV)
   ════════════════════════════════════════════════════════════════════════════ */

/* Übersetzungstabelle für den Manager selbst */
const MGR_LANG = {
  de: {
    navDashboard:    "Dashboard",
    navGebetszeiten: "Gebetszeiten",
    navHintergruende:"Hintergründe",
    navInfotexte:    "Infotexte",
    navTermine:      "Termine",
    navSystem:       "System",
    sysLangTakvimTitle:   "📺 Takvim — Anzeigesprache (TV)",
    sysLangTakvimHint:    "Sprache der TV-Anzeige auf dem Raspberry Pi",
    sysLangManagerTitle:  "🖥️ Manager — Bediensprache",
    sysLangManagerHint:   "Sprache der Benutzeroberfläche dieses Programms",
    sysDataTitle:   "Datenablage",
    sysDataBase:    "Programmordner",
    sysDataLock:    "Sperrzone (Update-sicher)",
    sysDataTemp:    "Update-Wartezimmer",
    saved:          "Gespeichert.",
    noConn:         "Pi nicht verbunden — Sprache nur lokal vorgemerkt.",
    langSet:        l => "✓ Takvim-Sprache: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
    mgrSet:         l => "✓ Manager-Sprache: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
  },
  al: {
    navDashboard:    "Paneli",
    navGebetszeiten: "Kohët e namazit",
    navHintergruende:"Sfondet",
    navInfotexte:    "Tekstet",
    navTermine:      "Terminet",
    navSystem:       "Sistemi",
    sysLangTakvimTitle:   "📺 Takvim — Gjuha e ekranit (TV)",
    sysLangTakvimHint:    "Gjuha e ekranit TV në Raspberry Pi",
    sysLangManagerTitle:  "🖥️ Manager — Gjuha e programit",
    sysLangManagerHint:   "Gjuha e ndërfaqes së këtij programi",
    sysDataTitle:   "Dosjet e të dhënave",
    sysDataBase:    "Dosja e programit",
    sysDataLock:    "Zonë e mbrojtur (e sigurt nga përditësimet)",
    sysDataTemp:    "Pritja e përditësimit",
    saved:          "U ruajt.",
    noConn:         "Pi nuk është i lidhur — gjuha u shënua vetëm lokalisht.",
    langSet:        l => "✓ Gjuha e Takvimit: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
    mgrSet:         l => "✓ Gjuha e menaxherit: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
  },
  ar: {
    navDashboard:    "لوحة",
    navGebetszeiten: "أوقات الصلاة",
    navHintergruende:"الخلفيات",
    navInfotexte:    "النصوص",
    navTermine:      "المواعيد",
    navSystem:       "النظام",
    sysLangTakvimTitle:   "📺 التقويم — لغة العرض (التلفاز)",
    sysLangTakvimHint:    "لغة شاشة التلفاز على Raspberry Pi",
    sysLangManagerTitle:  "🖥️ المدير — لغة البرنامج",
    sysLangManagerHint:   "لغة واجهة هذا البرنامج",
    sysDataTitle:   "مجلدات البيانات",
    sysDataBase:    "مجلد البرنامج",
    sysDataLock:    "منطقة محمية (آمنة من التحديثات)",
    sysDataTemp:    "انتظار التحديث",
    saved:          "تم الحفظ.",
    noConn:         "Pi غير متصل — تم حفظ اللغة محليًا فقط.",
    langSet:        l => "✓ لغة التقويم: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
    mgrSet:         l => "✓ لغة المدير: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
  },
  en: {
    navDashboard:    "Dashboard",
    navGebetszeiten: "Prayer Times",
    navHintergruende:"Backgrounds",
    navInfotexte:    "Info Texts",
    navTermine:      "Events",
    navSystem:       "System",
    sysLangTakvimTitle:   "📺 Takvim — Display Language (TV)",
    sysLangTakvimHint:    "Language of the TV display on the Raspberry Pi",
    sysLangManagerTitle:  "🖥️ Manager — Interface Language",
    sysLangManagerHint:   "Language of this program's user interface",
    sysDataTitle:   "Data Storage",
    sysDataBase:    "Program Folder",
    sysDataLock:    "Protected Zone (update-safe)",
    sysDataTemp:    "Update Staging",
    saved:          "Saved.",
    noConn:         "Pi not connected — language saved locally only.",
    langSet:        l => "✓ Takvim language: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
    mgrSet:         l => "✓ Manager language: " + {de:"Deutsch",al:"Shqip",ar:"عربي",en:"English"}[l],
  }
};

let MANAGER_LANG = "de";
let TAKVIM_LANG  = "de";

/* ════════════════════════════════════════════════════════════════════════════
   TERMINE / EVENTS  (Etappe 5)
   Zeitgesteuerte Infotexte mit von/bis-Fenster. Werden lokal in
   hadith_bibliothek.json (events[]) gespeichert und bei jeder Änderung an den
   Pi gesendet (config.events[]). Die TV-App blendet sie im Zeitfenster
   automatisch ein und nach Ablauf wieder aus – mit Vorrang vor dem Pool.
   ════════════════════════════════════════════════════════════════════════════ */
let EV_LIST = [];

function initTerminePanel() {
  const sb = $("#btnSaveEvent");
  if (sb) sb.addEventListener("click", saveEventForm);
  const cb = $("#btnEvClear");
  if (cb) cb.addEventListener("click", clearEventForm);
}

async function loadEvents() {
  try {
    const lib = await pywebview.api.get_library();
    EV_LIST = (lib && lib.events) ? lib.events : [];
    renderEvents();
  } catch (e) {
    console.error("loadEvents:", e);
  }
}

/* Status eines Termins zum aktuellen Zeitpunkt bestimmen. */
function eventStatus(ev) {
  if (ev.aktiv === false) return { key: "inaktiv", label: "Inaktiv" };
  const now = Date.now();
  const von = parseEventTsJS(ev.von);
  const bis = parseEventTsJS(ev.bis);
  if (bis !== null && now > bis)  return { key: "abgelaufen", label: "Abgelaufen" };
  if (von !== null && now < von)  return { key: "geplant",    label: "Geplant" };
  return { key: "aktiv", label: "Läuft jetzt" };
}

function fmtEventTs(v) {
  const ts = parseEventTsJS(v);
  if (ts === null) return null;
  const d = new Date(ts);
  const p = n => String(n).padStart(2, "0");
  return p(d.getDate()) + "." + p(d.getMonth() + 1) + "." + d.getFullYear() +
         " " + p(d.getHours()) + ":" + p(d.getMinutes());
}

function eventZeitfenster(ev) {
  const von = fmtEventTs(ev.von);
  const bis = fmtEventTs(ev.bis);
  if (von && bis) return "ab " + von + " · bis " + bis;
  if (von)        return "ab " + von + " · unbegrenzt";
  if (bis)        return "sofort · bis " + bis;
  return "sofort · unbegrenzt";
}

function renderEvents() {
  const list = $("#evList");
  if (!list) return;
  const evs = EV_LIST || [];
  $("#evCount").textContent = evs.length + (evs.length === 1 ? " Termin" : " Termine");

  if (!evs.length) {
    list.innerHTML = '<div class="lib-empty">Noch keine Termine angelegt.</div>';
    return;
  }

  list.innerHTML = evs.map(ev => {
    const st = eventStatus(ev);
    const vorschau = (ev.arabisch ? "«" + ev.arabisch.substring(0, 40) + "» " : "")
                   + (ev.text || "").substring(0, 90)
                   + ((ev.text || "").length > 90 ? "…" : "");
    return `<div class="lib-item ev-item" data-id="${esc(ev.id)}">
      <div class="lib-item-body" data-id="${esc(ev.id)}">
        <div class="lib-item-head">
          <span class="ev-status ev-${st.key}">${st.label}</span>
          <span class="lib-titel">${esc(ev.titel || "(ohne Titel)")}</span>
        </div>
        <div class="ev-window">🕒 ${esc(eventZeitfenster(ev))}</div>
        <div class="lib-vorschau">${esc(vorschau)}</div>
      </div>
      <div class="lib-actions">
        <button class="lib-btn" data-action="evedit" data-id="${esc(ev.id)}" title="Bearbeiten">✏️</button>
        <button class="lib-btn" data-action="evdel"  data-id="${esc(ev.id)}" title="Löschen">🗑</button>
      </div>
    </div>`;
  }).join("");

  list.querySelectorAll("[data-action='evedit']").forEach(btn =>
    btn.addEventListener("click", () => loadEventIntoForm(btn.dataset.id)));
  list.querySelectorAll("[data-action='evdel']").forEach(btn =>
    btn.addEventListener("click", () => deleteEventUI(btn.dataset.id)));
  list.querySelectorAll(".lib-item-body").forEach(el =>
    el.addEventListener("click", () => loadEventIntoForm(el.dataset.id)));
}

function loadEventIntoForm(id) {
  const ev = (EV_LIST || []).find(e => e.id === id);
  if (!ev) return;
  $("#evEditId").value  = ev.id || "";
  $("#evTitel").value   = ev.titel || "";
  $("#evArabisch").value= ev.arabisch || "";
  $("#evText").value    = ev.text || "";
  $("#evQuelle").value  = ev.quelle || "";
  $("#evKat").value     = ev.kategorie || "Sonstiges";
  $("#evVon").value     = toLocalInput(ev.von);
  $("#evBis").value     = toLocalInput(ev.bis);
  $("#evAktiv").checked = ev.aktiv !== false;
  $("#evCardTitle").textContent = "Termin bearbeiten";
  setResult("#evResult", "", "");
  $("#cardEditEvent").scrollIntoView({ behavior: "smooth", block: "start" });
}

/* datetime-local erwartet "YYYY-MM-DDTHH:MM". Wir speichern exakt dieses Format,
   daher ist die Rückwandlung trivial (nur abschneiden / Leerzeichen→T). */
function toLocalInput(v) {
  if (!v) return "";
  return String(v).trim().replace(" ", "T").substring(0, 16);
}

function clearEventForm() {
  ["#evEditId","#evTitel","#evArabisch","#evText","#evQuelle","#evVon","#evBis"]
    .forEach(s => { const el = $(s); if (el) el.value = ""; });
  $("#evKat").value = "Allgemeine Info / Appell";
  $("#evAktiv").checked = true;
  $("#evCardTitle").textContent = "Neuer Termin";
  setResult("#evResult", "", "");
}

async function saveEventForm() {
  const eintrag = {
    id:        $("#evEditId").value || undefined,
    titel:     $("#evTitel").value.trim(),
    arabisch:  $("#evArabisch").value.trim(),
    text:      $("#evText").value.trim(),
    quelle:    $("#evQuelle").value.trim(),
    kategorie: $("#evKat").value,
    von:       $("#evVon").value.trim(),
    bis:       $("#evBis").value.trim(),
    aktiv:     $("#evAktiv").checked,
  };

  if (!eintrag.titel && !eintrag.text && !eintrag.arabisch) {
    setResult("#evResult", "err", "Bitte mindestens Titel, Text oder arabischen Text ausfüllen.");
    return;
  }
  // Plausibilität: Bis darf nicht vor Von liegen
  const vts = parseEventTsJS(eintrag.von), bts = parseEventTsJS(eintrag.bis);
  if (vts !== null && bts !== null && bts < vts) {
    setResult("#evResult", "err", "Das Ende (Anzeigen bis) liegt vor dem Anfang (Anzeigen ab).");
    return;
  }

  setResult("#evResult", "", "Speichere…");
  try {
    const r = await pywebview.api.save_event(eintrag);
    if (r && r.ok) {
      EV_LIST = (r.library && r.library.events) ? r.library.events : EV_LIST;
      renderEvents();
      clearEventForm();
      const push = r.push || {};
      if (PI_ONLINE && push.ok) {
        setResult("#evResult", "ok", "✓ Termin gespeichert und an den TV gesendet.");
      } else if (push.offline || !PI_ONLINE) {
        setResult("#evResult", "ok", "✓ Termin gespeichert. TV offline — wird beim nächsten Senden/Verbinden übernommen.");
      } else {
        setResult("#evResult", "ok", "✓ Termin gespeichert. Senden an TV fehlgeschlagen: " + (push.error || "unbekannt"));
      }
      // Studio-Vorschau aktualisieren (Events beeinflussen den Live-Infotext)
      try { await pullPreviewState(); } catch (e) {}
    } else {
      setResult("#evResult", "err", "✕ " + ((r && r.error) || "Fehler beim Speichern"));
    }
  } catch (e) {
    setResult("#evResult", "err", "✕ " + e);
  }
}

async function deleteEventUI(id) {
  const ev = (EV_LIST || []).find(e => e.id === id);
  const name = ev ? (ev.titel || "(ohne Titel)") : "";
  if (!confirm("Diesen Termin wirklich löschen?\n\n" + name)) return;
  try {
    const r = await pywebview.api.delete_event(id);
    if (r && r.ok) {
      EV_LIST = (r.library && r.library.events) ? r.library.events : (EV_LIST || []).filter(e => e.id !== id);
      renderEvents();
      const push = r.push || {};
      if (PI_ONLINE && push.ok) {
        setResult("#evResult", "ok", "✓ Termin gelöscht und TV aktualisiert.");
      } else {
        setResult("#evResult", "ok", "✓ Termin gelöscht. (TV wird beim nächsten Senden aktualisiert.)");
      }
      try { await pullPreviewState(); } catch (e) {}
    } else {
      setResult("#evResult", "err", "✕ " + ((r && r.error) || "Fehler beim Löschen"));
    }
  } catch (e) {
    setResult("#evResult", "err", "✕ " + e);
  }
}

/* ── Manager-UI übersetzen ──────────────────────────────────────────────── */
function applyManagerLang(l) {
  if (!MGR_LANG[l]) return;
  MANAGER_LANG = l;
  const LL = MGR_LANG[l];
  const isRtl = (l === "ar");
  document.documentElement.setAttribute("dir", isRtl ? "rtl" : "ltr");

  const navKeys = { dashboard:"navDashboard", gebetszeiten:"navGebetszeiten",
                    hintergruende:"navHintergruende", infotexte:"navInfotexte",
                    termine:"navTermine", system:"navSystem" };
  document.querySelectorAll(".nav-btn").forEach(btn => {
    const key = navKeys[btn.dataset.panel];
    if (key && LL[key]) btn.querySelector("span").textContent = LL[key];
  });

  ["sysLangTakvimTitle","sysLangTakvimHint","sysLangManagerTitle","sysLangManagerHint",
   "sysDataTitle","sysDataBase","sysDataLock","sysDataTemp"].forEach(id => {
    const el = document.getElementById(id);
    if (el && LL[id]) el.textContent = LL[id];
  });

  markLangBtns("managerLangRow", l);
}

function markLangBtns(rowId, activeLang) {
  document.querySelectorAll("#" + rowId + " .lang-btn").forEach(btn =>
    btn.classList.toggle("active", btn.dataset.lang === activeLang));
}

/* ── Takvim-Sprache setzen ───────────────────────────────────────────────── */
async function setTakvimLang(l) {
  const LL = MGR_LANG[MANAGER_LANG];
  setResult("#takvimLangResult", "", "…");
  try {
    const r = await pywebview.api.set_takvim_lang(l);
    if (r && r.ok === false) {
      setResult("#takvimLangResult", "err", "✕ " + (r.error || "Fehler"));
    } else {
      TAKVIM_LANG = l;
      markLangBtns("takvimLangRow", l);
      setResult("#takvimLangResult", "ok", PI_ONLINE ? LL.langSet(l) : LL.noConn);
    }
  } catch(e) { setResult("#takvimLangResult", "err", "✕ " + e); }
}
window.setTakvimLang = setTakvimLang;

/* ── Manager-Sprache setzen ──────────────────────────────────────────────── */
async function setManagerLang(l) {
  setResult("#managerLangResult", "", "…");
  try {
    const r = await pywebview.api.set_manager_lang(l);
    if (r && r.ok === false) {
      setResult("#managerLangResult", "err", "✕ " + (r.error || "Fehler"));
    } else {
      CFG = await pywebview.api.get_config();
      applyManagerLang(l);
      if (typeof renderSnippets === 'function') renderSnippets();
      setResult("#managerLangResult", "ok", MGR_LANG[l].mgrSet(l));
    }
  } catch(e) { setResult("#managerLangResult", "err", "✕ " + e); }
}
window.setManagerLang = setManagerLang;

/* ── Sprachinit beim Laden ───────────────────────────────────────────────── */
function initLangPanel() {
  MANAGER_LANG = (CFG && CFG.manager_lang) || "de";
  applyManagerLang(MANAGER_LANG);
  if (PI_ONLINE) {
    pywebview.api.get_pi_config().then(pc => {
      TAKVIM_LANG = (pc && pc.sprache) || "de";
      markLangBtns("takvimLangRow", TAKVIM_LANG);
    }).catch(() => markLangBtns("takvimLangRow", "de"));
  } else {
    markLangBtns("takvimLangRow", "de");
  }
}

/* ── System-Panel ─────────────────────────────────────────────────────────── */
function initSystemPanel() {
  $("#inpIp").value        = (CFG.pi && CFG.pi.ip)   || "";
  $("#inpPort").value      = (CFG.pi && CFG.pi.port) || 8080;
  $("#inpUpdateUrl").value = (CFG.update && CFG.update.url) || "";

  initLangPanel();

  $("#btnSavePi").addEventListener("click", async () => {
    await savePiSettings();
    setResult("#piTestResult", "ok", "Gespeichert.");
  });

  $("#btnTestPi").addEventListener("click", async () => {
    const btn = $("#btnTestPi");
    btn.disabled = true;
    setResult("#piTestResult", "", "Verbinde…");
    await savePiSettings();
    try {
      const pi = await pywebview.api.ping_pi();
      applyPiResult(pi);
      if (pi.online) {
        setResult("#piTestResult", "ok",
          "✓ Verbunden — Pi-Dienst v" + pi.pi_version + ", Antwortzeit " + pi.latency_ms + " ms");
        refreshPrayerCard();
      } else {
        setResult("#piTestResult", "err", "✕ " + (pi.error || "Keine Verbindung"));
      }
    } catch (e) {
      setResult("#piTestResult", "err", "✕ Test fehlgeschlagen");
    }
    btn.disabled = false;
  });

  $("#btnSaveUpdate").addEventListener("click", async () => {
    CFG = await pywebview.api.save_config({
      update: { url: $("#inpUpdateUrl").value.trim(), check_on_start: true }
    });
    setResult("#updateResult", "ok", "Gespeichert.");
  });

  $("#btnCheckUpdate").addEventListener("click", async () => {
    await checkUpdateUI();
  });

  $("#btnDownloadUpdate").addEventListener("click", async () => {
    const btn = $("#btnDownloadUpdate");
    btn.disabled = true;
    setResult("#updateResult", "", "Lade Update herunter…");
    try {
      const r = await pywebview.api.download_update();
      if (r.ok && r.downloaded) {
        setResult("#updateResult", "ok",
          "✓ Heruntergeladen (v" + (r.version || "?") + "). Jetzt installierbar.");
        $("#btnInstallUpdate").classList.remove("hidden");
      } else if (r.ok) {
        setResult("#updateResult", "", r.info || "Kein Update zum Laden.");
      } else {
        setResult("#updateResult", "err", "✕ " + (r.error || "Download fehlgeschlagen"));
      }
    } catch (e) {
      setResult("#updateResult", "err", "✕ Download fehlgeschlagen.");
    }
    btn.disabled = false;
  });

  $("#btnInstallUpdate").addEventListener("click", async () => {
    if (!confirm("Update jetzt installieren?\n\nDie App schließt sich, tauscht " +
                 "ihre Programmdateien aus und startet automatisch neu. " +
                 "Ihre Daten (Bibliothek, Einstellungen) bleiben erhalten.")) {
      return;
    }
    setResult("#updateResult", "", "Installation wird gestartet…");
    try {
      const r = await pywebview.api.install_update();
      if (r.ok) {
        setResult("#updateResult", "ok", r.info || "Installation gestartet…");
      } else {
        setResult("#updateResult", "err", "✕ " + (r.error || "Installation fehlgeschlagen"));
      }
    } catch (e) {
      // Beim erfolgreichen Start beendet sich die App — ein Fehler hier ist
      // meist nur der abbrechende Aufruf.
      setResult("#updateResult", "", "Installation läuft – App startet neu…");
    }
  });

  $("#btnRefreshPiUpdate").addEventListener("click", refreshPiUpdateStatus);

  $("#btnRollback").addEventListener("click", async () => {
    if (!confirm("Letzte stabile Version auf dem TV wiederherstellen?\n\n" +
                 "Der Pi stellt die gesicherte Vorgängerversion wieder her und " +
                 "startet die Anzeige in wenigen Sekunden neu.")) {
      return;
    }
    const btn = $("#btnRollback");
    btn.disabled = true;
    setResult("#rollbackResult", "", "Sende Notfall-Signal an den Pi…");
    try {
      const r = await pywebview.api.rollback_pi();
      if (r.ok && r.restored) {
        setResult("#rollbackResult", "ok",
          "✓ Wiederhergestellt — die Anzeige startet jetzt neu.");
      } else {
        setResult("#rollbackResult", "err",
          "✕ " + (r.error || "Wiederherstellung nicht möglich"));
      }
    } catch (e) {
      setResult("#rollbackResult", "err", "✕ Signal konnte nicht gesendet werden.");
    }
    btn.disabled = false;
    setTimeout(refreshPiUpdateStatus, 1500);
  });

  refreshPiUpdateStatus();
}

async function savePiSettings() {
  CFG = await pywebview.api.save_config({
    pi: { ip:   $("#inpIp").value.trim(),
          port: parseInt($("#inpPort").value, 10) || 8080 }
  });
}

/* ── Update-Prüfung (System-Reiter, Etappe 6) ──────────────────────────────── */
async function checkUpdateUI() {
  setResult("#updateResult", "", "Prüfe…");
  const box = $("#updateAvailBox");
  try {
    const r = await pywebview.api.check_update();
    if (!r.ok) {
      box.classList.add("hidden");
      setResult("#updateResult", "err", "✕ " + (r.error || "Prüfung fehlgeschlagen."));
      return;
    }
    if (r.available) {
      $("#updateLatest").textContent = "v" + (r.latest || "?");
      $("#updateNotes").textContent  = r.notes || "";
      $("#btnInstallUpdate").classList.add("hidden");  // erst nach Download
      box.classList.remove("hidden");
      setResult("#updateResult", "ok", r.info || "Update verfügbar.");
    } else {
      box.classList.add("hidden");
      setResult("#updateResult", "", r.info || "Software ist aktuell.");
    }
  } catch (e) {
    setResult("#updateResult", "err", "Prüfung fehlgeschlagen.");
  }
}

/* ── Backup-/Update-Status des Pi (für Notfall-Karte) ──────────────────────── */
async function refreshPiUpdateStatus() {
  const bEl = $("#piBackupState"), uEl = $("#piUpdateState");
  if (!bEl || !uEl) return;
  bEl.textContent = "wird geprüft…";
  uEl.textContent = "wird geprüft…";
  try {
    const r = await pywebview.api.get_pi_update_status();
    if (r && r.ok) {
      bEl.textContent = r.backup_present ? "vorhanden ✓" : "keines";
      uEl.textContent = r.update_pending
        ? ((r.pending_files && r.pending_files.length
              ? r.pending_files.join(", ") : "ja"))
        : "keines";
      $("#btnRollback").disabled = !r.backup_present;
    } else {
      bEl.textContent = "—";
      uEl.textContent = "—";
      $("#btnRollback").disabled = true;
    }
  } catch (e) {
    bEl.textContent = "Pi offline";
    uEl.textContent = "—";
    $("#btnRollback").disabled = true;
  }
}

/* ── Kleinkram ────────────────────────────────────────────────────────────── */
function setResult(sel, cls, text) {
  const el = $(sel);
  el.className = "result-line " + cls;
  el.textContent = text;
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, c =>
    ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

function fmtTime(iso) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("de-DE") + ", " +
           d.toLocaleTimeString("de-DE", {hour:"2-digit", minute:"2-digit"}) + " Uhr";
  } catch (e) { return iso; }
}

/* ════════════════════════════════════════════════════════════════════════════
   PANEL: HINTERGRÜNDE · DESIGN-STUDIO (Etappe 4)
   ----------------------------------------------------------------------------
   • Mediathek: Upload (16:9-Prüfung im Browser), Galerie, Klick = Hintergrund,
     Löschen. Bilder werden über Python an den Pi gesendet (Architektur:
     Pi-Kommunikation läuft über Python, nicht über JS-fetch). Die Anzeige der
     Thumbnails lädt das Bild direkt vom Pi (statische Datei, CORS offen).
   • 3 Echtzeit-Regler -> design.blur/opacity/darken (live in der Vorschau,
     beim Loslassen an den Pi gesendet).
   • WYSIWYG: Verschieben & Skalieren des Anzeige-Blocks -> layout {x,y,scale}
     als Prozentwerte. 🔒/🔓-Schalter (Standard: gesperrt).
   • Kontrast-Analyse + Auto-Optimierung (lokal auf einer Canvas).
   ════════════════════════════════════════════════════════════════════════════ */

let DS_PI_BASE   = null;
let DS_BG        = null;                       // aktiver Hintergrund-Dateiname
let DS_DESIGN    = { blur: 12, opacity: 55, darken: 30 };
let DS_OVERRIDE  = { enabled: false, elements: {} };  // freies Pro-Element-Layout
/* v1.8 (Anf. 6): Der Block-Modus wurde entfernt. „Einzeln" (Frei-Layout) ist das
   einzige und damit unbenannte Standard-Verhalten. DS_MODE bleibt aus Gruenden
   der Lesbarkeit erhalten, ist aber konstant "free". */
const DS_MODE    = "free";
let DS_UNLOCKED  = false;
let DS_UPLOAD    = null;                        // { name, b64 } vor dem Senden
let DS_INFO      = null;   // tatsächlich vom Admin eingegebener Infotext (oder null) – KEIN Platzhalter
let dsDesignTimer = null;

/* ════════════════════════════════════════════════════════════════════════════
   GETEILTE VORSCHAU-KOMPONENTE  (Etappe 4 · Bugfix 5)
   Dashboard-Vorschau und Studio-Editor sind ab jetzt EIN und dieselbe
   Komponente. Beide Bühnen erhalten exakt dasselbe Markup (STAGE_INNER) und
   dieselben Apply-Funktionen, sodass die Vorschau überall identisch aussieht
   und in Echtzeit synchron bleibt. Die Struktur spiegelt die echte TV-Anzeige
   (kiosk-logic.js): die Element-IDs (clock, info, tile_*) entsprechen
   exakt den IDs des override_layout-Schemas.
   ════════════════════════════════════════════════════════════════════════════ */

/* ── TV-Icons (1:1 aus kiosk-logic.js) ─────────────────────────────────────── */
const _G = '#c5a55a';
const _S = b => `<svg viewBox="0 0 32 32" width="34" height="34">${b}</svg>`;
const _L  = `stroke="${_G}" stroke-width="1.5" stroke-linecap="round"`;
const _LT = `stroke="${_G}" stroke-width="1.2" stroke-linecap="round"`;
const TV_ICONS = {
  fajr:_S(`<line x1="3" y1="25" x2="29" y2="25" ${_L}/><path d="M 8 25 A 8 8 0 0 0 24 25" fill="rgba(197,165,90,.2)" stroke="${_G}" stroke-width="1.5"/><line x1="16" y1="13" x2="16" y2="10" ${_L}/><line x1="21" y1="15.5" x2="23" y2="13" ${_L}/><line x1="11" y1="15.5" x2="9" y2="13" ${_L}/><line x1="24.5" y1="20" x2="27" y2="19" ${_L}/><line x1="7.5" y1="20" x2="5" y2="19" ${_L}/><polyline points="13,8 16,5 19,8" fill="none" stroke="${_G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  dhuhr:_S(`<circle cx="16" cy="16" r="6" fill="rgba(197,165,90,.2)" stroke="${_G}" stroke-width="1.5"/><line x1="16" y1="7" x2="16" y2="4" ${_L}/><line x1="16" y1="25" x2="16" y2="28" ${_L}/><line x1="7" y1="16" x2="4" y2="16" ${_L}/><line x1="25" y1="16" x2="28" y2="16" ${_L}/><line x1="10" y1="10" x2="8" y2="8" ${_L}/><line x1="22" y1="22" x2="24" y2="24" ${_L}/><line x1="22" y1="10" x2="24" y2="8" ${_L}/><line x1="10" y1="22" x2="8" y2="24" ${_L}/>`),
  asr:_S(`<circle cx="16" cy="17" r="6" fill="rgba(197,165,90,.18)" stroke="${_G}" stroke-width="1.5"/><line x1="16" y1="8" x2="16" y2="5" ${_LT} opacity=".35"/><line x1="16" y1="26" x2="16" y2="29" ${_L}/><line x1="7" y1="17" x2="4" y2="17" ${_LT} opacity=".35"/><line x1="25" y1="17" x2="28" y2="17" ${_L}/><line x1="10.5" y1="11.5" x2="8.5" y2="9.5" ${_LT} opacity=".35"/><line x1="21.5" y1="22.5" x2="23.5" y2="24.5" ${_L}/><line x1="21.5" y1="11.5" x2="23.5" y2="9.5" ${_L}/><line x1="10.5" y1="22.5" x2="8.5" y2="24.5" ${_L}/>`),
  maghrib:_S(`<line x1="3" y1="23" x2="29" y2="23" ${_L}/><path d="M 8 23 A 8 8 0 0 0 24 23" fill="rgba(197,165,90,.2)" stroke="${_G}" stroke-width="1.5"/><line x1="16" y1="11" x2="16" y2="8" ${_L}/><line x1="21" y1="13.5" x2="23" y2="11" ${_L}/><line x1="11" y1="13.5" x2="9" y2="11" ${_L}/><line x1="24.5" y1="18" x2="27" y2="17" ${_L}/><line x1="7.5" y1="18" x2="5" y2="17" ${_L}/><polyline points="13,27 16,30 19,27" fill="none" stroke="${_G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  isha:_S(`<path d="M 20 7 A 10 10 0 1 0 20 25 A 6.5 6.5 0 1 1 20 7 Z" fill="rgba(197,165,90,.2)" stroke="${_G}" stroke-width="1.5" stroke-linejoin="round"/><circle cx="22" cy="10" r="1" fill="${_G}" opacity=".6"/><circle cx="24" cy="14" r=".8" fill="${_G}" opacity=".4"/>`)
};

/* Referenz-Auflösung der TV-Anzeige (16:9 Full-HD). Alle px-Angaben im
   Kachel-Stil-Editor beziehen sich auf diese Auflösung. Die Vorschau skaliert
   sie mit --tv-scale auf ihre tatsächliche Breite herunter, sodass 52px im
   Slider auch 52 "TV-Pixel" erzeugt. */
const TV_REF_W = 1920;

const STAGE_TILES = [
  ["tile_fajr",    "Morgengebet",      "\u0627\u0644\u0641\u062c\u0631", "04:18", "fajr",    {beginn:"03:42", aufgang:"05:31"}],
  ["tile_dhuhr",   "Mittagsgebet",     "\u0627\u0644\u0638\u0647\u0631", "13:16", "dhuhr",   null],
  ["tile_asr",     "Nachmittagsgebet", "\u0627\u0644\u0639\u0635\u0631", "17:02", "asr",     null],
  ["tile_maghrib", "Abendgebet",       "\u0627\u0644\u0645\u063a\u0631\u0628", "20:44", "maghrib", null],
  ["tile_isha",    "Nachtgebet",       "\u0627\u0644\u0639\u0634\u0627\u0621", "22:21", "isha",    null],
];

/* Standard-Boxen (% der 16:9-Bühne) – nähern das normale Layout an und dienen
   als Startpunkt beim ersten Wechsel in den Einzeln-Modus. */
const OVERRIDE_DEFAULTS = {
  clock:        { x: 30, y: 6,  w: 40,   h: 16 },
  tile_fajr:    { x: 3,  y: 37, w: 17.6, h: 34 },
  tile_dhuhr:   { x: 22, y: 37, w: 17.6, h: 34 },
  tile_asr:     { x: 41, y: 37, w: 17.6, h: 34 },
  tile_maghrib: { x: 60, y: 37, w: 17.6, h: 34 },
  tile_isha:    { x: 79, y: 37, w: 17.6, h: 34 },
  info:         { x: 12, y: 74, w: 76,   h: 20 },
};

function defaultOverrideElements() {
  // tiefe Kopie, damit Bearbeiten die Vorlage nicht verändert
  const o = {};
  Object.keys(OVERRIDE_DEFAULTS).forEach(k => { o[k] = { ...OVERRIDE_DEFAULTS[k] }; });
  return o;
}

function stageInnerHTML(editable) {
  const tiles = STAGE_TILES.map(([id, nameDe, nameAr, time, key, sub]) => {
    const icon = TV_ICONS[key] || "";
    let inner = `<div class="ds-icon">${icon}</div>` +
                `<div><div class="ds-name-de">${nameDe}</div><div class="ds-name-ar">${nameAr}</div></div>` +
                `<div class="ds-ptime">${time}</div>`;
    if (sub) {
      inner += `<div class="ds-fajr-sub"><div><span class="ds-fsub-label">Beginn</span><span class="ds-fsub-time">${sub.beginn}</span></div><div style="text-align:right"><span class="ds-fsub-label">Aufgang</span><span class="ds-fsub-time">${sub.aufgang}</span></div></div>`;
    }
    return `<div class="ds-el ds-tile" data-el="${id}">${inner}` +
           (editable ? '<span class="ds-rs" data-rs="se"></span>' : "") + `</div>`;
  }).join("");
  const rs = editable ? '<span class="ds-rs" data-rs="se"></span>' : "";
  return `
    <div class="ds-bg default" data-role="bg"></div>
    <div class="ds-darken" data-role="darken"></div>
    <div class="ds-content" data-role="content">
      <div class="ds-el ds-clock" data-el="clock">12<span class="ds-blink">:</span>45${rs}</div>
      <div class="ds-tiles" data-role="tiles">${tiles}</div>
      <div class="ds-el ds-info" data-el="info" data-empty="1"><div class="ds-hadith-arabic"></div><div class="ds-hadith-text"></div><div class="ds-hadith-quelle"></div>${rs}</div>
    </div>
    ${editable ? '<svg class="ds-guides" data-role="guides" xmlns="http://www.w3.org/2000/svg"></svg>' : ''}
    <div class="ds-edithint" data-role="edithint">🔓 Jede Kachel einzeln ziehen · Ecke unten rechts skalieren · Doppelklick zum Gestalten</div>`;
}

function mountStage(stageEl, editable) {
  if (!stageEl) return;
  stageEl.innerHTML = stageInnerHTML(editable);
  applyDesignTo(stageEl, DS_DESIGN);
  applyBgTo(stageEl, DS_BG);
  applyLayoutTo(stageEl);
}

/* ════════════════════════════════════════════════════════════════════════════
   SNAP-LINIEN (Ausrichtungshilfen wie in PowerPoint)
   Beim Ziehen einer Kachel im Einzeln-Modus werden Kanten und Mitten
   mit allen anderen Kacheln sowie der Bühnenmitte verglichen. Bei
   Übereinstimmung innerhalb von SNAP_THRESH % rastet die Kachel ein
   und eine farbige Hilfslinie wird eingeblendet.
   ════════════════════════════════════════════════════════════════════════════ */
const SNAP_THRESH = 1.5; // %-Schwelle

function snapToGuides(dragId, box) {
  const guides = [];
  const others = [];
  Object.keys(DS_OVERRIDE.elements).forEach(id => {
    if (id === dragId) return;
    const b = DS_OVERRIDE.elements[id];
    if (b && typeof b.x === 'number') others.push({ id, ...b });
  });

  let bestDx = SNAP_THRESH, bestDy = SNAP_THRESH;
  let snapX = null, snapY = null;
  const cx = box.x + box.w / 2, cy = box.y + box.h / 2;
  const br = box.x + box.w, bb = box.y + box.h;

  /* Bühnenmitte (50 %) */
  [[cx, v => v - box.w / 2], [box.x, v => v], [br, v => v - box.w]].forEach(([val, snap]) => {
    const d = Math.abs(val - 50);
    if (d < bestDx) { bestDx = d; snapX = { pos: 50, to: snap(50) }; }
  });
  [[cy, v => v - box.h / 2], [box.y, v => v], [bb, v => v - box.h]].forEach(([val, snap]) => {
    const d = Math.abs(val - 50);
    if (d < bestDy) { bestDy = d; snapY = { pos: 50, to: snap(50) }; }
  });

  /* Gegen alle anderen Kacheln prüfen */
  others.forEach(o => {
    const oCx = o.x + o.w / 2, oCy = o.y + o.h / 2;
    const oR = o.x + o.w, oB = o.y + o.h;
    [[box.x, o.x, v => v], [box.x, oR, v => v], [br, o.x, v => v - box.w],
     [br, oR, v => v - box.w], [cx, oCx, v => v - box.w / 2]].forEach(([a, t, snap]) => {
      const d = Math.abs(a - t);
      if (d < bestDx) { bestDx = d; snapX = { pos: t, to: snap(t) }; }
    });
    [[box.y, o.y, v => v], [box.y, oB, v => v], [bb, o.y, v => v - box.h],
     [bb, oB, v => v - box.h], [cy, oCy, v => v - box.h / 2]].forEach(([a, t, snap]) => {
      const d = Math.abs(a - t);
      if (d < bestDy) { bestDy = d; snapY = { pos: t, to: snap(t) }; }
    });
  });

  if (snapX) { guides.push({ orient: 'v', pos: snapX.pos }); box = { ...box, x: snapX.to }; }
  if (snapY) { guides.push({ orient: 'h', pos: snapY.pos }); box = { ...box, y: snapY.to }; }
  return { box, guides };
}

function renderGuides(stageEl, guides) {
  const svg = stageEl.querySelector('[data-role="guides"]');
  if (!svg) return;
  svg.innerHTML = guides.map(g => g.orient === 'v'
    ? '<line x1="' + g.pos + '%" y1="0" x2="' + g.pos + '%" y2="100%" class="ds-guide-line"/>'
    : '<line x1="0" y1="' + g.pos + '%" x2="100%" y2="' + g.pos + '%" class="ds-guide-line"/>'
  ).join('');
}

function clearGuides(stageEl) {
  const svg = stageEl.querySelector('[data-role="guides"]');
  if (svg) svg.innerHTML = '';
}

/* ════════════════════════════════════════════════════════════════════════════
   KACHEL-EDITOR  (Fullscreen Milchglas-Overlay)
   Doppelklick → großes Milchglas-Overlay mit allen Kachel-Elementen einzeln
   bearbeitbar (Größe, Farbe) und frei verschiebbar mit Ausrichtungslinien.
   ════════════════════════════════════════════════════════════════════════════ */
let DS_SELECTED = null;
let TE_SUB = null;            // aktuell ausgewähltes Sub-Element im Editor (Anf. 3)
let dsEditorOverlay = null;
let dsEditorCommitTimer = null;

/* Defaults passend zur Takvim-TV-Anzeige */
const TE_DEFAULTS = {
  timeFontSize: 52, timeColor: '#ffffff',
  nameFontSize: 14, nameColor: '#b8c4dc',
  arFontSize: 24, arColor: '#c5a55a',
  iconScale: 130,
  bgOpacity: 55,
  fajrLabelSize: 11, fajrLabelColor: '#8a96b6',
  fajrTimeSize: 16, fajrTimeColor: '#b6c0da',
};

/* Defaults für die Infotext-/Hadith-Box (TV-Referenz-Pixel, 1920 px breit).
   arabisch groß, Übersetzung groß, Quelle bewusst kleiner (Aufgabe 4). */
const TE_INFO_DEFAULTS = {
  arFontSize: 48, arColor: '#c5a55a',
  nameFontSize: 34, nameColor: '#e8eefc',
  srcFontSize: 18, srcColor: '#8a96b6',
  bgOpacity: 55,
};

/* Welche Stil-Eigenschaften sind Fajr-exklusiv (werden beim Synchronisieren
   nicht auf andere Kacheln übertragen). */
const FAJR_ONLY_PROPS = [
  'fajrLabelSize','fajrLabelColor','fajrTimeSize','fajrTimeColor',
  'pos_fajrSub_x','pos_fajrSub_y'
];

function openTileEditor(tileEl, stageEl) {
  closeTileEditor();
  DS_SELECTED = tileEl.dataset.el;
  const id = DS_SELECTED;
  const isInfo = (id === 'info');
  const isClockId = (id === 'clock');
  const tileData = STAGE_TILES.find(t => t[0] === id);
  if (!isInfo && !isClockId && !tileData) return;

  const box = DS_OVERRIDE.elements[id] || {};
  const TE_CLOCK_DEFAULTS = { timeFontSize: 80, timeColor: '#f0ece0' };
  const defaults = (id === 'clock') ? TE_CLOCK_DEFAULTS
                 : isInfo ? TE_INFO_DEFAULTS : TE_DEFAULTS;
  const s = { ...defaults, ...(box.style || {}) };

  /* ── Element-Wrapper (jedes einzeln verschiebbar) ───────── */
  const mkEl = (cls, html, cursor) =>
    `<div class="te-el" data-te="${cls}" style="cursor:${cursor||'grab'}">${html}</div>`;

  let tileHTML, ctrls;

  const isClock = isClockId;

  if (isClock) {
    /* ── UHR (Anf. 2): vollwertiges Textelement ───────────────────────────
       Markup spiegelt die TV-Uhr (.time-big + .secs). Eigenschaften: Größe,
       Farbe, Position. Ausrichtung erfolgt über Drag + Snap-Linien wie bei
       allen anderen Elementen. */
    const cs = s;
    tileHTML =
      mkEl('ptime',
        '<span class="te-clock-txt"><span class="te-ptime-txt">12:45</span>' +
        '<span class="te-clock-secs">:00</span></span>');
    ctrls =
      '<div class="te-title" id="teTitle">Uhrzeit</div>' +
      '<div class="te-subhint" id="teSubHint">Die Uhr ist ein normales Textelement – Größe, Farbe und Position frei wählbar.</div>' +
      teGroup('Uhrzeit', [
        teSlider('timeFontSize', 'Größe', cs.timeFontSize, 20, 220, 'px'),
        teColor('timeColor', 'Farbe', cs.timeColor)
      ], 'ptime') +
      '<div class="te-btn-row">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';
  } else if (isInfo) {
    /* ── INFOTEXT / HADITH-BOX (Aufgabe 2) ─────────────────────
       Gleiches Editor-Prinzip wie bei den Gebets-Kacheln, aber mit
       Hadith-spezifischen Reglern. Die Vorschau zeigt den ECHTEN, vom
       Admin eingegebenen Inhalt (DS_INFO) – ohne Platzhalter. */
    const info = DS_INFO || {};
    const arabisch = String(info.arabisch || "").trim();
    const titel    = String(info.titel || "").trim();
    const text     = String(info.text || "").trim();
    const quelle   = String(info.quelle || "").trim();
    const leer = !hasInfoContent(info);

    const txtHTML = (titel ? '<b>' + esc(titel) + '</b> ' : '') + esc(text);
    tileHTML =
      mkEl('hArabic', '<span class="te-h-arabic" dir="rtl">' + (esc(arabisch) || '') + '</span>') +
      mkEl('hText',   '<span class="te-h-text">' + txtHTML + '</span>') +
      mkEl('hQuelle', '<span class="te-h-quelle">' + esc(quelle) + '</span>');

    ctrls =
      '<div class="te-title" id="teTitle">Infotext / Hadith</div>' +
      '<div class="te-subhint" id="teSubHint">Klicke ein Element an, um nur dessen Eigenschaften zu bearbeiten.</div>' +
      (leer
        ? '<div class="te-empty-note">Noch kein Infotext eingegeben.<br>' +
          'Lege im Reiter <b>✍️ Infotexte</b> einen Eintrag an – er erscheint dann hier ' +
          'live und kann gestaltet werden.</div>'
        : '') +
      teGroup('Arabischer Text', [
        teSlider('arFontSize', 'Größe', s.arFontSize, 10, 120, 'px'),
        teColor('arColor', 'Farbe', s.arColor)
      ], 'hArabic') +
      teGroup('Übersetzung (DE/AL)', [
        teSlider('nameFontSize', 'Größe', s.nameFontSize, 8, 90, 'px'),
        teColor('nameColor', 'Farbe', s.nameColor)
      ], 'hText') +
      teGroup('Quelle', [
        teSlider('srcFontSize', 'Größe', s.srcFontSize, 6, 50, 'px'),
        teColor('srcColor', 'Farbe', s.srcColor)
      ], 'hQuelle') +
      teGroup('Hintergrund (ganze Box)', [teSlider('bgOpacity', 'Deckkraft', s.bgOpacity, 0, 100, '%')], 'card') +
      '<div class="te-btn-row">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';
  } else {
    const [, nameDe, nameAr, time, key, sub] = tileData;
    const icon = TV_ICONS[key] || "";
    const label = key.charAt(0).toUpperCase() + key.slice(1);

    tileHTML =
      mkEl('icon', '<div class="te-icon-inner">' + icon + '</div>') +
      mkEl('nameDe', '<span class="te-name-de-txt">' + esc(nameDe) + '</span>') +
      mkEl('nameAr', '<span class="te-name-ar-txt">' + nameAr + '</span>') +
      mkEl('ptime', '<span class="te-ptime-txt">' + time + '</span>');
    if (sub) {
      tileHTML += mkEl('fajrSub',
        '<div class="te-fajr-sub-inner">' +
          '<div><span class="te-fsub-label">Beginn</span><span class="te-fsub-time">' + sub.beginn + '</span></div>' +
          '<div style="text-align:right"><span class="te-fsub-label">Aufgang</span><span class="te-fsub-time">' + sub.aufgang + '</span></div>' +
        '</div>');
    }

    /* ── Regler (pro Element gruppiert) ─────────────────────────
       v1.9 (Anf. 3): Jede Gruppe trägt data-sub = Name des Sub-Elements.
       Ein Klick auf ein Element im Canvas blendet nur dessen Gruppe(n) ein. */
    ctrls =
      '<div class="te-title" id="teTitle">' + esc(label) + '</div>' +
      '<div class="te-subhint" id="teSubHint">Klicke ein Element an, um nur dessen Eigenschaften zu bearbeiten.</div>' +
      teGroup('Symbol', [teSlider('iconScale', 'Größe', s.iconScale, 50, 250, '%')], 'icon') +
      teGroup('Name (DE)', [
        teSlider('nameFontSize', 'Größe', s.nameFontSize, 4, 60, 'px'),
        teColor('nameColor', 'Farbe', s.nameColor)
      ], 'nameDe') +
      teGroup('Name (AR)', [
        teSlider('arFontSize', 'Größe', s.arFontSize, 6, 60, 'px'),
        teColor('arColor', 'Farbe', s.arColor)
      ], 'nameAr') +
      teGroup('Uhrzeit', [
        teSlider('timeFontSize', 'Größe', s.timeFontSize, 8, 130, 'px'),
        teColor('timeColor', 'Farbe', s.timeColor)
      ], 'ptime') +
      teGroup('Hintergrund (ganze Kachel)', [teSlider('bgOpacity', 'Deckkraft', s.bgOpacity, 0, 100, '%')], 'card') +
      (sub ? teGroup('Beginn / Aufgang', [
        teSlider('fajrLabelSize', 'Label-Größe', s.fajrLabelSize, 4, 30, 'px'),
        teColor('fajrLabelColor', 'Label-Farbe', s.fajrLabelColor),
        teSlider('fajrTimeSize', 'Zeit-Größe', s.fajrTimeSize, 6, 50, 'px'),
        teColor('fajrTimeColor', 'Zeit-Farbe', s.fajrTimeColor),
      ], 'fajrSub') : '') +
      '<div class="te-btn-row te-btn-row-3">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn te-sync" data-action="sync">⟳ Sync</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';
  }

  /* ── Overlay aufbauen ───────────────────────────────────── */
  const overlay = document.createElement('div');
  overlay.className = 'te-overlay';
  overlay.innerHTML =
    '<div class="te-backdrop"></div>' +
    '<div class="te-glass">' +
      '<div class="te-left">' + ctrls + '</div>' +
      '<div class="te-right">' +
        '<div class="te-canvas">' +
          '<div class="te-card" id="teCard">' + tileHTML + '</div>' +
          '<svg class="te-guides" id="teGuides"></svg>' +
        '</div>' +
        '<div class="te-hint">Klick wählt ein Element · Drag verschiebt · Ausrichtungslinien helfen beim Zentrieren</div>' +
      '</div>' +
    '</div>';

  document.body.appendChild(overlay);
  dsEditorOverlay = overlay;
  teApplyAll(s);
  teRestorePositions(s);
  teInitDrag();

  /* Events – Backdrop-Klick schließt NICHT; nur ESC oder Buttons */

  overlay.querySelectorAll('input').forEach(inp => {
    inp.addEventListener('input', () => {
      const prop = inp.dataset.prop;
      const val = inp.type === 'color' ? inp.value : parseInt(inp.value);
      const vt = inp.parentElement.querySelector('.te-val');
      if (vt) vt.textContent = val + (prop === 'bgOpacity' || prop === 'iconScale' ? '%' : 'px');
      ensureStyle(DS_SELECTED)[prop] = val;
      teApplyAll(ensureStyle(DS_SELECTED));
      applyTileStylesTo(stageEl, DS_OVERRIDE.elements);
      teAutoCommit();
    });
  });

  overlay.querySelector('[data-action="reset"]').addEventListener('click', () => {
    clearTimeout(dsEditorCommitTimer);
    if (DS_OVERRIDE.elements[DS_SELECTED]) delete DS_OVERRIDE.elements[DS_SELECTED].style;
    applyTileStylesTo(stageEl, DS_OVERRIDE.elements);
    teClose(); commitOverride();
  });

  overlay.querySelector('[data-action="apply"]').addEventListener('click', () => {
    clearTimeout(dsEditorCommitTimer);
    teClose(); commitOverride();
  });

  /* Synchronisieren: Stil der aktuellen Kachel auf alle anderen übertragen.
     Fajr-exklusive Eigenschaften (Beginn/Aufgang) bleiben unberührt. */
  const syncBtn = overlay.querySelector('[data-action="sync"]');
  if (syncBtn) syncBtn.addEventListener('click', () => {
    if (!DS_SELECTED) return;
    const src = { ...(ensureStyle(DS_SELECTED)) };
    /* Fajr-exklusive Props entfernen bevor wir synchronisieren */
    FAJR_ONLY_PROPS.forEach(p => delete src[p]);
    /* Auf alle anderen Kacheln anwenden */
    STAGE_TILES.forEach(([tileId]) => {
      if (tileId === DS_SELECTED) return;
      const tgt = ensureStyle(tileId);
      Object.keys(src).forEach(k => {
        /* Fajr-exklusive Props am Ziel nicht überschreiben */
        if (tileId === 'tile_fajr' && FAJR_ONLY_PROPS.includes(k)) return;
        tgt[k] = src[k];
      });
    });
    applyTileStylesTo(stageEl, DS_OVERRIDE.elements);
    teAutoCommit();
    /* Kurzes visuelles Feedback */
    syncBtn.textContent = '✓ Synchronisiert';
    syncBtn.classList.add('te-sync-done');
    setTimeout(() => { syncBtn.textContent = '⟳ Sync'; syncBtn.classList.remove('te-sync-done'); }, 1200);
  });

  overlay._esc = e => { if (e.key === 'Escape') teClose(); };
  window.addEventListener('keydown', overlay._esc);
}

function teClose() {
  clearTimeout(dsEditorCommitTimer);
  if (dsEditorOverlay) {
    if (dsEditorOverlay._esc) window.removeEventListener('keydown', dsEditorOverlay._esc);
    dsEditorOverlay.remove(); dsEditorOverlay = null;
  }
  DS_SELECTED = null;
  TE_SUB = null;
  commitOverride();
}

function teAutoCommit() {
  clearTimeout(dsEditorCommitTimer);
  dsEditorCommitTimer = setTimeout(() => commitOverride(), 400);
}

/* ── Stile auf die 1:1-Kachel im Editor anwenden ────────────────────────── */
function teApplyAll(s) {
  if (!dsEditorOverlay) return;
  const c = dsEditorOverlay.querySelector('#teCard');
  if (!c) return;
  const d = { ...TE_DEFAULTS, ...s };

  const pt = c.querySelector('.te-ptime-txt');
  if (pt) { pt.style.fontSize = d.timeFontSize + 'px'; pt.style.color = d.timeColor; }

  /* Uhr-Sekunden proportional (~0,46) + Farbe erben, damit Editor=TV */
  const secs = c.querySelector('.te-clock-secs');
  if (secs && typeof d.timeFontSize === 'number') {
    secs.style.fontSize = (d.timeFontSize * 0.46).toFixed(1) + 'px';
  }

  const nd = c.querySelector('.te-name-de-txt');
  if (nd) { nd.style.fontSize = d.nameFontSize + 'px'; nd.style.color = d.nameColor; }

  const ar = c.querySelector('.te-name-ar-txt');
  if (ar) { ar.style.fontSize = d.arFontSize + 'px'; ar.style.color = d.arColor; }

  const ic = c.querySelector('.te-icon-inner');
  if (ic) ic.style.transform = 'scale(' + (d.iconScale / 100).toFixed(2) + ')';

  /* Fajr: Beginn/Aufgang Styles */
  c.querySelectorAll('.te-fsub-label').forEach(el => {
    el.style.fontSize = d.fajrLabelSize + 'px';
    el.style.color    = d.fajrLabelColor;
  });
  c.querySelectorAll('.te-fsub-time').forEach(el => {
    el.style.fontSize = d.fajrTimeSize + 'px';
    el.style.color    = d.fajrTimeColor;
  });

  c.style.backgroundColor = 'rgba(13,20,38,' + (d.bgOpacity / 100).toFixed(2) + ')';

  /* Infotext-/Hadith-Box im Editor (Aufgabe 2) */
  const hAr = c.querySelector('.te-h-arabic');
  if (hAr) { hAr.style.fontSize = d.arFontSize + 'px'; hAr.style.color = d.arColor; }
  const hTx = c.querySelector('.te-h-text');
  if (hTx) { hTx.style.fontSize = d.nameFontSize + 'px'; hTx.style.color = d.nameColor; }
  const hSrc = c.querySelector('.te-h-quelle');
  if (hSrc) { hSrc.style.fontSize = d.srcFontSize + 'px'; hSrc.style.color = d.srcColor; }
}

/* ── Positionen speichern / wiederherstellen ──────────────────────────────── */
function teSavePosition(elName, dx, dy) {
  if (!DS_SELECTED) return;
  const s = ensureStyle(DS_SELECTED);
  s['pos_' + elName + '_x'] = Math.round(dx);
  s['pos_' + elName + '_y'] = Math.round(dy);
}

function teRestorePositions(s) {
  if (!dsEditorOverlay) return;
  dsEditorOverlay.querySelectorAll('.te-el').forEach(el => {
    const n = el.dataset.te;
    const dx = s['pos_' + n + '_x'] || 0;
    const dy = s['pos_' + n + '_y'] || 0;
    el.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    el._dx = dx; el._dy = dy;
  });
}

/* ── Drag & Drop mit Ausrichtungslinien ───────────────────────────────────── */
function teInitDrag() {
  if (!dsEditorOverlay) return;
  const card = dsEditorOverlay.querySelector('#teCard');
  const svg  = dsEditorOverlay.querySelector('#teGuides');
  if (!card || !svg) return;

  const SNAP = 4;  // px Toleranz

  dsEditorOverlay.querySelectorAll('.te-el').forEach(el => {
    el._dx = el._dx || 0;
    el._dy = el._dy || 0;
    let startX, startY, startDx, startDy;

    el.addEventListener('pointerdown', e => {
      e.preventDefault(); e.stopPropagation();
      el.classList.add('te-dragging');
      startX = e.clientX; startY = e.clientY;
      startDx = el._dx; startDy = el._dy;
      let moved = false;

      const onMove = ev => {
        let dx = startDx + (ev.clientX - startX);
        let dy = startDy + (ev.clientY - startY);
        if (Math.abs(ev.clientX - startX) > 3 || Math.abs(ev.clientY - startY) > 3) moved = true;

        /* Snap-Guides */
        const cr = card.getBoundingClientRect();
        const er = el.getBoundingClientRect();
        const ew = er.width, eh = er.height;
        /* Element-Mitte relativ zur Karte */
        const ecx = (er.left - cr.left + ew / 2);
        const ecy = (er.top  - cr.top  + eh / 2);
        const ccx = cr.width / 2;
        const ccy = cr.height / 2;
        let guides = '';

        if (Math.abs(ecx - ccx) < SNAP) {
          dx += (ccx - ecx);
          guides += '<line x1="50%" y1="0" x2="50%" y2="100%" class="te-gl"/>';
        }
        if (Math.abs(ecy - ccy) < SNAP) {
          dy += (ccy - ecy);
          guides += '<line x1="0" y1="50%" x2="100%" y2="50%" class="te-gl"/>';
        }
        svg.innerHTML = guides;
        el._dx = dx; el._dy = dy;
        el.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
      };

      const onUp = () => {
        el.classList.remove('te-dragging');
        svg.innerHTML = '';
        if (moved) {
          teSavePosition(el.dataset.te, el._dx, el._dy);
          teAutoCommit();
        } else {
          /* v1.9 (Anf. 3): reiner Klick → nur dieses Element auswählen */
          teSelectSub(el.dataset.te);
        }
        window.removeEventListener('pointermove', onMove);
      };

      window.addEventListener('pointermove', onMove);
      window.addEventListener('pointerup', onUp, { once: true });
    });
  });
}

function closeTileEditor() { teClose(); }
function hideStylePanel() { closeTileEditor(); }

/* ════════════════════════════════════════════════════════════════════════════
   ELEMENT-AUSWAHL IM EDITOR  (v1.9 · Anf. 3)
   Klick auf ein Element im Canvas blendet links NUR dessen Eigenschaften ein.
   Hover-Hervorhebung & Verschieben bleiben unverändert. „card" (Hintergrund der
   ganzen Kachel/Box) wird nicht über ein Sub-Element ausgewählt, sondern bleibt
   sichtbar, solange nichts ausgewählt ist.
   ════════════════════════════════════════════════════════════════════════════ */

/* Anzeige-Namen für die Titelzeile */
const TE_SUB_LABELS = {
  icon: 'Symbol', nameDe: 'Name (DE)', nameAr: 'Name (AR)', ptime: 'Uhrzeit',
  fajrSub: 'Beginn / Aufgang', hArabic: 'Arabischer Text', hText: 'Übersetzung',
  hQuelle: 'Quelle'
};

function teSelectSub(sub) {
  if (!dsEditorOverlay) return;
  TE_SUB = sub;
  /* Canvas: ausgewähltes Element hervorheben */
  dsEditorOverlay.querySelectorAll('.te-el').forEach(el =>
    el.classList.toggle('te-selected', el.dataset.te === sub));
  /* Linkes Panel: nur passende Gruppe(n) zeigen. „card" (ganze Kachel) wird
     bei Element-Auswahl ausgeblendet, da es kein Sub-Element ist. */
  dsEditorOverlay.querySelectorAll('.te-grp[data-sub]').forEach(g => {
    g.style.display = (g.dataset.sub === sub) ? '' : 'none';
  });
  const hint = dsEditorOverlay.querySelector('#teSubHint');
  if (hint) {
    hint.innerHTML = 'Bearbeite: <b>' + esc(TE_SUB_LABELS[sub] || sub) + '</b> · ' +
      '<a href="#" class="te-showall">alle anzeigen</a>';
    const a = hint.querySelector('.te-showall');
    if (a) a.addEventListener('click', e => { e.preventDefault(); teShowAll(); });
  }
}

function teShowAll() {
  if (!dsEditorOverlay) return;
  TE_SUB = null;
  dsEditorOverlay.querySelectorAll('.te-el').forEach(el => el.classList.remove('te-selected'));
  dsEditorOverlay.querySelectorAll('.te-grp[data-sub]').forEach(g => { g.style.display = ''; });
  const hint = dsEditorOverlay.querySelector('#teSubHint');
  if (hint) hint.textContent = 'Klicke ein Element an, um nur dessen Eigenschaften zu bearbeiten.';
}

function ensureStyle(id) {
  if (!DS_OVERRIDE.elements[id]) DS_OVERRIDE.elements[id] = { ...OVERRIDE_DEFAULTS[id] };
  if (!DS_OVERRIDE.elements[id].style) DS_OVERRIDE.elements[id].style = {};
  return DS_OVERRIDE.elements[id].style;
}

function teGroup(title, rows, sub) {
  return '<div class="te-grp"' + (sub ? ' data-sub="' + sub + '"' : '') +
    '><span class="te-grp-label">' + esc(title) + '</span>' + rows.join('') + '</div>';
}
function teSlider(prop, label, val, min, max, unit) {
  return '<div class="te-row"><label>' + esc(label) + '</label>' +
    '<input type="range" data-prop="' + prop + '" min="' + min + '" max="' + max + '" value="' + val + '">' +
    '<span class="te-val">' + val + unit + '</span></div>';
}
function teColor(prop, label, val) {
  return '<div class="te-row"><label>' + esc(label) + '</label>' +
    '<input type="color" data-prop="' + prop + '" value="' + val + '"></div>';
}

/* Maßstab-Faktor: Vorschaubühne → TV. Alle px-Werte im Kachel-Stil-Editor
   beziehen sich auf die TV-Auflösung (1920 px breit). In der Vorschau werden
   sie mit diesem Faktor skaliert, damit die Proportionen stimmen. */
function tvScale(stageEl) {
  return (stageEl ? stageEl.offsetWidth : 780) / TV_REF_W;
}

/* Wendet pro-Kachel-Stile auf EINE Bühne an – mit maßstabsgetreuer
   Skalierung der Pixel-Angaben aus dem Kachel-Stil-Editor. */
function applyTileStylesTo(stageEl, elements) {
  if (!elements) return;
  const sc = tvScale(stageEl);
  /* v1.9 (Anf. 1): Positions-Offsets der Sub-Elemente exakt wie auf der TV
     anwenden (translate, mit demselben tvScale-Faktor). Bisher wurden pos_*
     in der Vorschau ignoriert — dadurch saßen verschobene Innenelemente im
     Editor anders als auf dem TV. */
  const off   = v => (typeof v === 'number' ? v : 0) * sc;
  const trans = (x, y) => (x || y) ? 'translate(' + off(x).toFixed(1) + 'px,' + off(y).toFixed(1) + 'px)' : '';
  stageEl.querySelectorAll('.ds-el').forEach(el => {
    const id = el.dataset.el;
    const sty = (elements[id] && elements[id].style) || null;

    /* v1.9 (Anf. 2): Uhr als vollwertiges Textelement. Markup der Editor-Uhr:
       12<span class="ds-blink">:</span>45 in .ds-clock — wir stylen den
       gesamten Uhr-Container als „Zeit". */
    const isClock = el.classList.contains('ds-clock');
    const timeEl = isClock ? el
                 : (el.querySelector('.ds-ptime') || el.querySelector('b'));
    const nameEl = el.querySelector('.ds-name-de') || el.querySelector('span:not(.ds-rs):not(.ds-blink)');
    const arEl   = el.querySelector('.ds-name-ar');
    const iconEl = el.querySelector('.ds-icon');
    if (timeEl) {
      timeEl.style.fontSize = sty && sty.timeFontSize ? (sty.timeFontSize * sc).toFixed(1) + 'px' : '';
      timeEl.style.color    = sty && sty.timeColor    ? sty.timeColor : '';
      /* Innere Verschiebung nur für Kachel-Uhrzeit, NICHT für den Uhr-Container
         (dessen Position regelt die Box selbst — sonst doppelter Versatz). */
      timeEl.style.transform = (!isClock && sty) ? trans(sty.pos_ptime_x, sty.pos_ptime_y) : '';
    }
    if (nameEl) {
      nameEl.style.fontSize = sty && sty.nameFontSize ? (sty.nameFontSize * sc).toFixed(1) + 'px' : '';
      nameEl.style.color    = sty && sty.nameColor    ? sty.nameColor : '';
      nameEl.style.transform = sty ? trans(sty.pos_nameDe_x, sty.pos_nameDe_y) : '';
    }
    if (arEl) {
      arEl.style.fontSize = sty && sty.arFontSize ? (sty.arFontSize * sc).toFixed(1) + 'px' : '';
      arEl.style.color    = sty && sty.arColor    ? sty.arColor : '';
      arEl.style.transform = sty ? trans(sty.pos_nameAr_x, sty.pos_nameAr_y) : '';
    }
    if (iconEl) {
      /* v1.8 (Anf. 5d): iconScale immer setzen (Default 130) — gleiche
         Datenbindung & Basis wie die TV-Anzeige, daher 1:1-Vorschau.
         v1.9: zusätzlich pos_icon_* als Offset (wie auf dem TV). */
      const isc = (sty && typeof sty.iconScale === 'number') ? sty.iconScale : 130;
      const it  = sty ? trans(sty.pos_icon_x, sty.pos_icon_y) : '';
      iconEl.style.transform = 'scale(' + (isc / 100).toFixed(2) + ')' + (it ? ' ' + it : '');
    }
    /* Info/Hadith-Box: arabischer Text, Übersetzung, Quelle getrennt stylen */
    if (el.classList.contains('ds-info')) {
      const hAr  = el.querySelector('.ds-hadith-arabic');
      const hTx  = el.querySelector('.ds-hadith-text');
      const hSrc = el.querySelector('.ds-hadith-quelle');
      if (hAr) {
        hAr.style.fontSize = sty && sty.arFontSize ? (sty.arFontSize * sc).toFixed(1) + 'px' : '';
        hAr.style.color    = sty && sty.arColor    ? sty.arColor : '';
      }
      if (hTx) {
        hTx.style.fontSize = sty && sty.nameFontSize ? (sty.nameFontSize * sc).toFixed(1) + 'px' : '';
        hTx.style.color    = sty && sty.nameColor    ? sty.nameColor : '';
      }
      if (hSrc) {
        hSrc.style.fontSize = sty && sty.srcFontSize ? (sty.srcFontSize * sc).toFixed(1) + 'px' : '';
        hSrc.style.color    = sty && sty.srcColor    ? sty.srcColor : '';
      }
    }
    if (sty && typeof sty.bgOpacity === 'number' &&
        (el.classList.contains('ds-tile') || el.classList.contains('ds-info'))) {
      el.style.backgroundColor = 'rgba(13,20,38,' + (sty.bgOpacity / 100).toFixed(2) + ')';
    } else {
      el.style.backgroundColor = '';
    }
  });
}

/* Wendet Design (Blur/Deckkraft/Abdunklung) auf EINE Bühne an. */
function applyDesignTo(stageEl, design) {
  if (!stageEl) return;
  stageEl.style.setProperty("--tile-blur",  design.blur + "px");
  stageEl.style.setProperty("--tile-alpha", (design.opacity / 100).toFixed(2));
  const dk = stageEl.querySelector('[data-role="darken"]');
  if (dk) dk.style.opacity = (design.darken / 100).toFixed(2);
}

/* Hintergrundbild (oder Standard-Verlauf) auf EINE Bühne anwenden. */
function applyBgTo(stageEl, bgName) {
  if (!stageEl) return;
  const bg = stageEl.querySelector('[data-role="bg"]');
  if (!bg) return;
  if (bgName && DS_PI_BASE) {
    bg.style.backgroundImage =
      "url('" + DS_PI_BASE + "/mediathek/" + encodeURIComponent(bgName) + "?t=" + Date.now() + "')";
    bg.classList.remove("default");
  } else {
    bg.style.backgroundImage = "none";
    bg.classList.add("default");
  }
}

/* Wendet das Frei-Layout (Einzeln) auf EINE Bühne an. v1.8: Block-Modus entfernt. */
function applyLayoutTo(stageEl) {
  if (!stageEl) return;
  stageEl.classList.add("free");
  clearBlockLayoutOn(stageEl);
  applyOverrideTo(stageEl, DS_OVERRIDE.elements || {});
}

/* Block-Transform entfernen — im Frei-Modus positionieren die Kacheln direkt
   auf der Bühne; eine alte Block-Verschiebung würde sonst alles aus dem
   sichtbaren Bereich schieben (overflow:hidden). */
function clearBlockLayoutOn(stageEl) {
  const c = stageEl.querySelector('[data-role="content"]');
  if (!c) return;
  c.style.transform = "";
}

/* Hält eine Kachel-Box vollständig innerhalb der 16:9-Bühne (0–100 %). */
function clampElBox(box) {
  const w = clampNum(box.w, 3, 100);
  const h = clampNum(box.h, 3, 100);
  const result = {
    x: clampNum(box.x, 0, 100 - w),
    y: clampNum(box.y, 0, 100 - h),
    w, h,
  };
  if (box.style) result.style = box.style;
  return result;
}

function applyOverrideTo(stageEl, elements) {
  stageEl.querySelectorAll(".ds-el").forEach(el => {
    const id = el.dataset.el;
    const box = elements[id];
    if (box) {
      const b = clampElBox(box);
      el.style.position = "absolute";
      el.style.left   = b.x + "%";
      el.style.top    = b.y + "%";
      el.style.width  = b.w + "%";
      el.style.height = b.h + "%";
      el.style.margin = "0";
      el.style.display = "flex";
    } else {
      el.style.display = "none";
    }
  });
  applyTileStylesTo(stageEl, elements);
}

/* Studio-Bühne referenzieren (Dashboard läuft als iframe). */
function eachStage(fn) {
  [$("#dsStage")].forEach(s => { if (s) fn(s); });
}

/* Design/Layout/Hintergrund auf BEIDE Bühnen spiegeln (Realtime-Sync). */
function applyToBothStages() {
  eachStage(s => {
    applyDesignTo(s, DS_DESIGN);
    applyBgTo(s, DS_BG);
    applyLayoutTo(s);
    applyInfoPreview(s);
  });
}

/* ── Live-Infotext-Auflösung (Etappe 5) ────────────────────────────────────
   Ermittelt den TATSÄCHLICH anzuzeigenden Infotext – exakt nach derselben
   Rangfolge wie die TV-App (kiosk-logic.js currentInfotext):
       1. aktiver Termin-Event (Zeitfenster von/bis enthält jetzt)
       2. Pool aktiv  → erster ausgewählter Eintrag (stellvertretend)
       3. sonst        → der einzelne Infotext
   Gibt {titel,text,arabisch,quelle,kategorie} oder null zurück.
   So steht in der Studio-Vorschau NIE ein Platzhalter, sondern nur echter,
   vom Admin eingegebener Inhalt (Aufgabe 2). */
function parseEventTsJS(v) {
  if (!v) return null;
  const m = String(v).trim().replace(" ", "T")
    .match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (!m) return null;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], 0).getTime();
}

function resolveActiveEvent(events) {
  const now = Date.now();
  for (const ev of (events || [])) {
    if (!ev || ev.aktiv === false) continue;
    if (!ev.titel && !ev.text && !ev.arabisch) continue;
    const von = parseEventTsJS(ev.von);
    const bis = parseEventTsJS(ev.bis);
    if (von !== null && now < von) continue;
    if (bis !== null && now > bis) continue;
    return ev;
  }
  return null;
}

function hasInfoContent(o) {
  return !!(o && (String(o.titel || "").trim() ||
                  String(o.text || "").trim() ||
                  String(o.arabisch || "").trim()));
}

/* Aus einer Pi-Config (oder normalisierten Struktur) den Live-Infotext lösen. */
function resolveInfoFromConfig(c) {
  if (!c) return null;
  const ev = resolveActiveEvent(c.events);
  if (ev) return ev;
  const pool = c.pool || {};
  if (pool.aktiv && Array.isArray(pool.eintraege) && pool.eintraege.length) {
    const e = pool.eintraege.find(hasInfoContent);
    if (e) return e;
  }
  if (hasInfoContent(c.infotext)) return c.infotext;
  return null;
}

/* Aus der lokalen Bibliothek (Manager-Datenstand) lösen – Fallback, wenn der
   Pi offline ist oder noch nichts gesendet wurde. Spiegelt send_live(). */
function resolveInfoFromLibrary(lib) {
  if (!lib) return null;
  const ev = resolveActiveEvent(lib.events);
  if (ev) return ev;
  const texte = lib.texte || [];
  const byId = {};
  texte.forEach(t => { if (t && t.id) byId[t.id] = t; });
  const pool = lib.pool || {};
  const auswahl = pool.auswahl || [];
  if (auswahl.length) {
    const first = byId[auswahl[0]];
    if (hasInfoContent(first)) return first;
  }
  return null;
}

/* Füllt die .ds-info-Box einer Bühne mit dem echten Infotext oder blendet sie
   aus, wenn nichts eingegeben wurde. KEIN Platzhalter. */
function applyInfoPreview(stageEl) {
  if (!stageEl) return;
  const box = stageEl.querySelector('.ds-info');
  if (!box) return;
  const rs = box.querySelector('.ds-rs');
  const info = DS_INFO;
  const arEl  = box.querySelector('.ds-hadith-arabic');
  const txEl  = box.querySelector('.ds-hadith-text');
  const srcEl = box.querySelector('.ds-hadith-quelle');
  if (!hasInfoContent(info)) {
    box.dataset.empty = "1";
    if (arEl)  arEl.textContent  = "";
    if (txEl)  txEl.textContent  = "";
    if (srcEl) srcEl.textContent = "";
    // Im gesperrten/Block-Modus ganz ausblenden; im Frei-Modus Position halten,
    // aber leer lassen, damit der Admin die (leere) Box noch platzieren kann.
    if (DS_MODE !== "free") box.style.display = "none";
    return;
  }
  box.dataset.empty = "0";
  if (DS_MODE !== "free") box.style.display = "";
  const arabisch = String(info.arabisch || "").trim();
  const titel    = String(info.titel || "").trim();
  const text     = String(info.text || "").trim();
  const quelle   = String(info.quelle || "").trim();
  // Übersetzungs-Block: Titel (fett) + Text
  if (arEl) { arEl.textContent = arabisch; arEl.style.display = arabisch ? "" : "none"; }
  if (txEl) {
    txEl.innerHTML = (titel ? '<b>' + esc(titel) + '</b> ' : '') + esc(text);
    txEl.style.display = (titel || text) ? "" : "none";
  }
  if (srcEl) { srcEl.textContent = quelle; srcEl.style.display = quelle ? "" : "none"; }
  if (rs) box.appendChild(rs);
}


/* Holt den aktuellen Stand vom Pi und spiegelt ihn in beide Vorschauen.
   Gemeinsam genutzt von Dashboard-Refresh, Studio-Laden und nach jedem
   Senden (reloadPreview). */
async function pullPreviewState() {
  try { DS_PI_BASE = await pywebview.api.pi_base_url(); } catch (e) {}
  let piInfo = null;
  if (PI_ONLINE) {
    try {
      const r = await pywebview.api.get_pi_config();
      if (r && r.ok && r.config) {
        const c = r.config;
        if (c.design) DS_DESIGN = {
          blur:    num(c.design.blur, 12),
          opacity: num(c.design.opacity, 55),
          darken:  num(c.design.darken, 30),
        };
        DS_BG = c.background || null;
        const ov = c.override_layout;
        if (ov && ov.enabled && ov.elements && Object.keys(ov.elements).length) {
          DS_OVERRIDE = { enabled: true, elements: ov.elements };
          Object.keys(DS_OVERRIDE.elements).forEach(k => {
            DS_OVERRIDE.elements[k] = clampElBox(DS_OVERRIDE.elements[k]);
          });
        } else {
          /* v1.8 (Anf. 6): Kein gespeichertes Einzel-Layout → Standard-Boxen als
             Startpunkt, damit der Editor sofort die frei platzierbaren Kacheln
             zeigt. Wird erst beim ersten Bearbeiten/Speichern an die TV gesendet. */
          if (!DS_OVERRIDE.elements || !Object.keys(DS_OVERRIDE.elements).length) {
            DS_OVERRIDE = { enabled: true, elements: defaultOverrideElements() };
          } else {
            DS_OVERRIDE.enabled = true;
          }
        }
        piInfo = resolveInfoFromConfig(c);
      }
    } catch (e) {}
  }
  // Infotext für die Vorschau: bevorzugt das, was wirklich auf dem Pi liegt;
  // sonst (offline / noch nichts gesendet) der lokale Bibliotheks-Stand.
  if (hasInfoContent(piInfo)) {
    DS_INFO = piInfo;
  } else {
    try {
      const lib = await pywebview.api.get_library();
      DS_INFO = resolveInfoFromLibrary(lib);
    } catch (e) { DS_INFO = piInfo; }
  }
  // v1.8 (Anf. 6): „Einzeln" ist Standard — auch offline/ohne gespeichertes
  // Layout immer frei platzierbare Default-Kacheln zeigen (nie leere Bühne).
  if (!DS_OVERRIDE.elements || !Object.keys(DS_OVERRIDE.elements).length) {
    DS_OVERRIDE = { enabled: true, elements: defaultOverrideElements() };
  } else {
    DS_OVERRIDE.enabled = true;
  }
  syncModeButtons();
  applyToBothStages();
}

/* Gemeinsame Live-Uhr für alle .ds-clock in beiden Vorschauen. */
let DS_CLOCK_TIMER = null;
function startStageClock() {
  if (DS_CLOCK_TIMER) return;
  const tick = () => {
    const d = new Date();
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    const blink = d.getSeconds() % 2 === 0 ? "" : "ds-dim";
    document.querySelectorAll(".ds-clock").forEach(el => {
      const rs = el.querySelector(".ds-rs");
      el.innerHTML = hh + '<span class="ds-blink ' + blink + '">:</span>' + mm;
      if (rs) el.appendChild(rs);
    });
  };
  tick();
  DS_CLOCK_TIMER = setInterval(tick, 1000);
}

/* Beim Programmstart aufgerufen: Studio-Bühne aufbauen + Uhr starten.
   Dashboard-Vorschau läuft als skalierter iframe der echten TV-Seite. */
function initStages() {
  mountStage($("#dsStage"),   true);    // Studio: bearbeitbar
  startStageClock();
  initDashIframe();
}

/* ── Dashboard-iframe (skalierte Echtzeit-Miniatur der TV-Seite) ────────── */
function initDashIframe() {
  const iframe = $("#dashIframe");
  if (!iframe) return;
  scaleDashIframe();
  window.addEventListener("resize", scaleDashIframe);
}

/* Passt die CSS-Skalierung des 1920×1080-iframes an die aktuelle Container-
   Größe an, damit er pixelgenau in den TV-Rahmen passt. */
function scaleDashIframe() {
  const iframe = $("#dashIframe");
  if (!iframe) return;
  const container = iframe.parentElement;         // .tv-screen
  if (!container) return;
  const cw = container.clientWidth;
  const ch = container.clientHeight;
  const s = Math.min(cw / 1920, ch / 1080);
  iframe.style.transform = "scale(" + s + ")";
}

function loadDashIframe() {
  const iframe = $("#dashIframe");
  if (!iframe || !DS_PI_BASE) return;
  const url = DS_PI_BASE + "/takvim-app/Takvim-App.html";
  if (iframe.src !== url) iframe.src = url;
  else iframe.contentWindow.location.reload();
  scaleDashIframe();
}

/* ---- reine, testbare Helfer (auch in der Node-Testdatei gespiegelt) ------- */
const DS_TILE_DARK_LUM = 0.0086;               // Luminanz von rgba(13,20,38)

function dsAspectInfo(w, h) {
  if (!w || !h) return { ratio: null, is169: false, label: "Maße unbekannt" };
  const ratio = w / h;
  const is169 = Math.abs(ratio - 16 / 9) <= 0.06;   // ~ ±1 %
  return { ratio, is169, label: w + "×" + h + " (" + ratio.toFixed(2) + ":1)" };
}

function dsRelLum(r, g, b) {
  const f = c => { c /= 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
  return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b);
}

/* Modell: weiße Kachelschrift auf halbtransparenter dunkler Kachel über
   (abgedunkeltem) Hintergrund. Liefert WCAG-Kontrastverhältnis. */
function dsContrastModel(bgLum, darkenPct, opacityPct) {
  const darken = Math.max(0, Math.min(1, darkenPct / 100));
  const alpha  = Math.max(0, Math.min(1, opacityPct / 100));
  const effBg  = bgLum * (1 - darken);
  const tileLum = DS_TILE_DARK_LUM * alpha + effBg * (1 - alpha);
  const cr = (1.0 + 0.05) / (tileLum + 0.05);     // weißer Text (Lum 1.0)
  return { tileLum, cr };
}

function dsAutoOptimize(bgLum, target) {
  target = target || 4.5;
  let darken = DS_DESIGN.darken, opacity = DS_DESIGN.opacity;
  // 1) Abdunklung erhöhen
  while (darken < 85 && dsContrastModel(bgLum, darken, opacity).cr < target) darken += 5;
  // 2) reicht nicht -> Deckkraft erhöhen
  while (opacity < 90 && dsContrastModel(bgLum, darken, opacity).cr < target) opacity += 5;
  return { darken: Math.min(85, darken), opacity: Math.min(90, opacity) };
}

function dsContrastRating(cr) {
  if (cr >= 4.5) return { cls: "ok",   txt: "Gut lesbar" };
  if (cr >= 3.0) return { cls: "warn", txt: "Grenzwertig" };
  return { cls: "err", txt: "Schlecht lesbar" };
}

/* ---- Initialisierung der Bedienelemente ----------------------------------- */
function initDesignStudio() {
  // Slider
  ["Blur", "Opacity", "Darken"].forEach(key => {
    const el = $("#ds" + key);
    el.addEventListener("input", onDesignSliderInput);
    el.addEventListener("change", onDesignSliderCommit);
  });

  // Upload
  const drop = $("#dsDropArea"), inp = $("#dsFileInput");
  drop.addEventListener("click", () => inp.click());
  drop.addEventListener("dragover", e => { e.preventDefault(); drop.classList.add("drag-over"); });
  drop.addEventListener("dragleave", () => drop.classList.remove("drag-over"));
  drop.addEventListener("drop", e => {
    e.preventDefault(); drop.classList.remove("drag-over");
    if (e.dataTransfer.files[0]) handleMediaFile(e.dataTransfer.files[0]);
  });
  inp.addEventListener("change", () => {
    if (inp.files[0]) handleMediaFile(inp.files[0]);
    inp.value = "";
  });
  $("#dsUploadCancel").addEventListener("click", resetMediaUpload);
  $("#dsUploadSend").addEventListener("click", sendMediaUpload);

  // Edit-Mode (Entsperrt/Gesperrt) & Reset — bleiben funktionsfähig (Anf. 6)
  $("#dsLockBtn").addEventListener("click", toggleEditMode);
  $("#dsLayoutReset").addEventListener("click", resetLayout);
  initStageEditing();
  initPresetManager();

  // Kontrast
  $("#dsAnalyzeBtn").addEventListener("click", analyzeContrast);
  $("#dsAutoBtn").addEventListener("click", applyAutoOptimize);
}

/* ---- Laden beim Öffnen des Panels ----------------------------------------- */
async function loadDesignStudio() {
  const off = $("#dsOffline");
  off.classList.toggle("hidden", PI_ONLINE);

  // Aktuellen Stand (Design, Hintergrund, Layout, Override) vom Pi holen und
  // in beide Vorschauen spiegeln (gemeinsame Komponente).
  await pullPreviewState();

  syncSlidersFromState();
  await refreshGallery();
  await loadPresets();        // Preset-Liste & Button-Zustand aktualisieren (Anf. 7)
}

function num(v, d) { return (typeof v === "number" && isFinite(v)) ? v : d; }

/* ---- Slider --------------------------------------------------------------- */
function syncSlidersFromState() {
  $("#dsBlur").value    = DS_DESIGN.blur;
  $("#dsOpacity").value = DS_DESIGN.opacity;
  $("#dsDarken").value  = DS_DESIGN.darken;
  updateSliderLabels();
}
function updateSliderLabels() {
  $("#dsBlurVal").textContent    = DS_DESIGN.blur + " px";
  $("#dsOpacityVal").textContent = DS_DESIGN.opacity + " %";
  $("#dsDarkenVal").textContent  = DS_DESIGN.darken + " %";
}
function onDesignSliderInput() {
  DS_DESIGN.blur    = parseInt($("#dsBlur").value, 10);
  DS_DESIGN.opacity = parseInt($("#dsOpacity").value, 10);
  DS_DESIGN.darken  = parseInt($("#dsDarken").value, 10);
  updateSliderLabels();
  applyStageDesign();        // sofortige Vorschau (beide Bühnen)
}
function onDesignSliderCommit() {
  clearTimeout(dsDesignTimer);
  dsDesignTimer = setTimeout(commitDesign, 120);
}
async function commitDesign() {
  if (!PI_ONLINE) { return; }
  try {
    const r = await pywebview.api.set_design({ ...DS_DESIGN });
    if (r && r.ok) reloadPreview();
  } catch (e) {}
}

/* Design auf BEIDE Vorschauen anwenden (geteilte Komponente). */
function applyStageDesign() {
  eachStage(s => applyDesignTo(s, DS_DESIGN));
}

/* ---- Anordnung (Einzeln) — Readout ---------------------------------------- */
function applyStageLayout() {
  eachStage(s => applyLayoutTo(s));
  const n = Object.keys(DS_OVERRIDE.elements || {}).length;
  const ro = $("#dsLayoutReadout");
  if (ro) ro.textContent = "Einzeln · " + n + " Elemente frei platziert";
}

/* v1.8 (Anf. 6): Kein Modus-Umschalter mehr. Stellt nur sicher, dass die Bühne
   im (einzigen) Frei-Modus läuft und der Hinweistext passt. */
function syncModeButtons() {
  const stage = $("#dsStage");
  if (stage) stage.classList.add("free");
  const hint = stage && stage.querySelector('[data-role="edithint"]');
  if (hint) hint.textContent =
    "🔓 Jede Kachel einzeln ziehen · Ecke unten rechts skalieren · Doppelklick zum Gestalten";
}

function toggleEditMode() {
  DS_UNLOCKED = !DS_UNLOCKED;
  if (!DS_UNLOCKED) hideStylePanel();
  const btn = $("#dsLockBtn");
  btn.dataset.unlocked = String(DS_UNLOCKED);
  btn.querySelector(".ds-lock-ico").textContent = DS_UNLOCKED ? "🔓" : "🔒";
  btn.querySelector(".ds-lock-txt").textContent = DS_UNLOCKED ? "Entsperrt" : "Gesperrt";
  $("#dsStage").classList.toggle("editing", DS_UNLOCKED);
}

/* Reset: Anordnung & Stile auf die Standard-Boxen zurücksetzen (Anf. 6 — bleibt
   funktionsfähig) und sofort an die TV senden. */
async function resetLayout() {
  DS_OVERRIDE = { enabled: true, elements: defaultOverrideElements() };
  applyStageLayout();
  await commitOverride();
}

/* ---- Bearbeitung auf der Studio-Bühne ------------------------------------- */
/* v1.8 (Anf. 6): Nur noch Frei-Modus — jede Kachel einzeln & vollständig
   entkoppelt. Das Bewegen/Skalieren einer Kachel verändert keine andere. */
function initStageEditing() {
  const stage = $("#dsStage");
  if (!stage) return;
  let mode = null;          // "el-drag" | "el-resize"
  let startX = 0, startY = 0;
  let elId = null, startBox = null;

  const rect = () => stage.getBoundingClientRect();

  function beginEl(e, el, resize) {
    elId = el.dataset.el;
    startBox = { ...(DS_OVERRIDE.elements[elId] || OVERRIDE_DEFAULTS[elId] || { x: 10, y: 10, w: 20, h: 15 }) };
    DS_OVERRIDE.elements[elId] = startBox;
    startX = e.clientX; startY = e.clientY;
    mode = resize ? "el-resize" : "el-drag";
  }

  function onDown(e) {
    if (!DS_UNLOCKED) return;
    const rs = e.target.closest(".ds-rs");
    const el = e.target.closest(".ds-el");
    if (rs && el) { e.preventDefault(); e.stopPropagation(); beginEl(e, el, true); }
    else if (el)  { e.preventDefault(); e.stopPropagation(); beginEl(e, el, false); }
    else return;
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp, { once: true });
  }

  function onMove(e) {
    if (!mode) return;
    const r = rect();
    const dxPct = (e.clientX - startX) / r.width * 100;
    const dyPct = (e.clientY - startY) / r.height * 100;

    if (mode === "el-drag") {
      const raw = { ...startBox, x: startBox.x + dxPct, y: startBox.y + dyPct };
      const snapped = snapToGuides(elId, raw);
      DS_OVERRIDE.elements[elId] = clampElBox(snapped.box);
      renderGuides(stage, snapped.guides);
    } else if (mode === "el-resize") {
      DS_OVERRIDE.elements[elId] = clampElBox({
        ...startBox,
        w: startBox.w + dxPct,
        h: startBox.h + dyPct,
      });
    }
    applyStageLayout();
  }

  function onUp() {
    window.removeEventListener("pointermove", onMove);
    clearGuides(stage);
    const was = mode; mode = null;
    if (!was) return;
    commitOverride();
  }

  stage.addEventListener("pointerdown", onDown);

  /* Doppelklick öffnet den Kachel-Editor (Fullscreen-Overlay) */
  stage.addEventListener("dblclick", e => {
    if (!DS_UNLOCKED) return;
    const el = e.target.closest(".ds-el");
    if (!el) return;
    e.preventDefault();
    openTileEditor(el, stage);
  });
}

function clampNum(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

async function commitOverride() {
  if (!PI_ONLINE) {
    setResult("#dsLayoutResult", "err", "Pi nicht verbunden — Anordnung lokal gemerkt, aber nicht gesendet.");
    return;
  }
  try {
    const r = await pywebview.api.set_override_layout({ enabled: true, elements: DS_OVERRIDE.elements });
    if (r && r.ok) { setResult("#dsLayoutResult", "ok", "✓ Einzel-Anordnung auf den TV übertragen."); reloadPreview(); }
    else setResult("#dsLayoutResult", "err", (r && r.error) || "Fehler beim Senden");
  } catch (e) { setResult("#dsLayoutResult", "err", "Fehler: " + (e.message || e)); }
}

/* ════════════════════════════════════════════════════════════════════════════
   PRESET-MANAGER (v1.8 · Anf. 7)
   Speichert/lädt komplette UI-Konfigurationen (Hintergrund, Design-Regler,
   Einzel-Anordnung inkl. Kachel-Stile). Anwenden überträgt alles in EINEM
   gemergten /api/config-POST an den Pi und aktualisiert anschließend die
   Vorschauen aus dem dann gültigen Pi-Stand.
   ════════════════════════════════════════════════════════════════════════════ */
let DS_PRESETS = [];

function initPresetManager() {
  const save  = $("#dsPresetSave");
  const apply = $("#dsPresetApply");
  const del   = $("#dsPresetDelete");
  const sel   = $("#dsPresetSelect");
  if (save)  save.addEventListener("click", savePreset);
  if (apply) apply.addEventListener("click", applyPreset);
  if (del)   del.addEventListener("click", deletePreset);
  if (sel)   sel.addEventListener("change", onPresetSelectChange);
  loadPresets();
}

async function loadPresets() {
  try {
    const r = await pywebview.api.list_presets();
    DS_PRESETS = (r && r.ok && Array.isArray(r.presets)) ? r.presets : [];
  } catch (e) { DS_PRESETS = []; }
  renderPresetSelect();
}

function renderPresetSelect() {
  const sel = $("#dsPresetSelect");
  if (!sel) return;
  const prev = sel.value;
  sel.innerHTML = '<option value="">— Preset wählen —</option>' +
    DS_PRESETS.map(p => '<option value="' + esc(p.id) + '">' + esc(p.name) + '</option>').join("");
  if (DS_PRESETS.some(p => p.id === prev)) sel.value = prev;
  onPresetSelectChange();
}

function onPresetSelectChange() {
  const sel = $("#dsPresetSelect");
  const has = !!(sel && sel.value);
  const apply = $("#dsPresetApply"), del = $("#dsPresetDelete");
  if (apply) apply.disabled = !has || !PI_ONLINE;
  if (del)   del.disabled = !has;
}

async function savePreset() {
  const inp = $("#dsPresetName");
  const name = (inp ? inp.value : "").trim();
  if (!name) {
    setResult("#dsPresetResult", "err", "Bitte einen Preset-Namen eingeben.");
    if (inp) inp.focus();
    return;
  }
  /* Aktuellen Editor-Stand als Snapshot mitsenden, damit exakt das gespeichert
     wird, was sichtbar/angeordnet ist (Kacheln, Hintergrund, Helligkeit). */
  const snapshot = {
    name: name,
    background: DS_BG || null,
    design: { ...DS_DESIGN },
    override_layout: { enabled: true, elements: DS_OVERRIDE.elements || {} },
  };
  setResult("#dsPresetResult", "", "Speichere…");
  try {
    const r = await pywebview.api.save_preset(snapshot);
    if (r && r.ok) {
      DS_PRESETS = r.presets || DS_PRESETS;
      if (inp) inp.value = "";
      renderPresetSelect();
      const sel = $("#dsPresetSelect");
      if (sel && r.id) { sel.value = r.id; onPresetSelectChange(); }
      setResult("#dsPresetResult", "ok", '✓ Preset „' + name + '" gespeichert.');
    } else {
      setResult("#dsPresetResult", "err", (r && r.error) || "Speichern fehlgeschlagen.");
    }
  } catch (e) { setResult("#dsPresetResult", "err", "Fehler: " + (e.message || e)); }
}

async function applyPreset() {
  const sel = $("#dsPresetSelect");
  const id = sel ? sel.value : "";
  if (!id) return;
  if (!PI_ONLINE) {
    setResult("#dsPresetResult", "err", "Pi nicht verbunden — Preset kann nicht angewendet werden.");
    return;
  }
  setResult("#dsPresetResult", "", "Wende an…");
  try {
    const r = await pywebview.api.apply_preset(id);
    if (r && r.ok) {
      // Editor-Stand vom Pi neu laden + beide Vorschauen aktualisieren
      await pullPreviewState();
      syncSlidersFromState();
      await refreshGallery();
      reloadPreview();
      const p = DS_PRESETS.find(x => x.id === id);
      setResult("#dsPresetResult", "ok", '✓ Preset „' + (p ? p.name : "") + '" auf den TV angewendet.');
    } else {
      setResult("#dsPresetResult", "err", (r && r.error) || "Anwenden fehlgeschlagen.");
    }
  } catch (e) { setResult("#dsPresetResult", "err", "Fehler: " + (e.message || e)); }
}

async function deletePreset() {
  const sel = $("#dsPresetSelect");
  const id = sel ? sel.value : "";
  if (!id) return;
  const p = DS_PRESETS.find(x => x.id === id);
  if (!confirm('Preset „' + (p ? p.name : id) + '" wirklich löschen?')) return;
  try {
    const r = await pywebview.api.delete_preset(id);
    if (r && r.ok) {
      DS_PRESETS = r.presets || [];
      renderPresetSelect();
      setResult("#dsPresetResult", "ok", "Preset gelöscht.");
    } else {
      setResult("#dsPresetResult", "err", (r && r.error) || "Löschen fehlgeschlagen.");
    }
  } catch (e) { setResult("#dsPresetResult", "err", "Fehler: " + (e.message || e)); }
}

/* ---- Mediathek-Galerie ---------------------------------------------------- */
async function refreshGallery() {
  const gal = $("#dsGallery");
  if (!PI_ONLINE) {
    gal.innerHTML = '<div class="lib-empty">TV offline — Mediathek nicht abrufbar.</div>';
    $("#dsMediaCount").textContent = "—";
    return;
  }
  let data;
  try { data = await pywebview.api.list_media(); }
  catch (e) { gal.innerHTML = '<div class="lib-empty">Fehler beim Laden der Mediathek.</div>'; return; }

  if (!data || !data.ok) {
    gal.innerHTML = '<div class="lib-empty">' + esc((data && data.error) || "Mediathek nicht abrufbar") + "</div>";
    return;
  }
  if (data.pi_base) DS_PI_BASE = data.pi_base;
  DS_BG = data.background || null;
  const files = data.files || [];
  $("#dsMediaCount").textContent = files.length + " Bild" + (files.length !== 1 ? "er" : "");

  if (!files.length) {
    gal.innerHTML = '<div class="lib-empty">Noch keine Bilder in der Mediathek.</div>';
    syncActiveBgIntoStage();
    return;
  }

  gal.innerHTML = files.map(f => {
    const active = (f.name === DS_BG);
    const asp = dsAspectInfo(f.w, f.h);
    const badge = (f.w && f.h)
      ? `<span class="ds-thumb-asp ${asp.is169 ? "" : "warn"}">${asp.is169 ? "16:9" : "kein 16:9"}</span>`
      : "";
    const src = DS_PI_BASE + "/mediathek/" + encodeURIComponent(f.name) + "?t=" + Date.now();
    return `<div class="ds-thumb ${active ? "active" : ""}" data-name="${esc(f.name)}">
      <div class="ds-thumb-img" style="background-image:url('${src}')">
        ${active ? '<span class="ds-thumb-active">● Aktiv</span>' : ""}
        ${badge}
      </div>
      <div class="ds-thumb-foot">
        <span class="ds-thumb-name" title="${esc(f.name)}">${esc(f.name)}</span>
        <button class="ds-thumb-del" data-name="${esc(f.name)}" title="Löschen">🗑</button>
      </div>
    </div>`;
  }).join("");

  gal.querySelectorAll(".ds-thumb-img").forEach(el => {
    el.addEventListener("click", () => setBackground(el.parentElement.dataset.name));
  });
  gal.querySelectorAll(".ds-thumb-del").forEach(b => {
    b.addEventListener("click", e => { e.stopPropagation(); deleteMedia(b.dataset.name); });
  });

  syncActiveBgIntoStage();
}

function syncActiveBgIntoStage() {
  eachStage(s => applyBgTo(s, DS_BG));
}

async function setBackground(name) {
  if (!PI_ONLINE) return;
  const neu = (name === DS_BG) ? null : name;     // erneuter Klick = abwählen
  try {
    const r = await pywebview.api.set_background(neu);
    if (r && r.ok) {
      DS_BG = neu;
      await refreshGallery();
      reloadPreview();
    }
  } catch (e) {}
}

async function deleteMedia(name) {
  if (!confirm('Bild „' + name + '" wirklich vom Pi löschen?')) return;
  try {
    const r = await pywebview.api.delete_media(name);
    if (r && r.ok) {
      if (r.cleared_background) DS_BG = null;
      await refreshGallery();
      reloadPreview();
    }
  } catch (e) {}
}

/* ---- Upload (mit 16:9-Prüfung im Browser) --------------------------------- */
function handleMediaFile(file) {
  setResult("#dsUploadResult", "", "");
  if (!/^image\//.test(file.type)) {
    setResult("#dsUploadResult", "err", "Bitte eine Bilddatei wählen (.jpg .png .webp .gif).");
    return;
  }
  if (file.size > 15 * 1024 * 1024) {
    setResult("#dsUploadResult", "err", "Bild ist zu groß (max. 15 MB).");
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    const dataUrl = e.target.result;
    const img = new Image();
    img.onload = () => {
      const asp = dsAspectInfo(img.naturalWidth, img.naturalHeight);
      DS_UPLOAD = { name: file.name, b64: dataUrl };
      const warn = asp.is169
        ? '<span class="ds-asp-ok">✓ 16:9</span>'
        : '<span class="ds-asp-warn">⚠️ kein 16:9 — kann auf dem TV beschnitten/verzerrt wirken</span>';
      $("#dsUploadPreview").innerHTML =
        `<div class="ds-up-thumb" style="background-image:url('${dataUrl}')"></div>
         <div class="ds-up-meta"><b>${esc(file.name)}</b><br>${asp.label} ${warn}</div>`;
      $("#dsUploadPreview").classList.remove("hidden");
      $("#dsUploadBtnRow").style.display = "flex";
    };
    img.onerror = () => setResult("#dsUploadResult", "err", "Bild konnte nicht gelesen werden.");
    img.src = dataUrl;
  };
  reader.onerror = () => setResult("#dsUploadResult", "err", "Datei konnte nicht gelesen werden.");
  reader.readAsDataURL(file);
}

function resetMediaUpload() {
  DS_UPLOAD = null;
  $("#dsUploadPreview").classList.add("hidden");
  $("#dsUploadPreview").innerHTML = "";
  $("#dsUploadBtnRow").style.display = "none";
  setResult("#dsUploadResult", "", "");
}

async function sendMediaUpload() {
  if (!DS_UPLOAD) return;
  if (!PI_ONLINE) { setResult("#dsUploadResult", "err", "Pi nicht verbunden."); return; }
  const btn = $("#dsUploadSend"); btn.disabled = true;
  setResult("#dsUploadResult", "", "Lade hoch…");
  try {
    const r = await pywebview.api.upload_media(DS_UPLOAD.name, DS_UPLOAD.b64);
    if (r && r.ok) {
      setResult("#dsUploadResult", "ok", "✓ Hochgeladen: " + r.name +
        (r.w ? " (" + r.w + "×" + r.h + ")" : ""));
      resetMediaUpload();
      await refreshGallery();
    } else {
      setResult("#dsUploadResult", "err", "✕ " + ((r && r.error) || "Upload fehlgeschlagen"));
    }
  } catch (e) {
    setResult("#dsUploadResult", "err", "Fehler: " + (e.message || e));
  }
  btn.disabled = false;
}

/* ---- Kontrast-Analyse ----------------------------------------------------- */
let DS_LAST_BGLUM = null;

function analyzeContrast() {
  const box = $("#dsContrastResult");
  box.classList.remove("hidden");
  if (!DS_BG) {
    DS_LAST_BGLUM = 0.045;     // Standard-Dunkelblau ist sehr dunkel
    renderContrast(DS_LAST_BGLUM, "Kein Bild gesetzt — Standard-Dunkelblau wird verwendet.");
    return;
  }
  if (!DS_PI_BASE) { box.innerHTML = '<div class="csv-pre-err">Pi-Adresse unbekannt.</div>'; return; }
  box.innerHTML = '<div class="hint" style="border:none;padding:0">Analysiere…</div>';

  const img = new Image();
  img.crossOrigin = "anonymous";
  img.onload = () => {
    try {
      const cv = $("#dsCanvas"), ctx = cv.getContext("2d");
      ctx.drawImage(img, 0, 0, cv.width, cv.height);
      // Kachelband etwa im unteren Drittel (dort liegen die Kacheln)
      const y0 = Math.floor(cv.height * 0.45), y1 = Math.floor(cv.height * 0.85);
      const d = ctx.getImageData(0, y0, cv.width, y1 - y0).data;
      let sum = 0, n = 0;
      for (let i = 0; i < d.length; i += 4) { sum += dsRelLum(d[i], d[i + 1], d[i + 2]); n++; }
      DS_LAST_BGLUM = n ? sum / n : 0.2;
      renderContrast(DS_LAST_BGLUM, "Hintergrund analysiert (Kachelbereich).");
    } catch (err) {
      $("#dsContrastResult").innerHTML =
        '<div class="csv-pre-err">Analyse nicht möglich (Bild nicht lesbar).</div>';
    }
  };
  img.onerror = () => {
    $("#dsContrastResult").innerHTML =
      '<div class="csv-pre-err">Bild konnte nicht geladen werden.</div>';
  };
  img.src = DS_PI_BASE + "/mediathek/" + encodeURIComponent(DS_BG) + "?t=" + Date.now();
}

function renderContrast(bgLum, note) {
  const { cr } = dsContrastModel(bgLum, DS_DESIGN.darken, DS_DESIGN.opacity);
  const rate = dsContrastRating(cr);
  const optimal = dsAutoOptimize(bgLum, 4.5);
  const needsAuto = cr < 4.5;
  $("#dsAutoBtn").classList.toggle("hidden", !needsAuto);
  const lumPct = (bgLum * 100).toFixed(1);
  $("#dsContrastResult").innerHTML =
    `<div class="ds-contrast-line ${rate.cls}">
       <b>${rate.txt}</b> · Kontrast ${cr.toFixed(1)}:1
     </div>
     <div class="ds-contrast-meter"><span class="ds-cm-fill ${rate.cls}" style="width:${Math.min(100, cr / 7 * 100).toFixed(0)}%"></span></div>
     <div class="hint" style="border:none;padding:6px 0 0">${esc(note)}
       <br>Gemessene Hintergrund-Helligkeit im Kachelbereich: <b>${lumPct} %</b>.
       ${needsAuto ? "<br>Vorschlag: Abdunklung " + optimal.darken + " % · Deckkraft "
         + optimal.opacity + " %." : "<br>Die aktuellen Einstellungen sind ausreichend."}
     </div>`;
  flashContrastOnTiles(rate.cls);
}

/* Sichtbares Feedback direkt auf den Kacheln der Vorschau (Bugfix 3):
   farbiger Ring (grün/gelb/rot) blinkt kurz an allen Kacheln auf. */
function flashContrastOnTiles(cls) {
  eachStage(stage => {
    stage.querySelectorAll(".ds-tile, .ds-info").forEach(el => {
      el.classList.remove("ds-cr-ok", "ds-cr-warn", "ds-cr-err", "ds-cr-flash");
      void el.offsetWidth;                       // Reflow erzwingen → Animation neu
      el.classList.add("ds-cr-" + cls, "ds-cr-flash");
    });
  });
  clearTimeout(flashContrastOnTiles._t);
  flashContrastOnTiles._t = setTimeout(() => {
    eachStage(stage => stage.querySelectorAll(".ds-tile, .ds-info").forEach(el =>
      el.classList.remove("ds-cr-flash")));
  }, 2400);
}

async function applyAutoOptimize() {
  if (DS_LAST_BGLUM == null) return;
  const opt = dsAutoOptimize(DS_LAST_BGLUM, 4.5);
  DS_DESIGN.darken  = opt.darken;
  DS_DESIGN.opacity = opt.opacity;
  syncSlidersFromState();
  applyStageDesign();
  await commitDesign();
  renderContrast(DS_LAST_BGLUM, "Auto-Optimierung angewendet und an den TV gesendet.");
}
