#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 TAKVIM-MANAGER v1.6  —  Büro-Tool (Laptop)                          Etappe 6
================================================================================
 Neu in Etappe 6 (Update-Installer + Notfall-Rollback):
   • In-App-Update (Modul 3.1):
       check_update()      -> Update-Quelle (Manifest-JSON) prüfen, Version vergl.
       download_update()   -> Update-ZIP in temp_update/ herunterladen (atomar)
       install_update()    -> Archiv prüfen, installer.bat abgekoppelt starten,
                              App beenden; installer.bat tauscht app/ aus
                              (Sperrzone data/ bleibt unberührt) und startet neu.
   • Notfall-Rollback (Modul 3.2):
       rollback_pi()       -> Express-Signal POST /api/rollback an den Pi:
                              dieser stellt backup_previous -> takvim-app her und
                              startet den Browser in < 5 s neu.
   • TV-Update an den Pi schieben (für das nächtliche Staged Update):
       push_tv_update()    -> ZIP an POST /api/update (landet in /updates/)
       get_pi_update_status() -> GET /api/update (Backup-/Update-Status des Pi)
================================================================================
 Etappe 4 (Design-Studio):
   • Mediathek (Bilder auf dem Pi):
       list_media()              -> GET  /api/media  (Galerie laden)
       upload_media(name, b64)   -> POST /api/media?name=…  (Bild hochladen)
       delete_media(name)        -> DELETE /api/media?name=…
   • Hintergrund & Design (in current_config.json des Pi, von der TV ausgewertet):
       get_pi_config()           -> GET  /api/config (für Slider-/Hintergrund-Stand)
       set_background(name|None)  -> POST /api/config {background}
       set_design({blur,opacity,darken}) -> POST /api/config {design}
       set_layout({x,y,scale})    -> POST /api/config {layout} (+ lokale Spiegelung)

 Neu in Etappe 2:
   • Infotext-Bibliothek (hadith_bibliothek.json):
       get_library()           -> gesamte Bibliothek laden
       save_text(eintrag)      -> Text hinzufügen / aktualisieren (nach id)
       delete_text(id)         -> Text löschen
       reorder_texts(ids)      -> Reihenfolge via Drag-Drop speichern
   • Pool-Verwaltung:
       set_pool(config)        -> Pool aktiv/inaktiv + Intervall + Auswahl
       send_live()             -> aktuellen Pool/Einzeltext sofort an Pi senden
   • Gebetszeiten-Import:
       import_csv_from_url(url)  -> CSV per URL laden + prüfen + an Pi senden
       import_csv_from_text(txt) -> CSV-Rohtext (aus Datei-Dialog) prüfen + senden
       preview_csv(txt)          -> nur prüfen, nicht senden (Vorschau-Schritt)
================================================================================
 Neu in Etappe 5 (Termin-Events + Vorprogrammierung):
   • Termin-Verwaltung:
       save_event(event)   -> Termin (mit von/bis) anlegen/aktualisieren
       delete_event(id)    -> Termin löschen
       (Termine liegen in hadith_bibliothek.json unter "events" und werden bei
        Änderung sofort an den Pi gesendet -> config.events[]; die TV-App lässt
        einen aktiven Termin den Infotext-Pool überholen und blendet ihn nach
        Ablauf selbst aus.)
   • send_live() überträgt zusätzlich die Termine (events) an den Pi.
   • Die Bibliothek ist mit einem Standard-Hadith vorprogrammiert.
   • set_override_layout() persistiert nun ALLE Kachel-Stilwerte (inkl.
     Arabisch/Quelle/Icon/Positionen) — Voraussetzung für die Hadith-Bearbeitung
     im Design-Studio (Etappe-5-Aufgabe 2). Zuvor wurden die meisten Stilwerte
     vor dem Senden verworfen.
================================================================================
"""
import base64
import binascii
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import urllib.request
import urllib.error
import uuid as _uuid

VERSION = "1.9.0"

# ── Basisverzeichnis ─────────────────────────────────────────────────────────
if getattr(sys, "frozen", False):
    BASE = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE = os.path.dirname(os.path.abspath(__file__))

APP_DIR    = os.path.join(BASE, "app")
DATA_DIR   = os.path.join(BASE, "data")
TEMP_DIR   = os.path.join(BASE, "temp_update")

CONFIG_FILE  = os.path.join(DATA_DIR, "config.json")
LIBRARY_FILE = os.path.join(DATA_DIR, "hadith_bibliothek.json")
PRESETS_FILE = os.path.join(DATA_DIR, "presets.json")   # NEU v1.8 (Anf. 7)

# NEU Etappe 6: Self-Update-Pfade
UPDATE_ZIP    = os.path.join(TEMP_DIR, "update.zip")
INSTALLER_BAT = os.path.join(BASE, "installer.bat")

DEFAULT_CONFIG = {
    "version": VERSION,
    "pi": {"ip": "", "port": 8080},
    "update": {"url": "", "check_on_start": True},
    "layout": {},
    "override_layout": None,
    "manager_lang": "de"      # Anzeigesprache des Managers selbst
}

DEFAULT_PRESETS = {"presets": []}   # NEU v1.8 (Anf. 7)

DEFAULT_LIBRARY = {
    "texte": [
        {
            "id": "6fb774ad",
            "titel": "Profeti Muhammed \uFDFA ka th\u00ebn\u00eb:",
            "text": "\u201cAllahut i m\u00ebshiron vet\u00ebm ata prej rob\u00ebrve t\u00eb Tij q\u00eb jan\u00eb t\u00eb m\u00ebshirsh\u00ebm.\u201d",
            "arabisch": "\u00ab\u0625\u0650\u0646\u0651\u064e\u0645\u064e\u0627 \u064a\u064e\u0631\u0652\u062d\u064e\u0645\u064f \u0627\u0644\u0644\u0651\u064e\u0647\u064f \u0645\u0650\u0646\u0652 \u0639\u0650\u0628\u064e\u0627\u062f\u0650\u0647\u0650 \u0627\u0644\u0631\u0651\u064f\u062d\u064e\u0645\u064e\u0627\u0621\u064e\u00bb",
            "kategorie": "Hadithe",
            "quelle": "Sahih Buhari, nr. 7376"
        }
    ],
    "pool": {"aktiv": False, "intervall": "30", "auswahl": ["6fb774ad"]},
    "events": []
}

KATEGORIEN = ["Allgemeine Info / Appell", "Hadithe", "Koran-Zitate", "Sonstiges"]


# ── Persistenz-Helfer ────────────────────────────────────────────────────────
def _atomic_write_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def _now_iso():
    """ISO-Zeitstempel (sekundengenau) für Preset-Metadaten."""
    from datetime import datetime as _dt
    return _dt.now().isoformat(timespec="seconds")


def _read_json(path, default):
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError
        return data
    except Exception:
        return json.loads(json.dumps(default))


def ensure_data():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(TEMP_DIR, exist_ok=True)
    if not os.path.isfile(CONFIG_FILE):
        _atomic_write_json(CONFIG_FILE, DEFAULT_CONFIG)
    if not os.path.isfile(LIBRARY_FILE):
        _atomic_write_json(LIBRARY_FILE, DEFAULT_LIBRARY)
    if not os.path.isfile(PRESETS_FILE):
        _atomic_write_json(PRESETS_FILE, DEFAULT_PRESETS)


# ── Validierung Design/Override (NEU v1.8 · zentral, von set_design,
#    set_override_layout UND dem Preset-Manager wiederverwendet) ───────────────
_OVERRIDE_STYLE_KEYS = (
    "timeFontSize", "timeColor",
    "nameFontSize", "nameColor",
    "arFontSize", "arColor",
    "iconScale", "bgOpacity",
    "fajrLabelSize", "fajrLabelColor",
    "fajrTimeSize", "fajrTimeColor",
    "srcFontSize", "srcColor",
    "transFontSize", "transColor",
)


def _clean_design_obj(design):
    """Klemmt die drei Design-Regler. blur 0–40 px, opacity/darken 0–100 %."""
    def _c(v, lo, hi, d):
        try:
            return max(lo, min(hi, int(round(float(v)))))
        except (TypeError, ValueError):
            return d
    design = design if isinstance(design, dict) else {}
    return {
        "blur":    _c(design.get("blur"),    0, 40,  12),
        "opacity": _c(design.get("opacity"), 0, 100, 55),
        "darken":  _c(design.get("darken"),  0, 100, 30),
    }


def _clean_override_obj(override):
    """Validiert das freie Pro-Element-Layout. Gibt {enabled,elements} oder None."""
    def _cf(v, lo, hi, d):
        try:
            return max(lo, min(hi, round(float(v), 2)))
        except (TypeError, ValueError):
            return d
    if not (isinstance(override, dict) and override.get("enabled")):
        return None
    els = {}
    src = override.get("elements") or {}
    if isinstance(src, dict):
        for key, box in src.items():
            if not isinstance(box, dict):
                continue
            key = str(key)[:32]
            w = _cf(box.get("w"), 3, 100, 20)
            h = _cf(box.get("h"), 3, 100, 15)
            entry = {
                "x": _cf(box.get("x"), 0, 100 - w, 0),
                "y": _cf(box.get("y"), 0, 100 - h, 0),
                "w": w,
                "h": h,
            }
            sty = box.get("style")
            if isinstance(sty, dict) and sty:
                entry["style"] = {
                    k: v for k, v in sty.items()
                    if k in _OVERRIDE_STYLE_KEYS or str(k).startswith("pos_")
                }
            els[key] = entry
    return {"enabled": True, "elements": els}


# ── CSV-Helfer (lokal, ohne Pi) ──────────────────────────────────────────────
def _analyse_csv(text):
    """
    Prüft CSV-Inhalt auf gültige Datumszeilen (dd.mm.yyyy in Spalte 0).
    Gibt {"ok", "rows", "first", "last", "error"} zurück.
    """
    from datetime import datetime as dt
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    data_rows = []
    for line in lines:
        parts = line.split(",")
        if not parts:
            continue
        cell = parts[0].strip().strip('"')
        if len(cell) == 10 and cell[2] == "." and cell[5] == ".":
            try:
                dt.strptime(cell, "%d.%m.%Y")
                data_rows.append(cell)
            except ValueError:
                continue
    if not data_rows:
        return {"ok": False, "rows": 0, "first": None, "last": None,
                "error": "Keine gültigen Datumszeilen (dd.mm.yyyy) gefunden.\n"
                         "Bitte prüfen: Ist dies die richtige Google-Sheets-CSV?\n"
                         "Spalte A muss die Datumspalte sein."}
    return {"ok": True, "rows": len(data_rows),
            "first": data_rows[0], "last": data_rows[-1], "error": None}


def google_sheets_csv_url(url):
    """
    Wandelt die verschiedenen Google-Sheets-Link-Formate in eine direkte
    CSV-Export-URL um. Robust gegen die häufigsten Fehlerquellen:

      • Normale Freigabe:        .../d/<ID>/edit#gid=0
                                 -> .../d/<ID>/export?format=csv&gid=0
      • Bereits Export/Pub-CSV:  enthält format=csv / output=csv -> unverändert
      • „Im Web veröffentlicht": .../d/e/<TOKEN>/pubhtml?gid=0&single=true
                                 -> .../d/e/<TOKEN>/pub?output=csv&single=true&gid=0
        (WICHTIG: der ältere Parser zerbrach hier, weil /d/([\\w-]+) das „e"
         als Tabellen-ID interpretierte und so eine 404-„Not found"-URL baute.)

    Nicht-Google-URLs werden unverändert zurückgegeben.
    """
    import re
    if "docs.google.com/spreadsheets" not in url:
        return url

    # Schon ein CSV-Export/-Publish? Dann nichts verändern.
    if "format=csv" in url or "output=csv" in url:
        return url

    # gid (Tabellenblatt) aus Query ODER Fragment (#gid=…) lesen
    gid_m = re.search(r"[#&?]gid=(\d+)", url)
    gid = gid_m.group(1) if gid_m else None

    # 1) „Im Web veröffentlicht": /d/e/<TOKEN>/…  (TOKEN enthält oft Bindestriche)
    m_pub = re.search(r"/spreadsheets/d/e/([^/?#]+)", url)
    if m_pub:
        token = m_pub.group(1)
        out = "https://docs.google.com/spreadsheets/d/e/%s/pub?output=csv" % token
        if gid:
            out += "&single=true&gid=" + gid
        return out

    # 2) Normale Freigabe: /d/<ID>/edit -> /export?format=csv
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url)
    if m:
        sheet_id = m.group(1)
        out = "https://docs.google.com/spreadsheets/d/%s/export?format=csv" % sheet_id
        if gid:
            out += "&gid=" + gid
        return out

    return url


def _looks_like_html(text):
    """Erkennt eine HTML-Seite (z. B. Google-Anmelde-/Fehlerseite) statt CSV."""
    head = text.lstrip()[:400].lower()
    return ("<!doctype html" in head or "<html" in head
            or "<head" in head or "google docs" in head
            or "sign in" in head and "<title" in head)


# ── HTTP-Helfer ───────────────────────────────────────────────────────────────
def _http_get_json(url, timeout=2.0):
    req = urllib.request.Request(url, headers={"User-Agent": "Takvim-Manager/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _http_post_json(url, payload, timeout=4.0):
    body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url, data=body, method="POST",
        headers={"Content-Type": "application/json; charset=utf-8",
                 "User-Agent": "Takvim-Manager/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _http_post_raw(url, raw_bytes, content_type="text/plain; charset=utf-8", timeout=10.0):
    """Sendet Roh-Bytes (z. B. CSV-Text oder Bild) per POST."""
    req = urllib.request.Request(
        url, data=raw_bytes, method="POST",
        headers={"Content-Type": content_type,
                 "Content-Length": str(len(raw_bytes)),
                 "User-Agent": "Takvim-Manager/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _http_delete_json(url, timeout=6.0):
    """Sendet eine DELETE-Anfrage und liest die JSON-Antwort."""
    req = urllib.request.Request(
        url, method="DELETE",
        headers={"User-Agent": "Takvim-Manager/" + VERSION})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


# ── Die Brücke zur Oberfläche ────────────────────────────────────────────────
class Api:

    # ---- Allgemein ----------------------------------------------------------
    def get_info(self):
        return {"version": VERSION, "base": BASE}

    # ---- Konfiguration (data/config.json) -----------------------------------
    def get_config(self):
        return _read_json(CONFIG_FILE, DEFAULT_CONFIG)

    def save_config(self, changes):
        cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
        if isinstance(changes, dict):
            for key, value in changes.items():
                cfg[key] = value
        cfg["version"] = VERSION
        _atomic_write_json(CONFIG_FILE, cfg)
        return cfg

    # ---- Pi-Verbindung -------------------------------------------------------
    def _pi_base(self, cfg=None):
        cfg = cfg or self.get_config()
        ip = (cfg.get("pi", {}) or {}).get("ip", "").strip()
        port = (cfg.get("pi", {}) or {}).get("port", 8080)
        if not ip:
            return None
        return "http://%s:%s" % (ip, port)

    def pi_base_url(self):
        return self._pi_base()

    def ping_pi(self):
        cfg = self.get_config()
        base = self._pi_base(cfg)
        if not base:
            return {"online": False, "ip": "", "configured": False,
                    "error": "Keine Pi-Adresse konfiguriert"}
        t0 = time.time()
        try:
            data = _http_get_json(base + "/api/ping", timeout=2.0)
            return {"online": bool(data.get("ok")),
                    "configured": True,
                    "ip": cfg["pi"]["ip"], "port": cfg["pi"]["port"],
                    "latency_ms": int((time.time() - t0) * 1000),
                    "pi_version": data.get("version"),
                    "pi_time": data.get("time")}
        except Exception as e:
            return {"online": False, "configured": True,
                    "ip": cfg["pi"]["ip"], "port": cfg["pi"]["port"],
                    "error": _kurz(e)}

    def pi_status(self):
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            return _http_get_json(base + "/api/status", timeout=3.0)
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def send_config_to_pi(self, payload):
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            return _http_post_json(base + "/api/config", payload)
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    # ---- Sprachauswahl -------------------------------------------------------

    def set_takvim_lang(self, lang):
        """Setzt die Anzeigesprache des Takvim (TV-Anzeige) auf dem Pi."""
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            r = _http_post_json(base + "/api/config", {"sprache": lang})
            return r if isinstance(r, dict) else {"ok": True}
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def set_manager_lang(self, lang):
        """Setzt die Anzeigesprache des Managers selbst und speichert sie lokal."""
        allowed = ("de", "al", "ar", "en")
        if lang not in allowed:
            return {"ok": False, "error": "Unbekannte Sprache: " + str(lang)}
        cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
        cfg["manager_lang"] = lang
        cfg["version"] = VERSION
        _atomic_write_json(CONFIG_FILE, cfg)
        return {"ok": True, "manager_lang": lang}

    # ---- Mediathek & Design-Studio (NEU Etappe 4) ---------------------------

    def get_pi_config(self):
        """Liest die aktuelle Pi-Konfiguration (für Slider-/Hintergrund-Stand)."""
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            return _http_get_json(base + "/api/config", timeout=4.0)
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def list_media(self):
        """Holt die Mediathek-Bildliste vom Pi (Name, Größe, Maße + aktiver Hintergrund)."""
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            data = _http_get_json(base + "/api/media", timeout=6.0)
            data["pi_base"] = base
            return data
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def upload_media(self, filename, b64data):
        """
        Nimmt einen Dateinamen + Base64-Bilddaten (aus dem Datei-Dialog im
        Browser), dekodiert sie und sendet die Roh-Bytes an den Pi.
        """
        import urllib.parse
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        if not filename:
            return {"ok": False, "error": "Kein Dateiname übergeben"}
        # Falls eine Data-URL übergeben wurde ("data:image/png;base64,….")
        if isinstance(b64data, str) and "," in b64data[:64] and b64data[:5] == "data:":
            b64data = b64data.split(",", 1)[1]
        try:
            raw = base64.b64decode(b64data, validate=False)
        except (binascii.Error, ValueError):
            return {"ok": False, "error": "Bilddaten konnten nicht dekodiert werden"}
        if not raw:
            return {"ok": False, "error": "Leerer Bildinhalt"}

        url = base + "/api/media?name=" + urllib.parse.quote(filename)
        try:
            return _http_post_raw(url, raw,
                                  content_type="application/octet-stream",
                                  timeout=30.0)
        except Exception as e:
            return {"ok": False, "error": "Upload fehlgeschlagen: " + _kurz(e)}

    def delete_media(self, name):
        """Löscht ein Mediathek-Bild auf dem Pi."""
        import urllib.parse
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        if not name:
            return {"ok": False, "error": "Kein Dateiname übergeben"}
        url = base + "/api/media?name=" + urllib.parse.quote(name)
        try:
            return _http_delete_json(url, timeout=8.0)
        except Exception as e:
            return {"ok": False, "error": "Löschen fehlgeschlagen: " + _kurz(e)}

    def set_background(self, name):
        """Setzt (oder entfernt mit name=None/'') das Hintergrundbild auf dem Pi."""
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        bg = name if name else None
        try:
            return _http_post_json(base + "/api/config", {"background": bg})
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def set_design(self, design):
        """
        Speichert die drei Design-Regler (blur/opacity/darken) auf dem Pi.
        Werte werden geklemmt: blur 0–40 px, opacity 0–100 %, darken 0–100 %.
        """
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        if not isinstance(design, dict):
            return {"ok": False, "error": "Ungültige Design-Daten"}

        clean = _clean_design_obj(design)
        try:
            r = _http_post_json(base + "/api/config", {"design": clean})
            if r.get("ok"):
                r["design"] = clean
            return r
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def set_layout(self, layout):
        """
        VERALTET (v1.8 · Anf. 6): Der Block-Modus wurde entfernt; diese Methode
        wird vom Manager nicht mehr aufgerufen. Sie bleibt aus Gründen der
        Rückwärtskompatibilität erhalten (z. B. ältere Skripte) und spiegelt das
        Block-Layout weiterhin lokal/auf den Pi, wird von der TV aber ignoriert.
        layout = {x, y, scale}
        """
        base = self._pi_base()
        if not isinstance(layout, dict):
            return {"ok": False, "error": "Ungültige Layout-Daten"}

        def _clampf(v, lo, hi, default):
            try:
                return max(lo, min(hi, round(float(v), 2)))
            except (TypeError, ValueError):
                return default

        clean = {
            "x":     _clampf(layout.get("x"),     -40, 40,  0),
            "y":     _clampf(layout.get("y"),     -40, 40,  0),
            "scale": _clampf(layout.get("scale"), 0.5, 1.5, 1),
        }
        # Lokale Spiegelung (Architektur: Layout-Koordinaten als Prozentwerte)
        try:
            cfg = _read_json(CONFIG_FILE, DEFAULT_CONFIG)
            cfg["layout"] = clean
            cfg["version"] = VERSION
            _atomic_write_json(CONFIG_FILE, cfg)
        except Exception:
            pass
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert",
                    "layout": clean}
        try:
            r = _http_post_json(base + "/api/config", {"layout": clean})
            if r.get("ok"):
                r["layout"] = clean
            return r
        except Exception as e:
            return {"ok": False, "error": _kurz(e), "layout": clean}

    def set_override_layout(self, override):
        """
        Speichert das FREIE Pro-Element-Layout (Etappe 4, „entkoppelte Kacheln").
        override = { enabled: bool, elements: { <id>: {x,y,w,h}, … } }
        x/y/w/h sind Prozentwerte relativ zur 16:9-Bühne. Jede Kachel wird
        unabhängig absolut positioniert; das Verschieben/Skalieren einer Kachel
        beeinflusst keine andere. Bei enabled=False (oder None) fällt die TV-App
        auf das normale Raster + Block-Layout zurück (abwärtskompatibel).
        """
        base = self._pi_base()

        clean = _clean_override_obj(override)

        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert",
                    "override_layout": clean}
        try:
            r = _http_post_json(base + "/api/config", {"override_layout": clean})
            if r.get("ok"):
                r["override_layout"] = clean
            return r
        except Exception as e:
            return {"ok": False, "error": _kurz(e), "override_layout": clean}

    # ---- Preset-Manager (NEU v1.8 · Anf. 7) ---------------------------------
    def _load_presets(self):
        data = _read_json(PRESETS_FILE, DEFAULT_PRESETS)
        if not isinstance(data.get("presets"), list):
            data = {"presets": []}
        return data

    def list_presets(self):
        """Liefert die gespeicherten Presets (nur Metadaten für die Auswahlliste)."""
        data = self._load_presets()
        meta = [{"id": p.get("id"), "name": p.get("name"), "created_at": p.get("created_at")}
                for p in data["presets"] if isinstance(p, dict) and p.get("id")]
        return {"ok": True, "presets": meta}

    def save_preset(self, snapshot):
        """
        Speichert die aktuelle UI-Konfiguration als benanntes Preset
        (Hintergrund, Design-Regler, freie Kachel-Anordnung inkl. Stile).
        Ein bereits vorhandenes Preset mit gleichem Namen wird überschrieben.
        """
        if not isinstance(snapshot, dict):
            return {"ok": False, "error": "Ungültige Preset-Daten"}
        name = str(snapshot.get("name") or "").strip()[:48]
        if not name:
            return {"ok": False, "error": "Bitte einen Preset-Namen angeben"}

        bg = snapshot.get("background")
        bg = bg if (isinstance(bg, str) and bg) else None
        preset = {
            "name": name,
            "background": bg,
            "design": _clean_design_obj(snapshot.get("design")),
            "override_layout": _clean_override_obj(snapshot.get("override_layout")),
        }

        data = self._load_presets()
        # Gleicher Name → aktualisieren (id beibehalten); sonst neu anlegen.
        existing = next((p for p in data["presets"]
                         if isinstance(p, dict) and p.get("name") == name), None)
        if existing:
            existing.update(preset)
            existing["created_at"] = existing.get("created_at") or _now_iso()
            pid = existing["id"]
        else:
            pid = _uuid.uuid4().hex[:8]
            preset["id"] = pid
            preset["created_at"] = _now_iso()
            data["presets"].append(preset)
        try:
            _atomic_write_json(PRESETS_FILE, data)
        except Exception as e:
            return {"ok": False, "error": "Speichern fehlgeschlagen: " + _kurz(e)}
        return {"ok": True, "id": pid, "presets": self.list_presets()["presets"]}

    def apply_preset(self, preset_id):
        """
        Wendet ein gespeichertes Preset an: überträgt Hintergrund, Design und
        Einzel-Anordnung in EINEM gemergten /api/config-POST an den Pi.
        """
        data = self._load_presets()
        preset = next((p for p in data["presets"]
                       if isinstance(p, dict) and p.get("id") == preset_id), None)
        if not preset:
            return {"ok": False, "error": "Preset nicht gefunden"}

        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}

        payload = {
            "background": preset.get("background"),
            "design": _clean_design_obj(preset.get("design")),
            "override_layout": _clean_override_obj(preset.get("override_layout")),
        }
        try:
            r = _http_post_json(base + "/api/config", payload)
            if isinstance(r, dict) and r.get("ok"):
                r["applied"] = payload
            return r if isinstance(r, dict) else {"ok": True, "applied": payload}
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def delete_preset(self, preset_id):
        """Löscht ein gespeichertes Preset."""
        data = self._load_presets()
        vorher = len(data["presets"])
        data["presets"] = [p for p in data["presets"]
                           if not (isinstance(p, dict) and p.get("id") == preset_id)]
        try:
            _atomic_write_json(PRESETS_FILE, data)
        except Exception as e:
            return {"ok": False, "error": "Löschen fehlgeschlagen: " + _kurz(e)}
        return {"ok": True, "deleted": len(data["presets"]) < vorher,
                "presets": self.list_presets()["presets"]}

    # ---- Infotext-Bibliothek (NEU Etappe 2) ----------------------------------

    def get_library(self):
        """Liefert die gesamte Bibliothek inkl. Pool-Konfiguration und Terminen."""
        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        # Migration: ältere Bibliotheken haben evtl. kein events/pool-Feld
        changed = False
        if "events" not in lib or not isinstance(lib.get("events"), list):
            lib["events"] = []
            changed = True
        if "pool" not in lib or not isinstance(lib.get("pool"), dict):
            lib["pool"] = {"aktiv": False, "intervall": "30", "auswahl": []}
            changed = True
        if "texte" not in lib or not isinstance(lib.get("texte"), list):
            lib["texte"] = []
            changed = True
        if changed:
            try:
                _atomic_write_json(LIBRARY_FILE, lib)
            except Exception:
                pass
        return lib

    def save_text(self, eintrag):
        """
        Fügt einen neuen Text hinzu oder aktualisiert einen bestehenden (nach id).
        eintrag = {id?, titel, text, kategorie, arabisch?}
        Gibt die gespeicherte Bibliothek zurück.
        """
        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        texte = lib.get("texte", [])

        # Felder validieren / bereinigen
        kat = eintrag.get("kategorie", "Sonstiges")
        if kat not in KATEGORIEN:
            kat = "Sonstiges"

        eintrag_id = eintrag.get("id") or str(_uuid.uuid4())[:8]

        # Bestehenden Eintrag suchen
        idx = next((i for i, t in enumerate(texte) if t.get("id") == eintrag_id), None)

        neu = {
            "id": eintrag_id,
            "titel": str(eintrag.get("titel", "")).strip(),
            "text": str(eintrag.get("text", "")).strip(),
            "arabisch": str(eintrag.get("arabisch", "")).strip(),
            "kategorie": kat,
            "quelle": str(eintrag.get("quelle", "")).strip(),
        }
        if not neu["titel"] and not neu["text"]:
            return {"ok": False, "error": "Titel und Text dürfen nicht beide leer sein."}

        if idx is not None:
            texte[idx] = neu
        else:
            texte.append(neu)

        lib["texte"] = texte
        _atomic_write_json(LIBRARY_FILE, lib)
        return {"ok": True, "library": lib}

    def delete_text(self, eintrag_id):
        """Löscht einen Eintrag aus der Bibliothek (und aus der Pool-Auswahl)."""
        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        vorher = len(lib.get("texte", []))
        lib["texte"] = [t for t in lib.get("texte", []) if t.get("id") != eintrag_id]
        # aus Pool-Auswahl entfernen falls vorhanden
        pool = lib.get("pool", {})
        auswahl = pool.get("auswahl", [])
        pool["auswahl"] = [a for a in auswahl if a != eintrag_id]
        lib["pool"] = pool
        _atomic_write_json(LIBRARY_FILE, lib)
        return {"ok": True, "deleted": len(lib["texte"]) < vorher, "library": lib}

    def reorder_texts(self, ids):
        """Speichert eine neue Reihenfolge der Bibliotheks-Texte."""
        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        texte = lib.get("texte", [])
        by_id = {t["id"]: t for t in texte if "id" in t}
        neue_reihenfolge = [by_id[i] for i in ids if i in by_id]
        # Einträge ohne ID-Match anhängen (Sicherheit)
        bekannt = set(ids)
        neue_reihenfolge += [t for t in texte if t.get("id") not in bekannt]
        lib["texte"] = neue_reihenfolge
        _atomic_write_json(LIBRARY_FILE, lib)
        return {"ok": True, "library": lib}

    def set_pool(self, pool_config):
        """
        Speichert Pool-Einstellungen lokal.
        pool_config = {aktiv: bool, intervall: "30"|"60"|"day", auswahl: [id, ...]}
        """
        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        pool = lib.get("pool", {})
        if "aktiv" in pool_config:
            pool["aktiv"] = bool(pool_config["aktiv"])
        if "intervall" in pool_config:
            iv = str(pool_config["intervall"])
            pool["intervall"] = iv if iv in ("30", "60", "day") else "30"
        if "auswahl" in pool_config:
            pool["auswahl"] = list(pool_config["auswahl"])
        lib["pool"] = pool
        _atomic_write_json(LIBRARY_FILE, lib)
        return {"ok": True, "library": lib}

    def get_kategorien(self):
        return {"ok": True, "kategorien": KATEGORIEN}

    # ---- Termin-Events (NEU Etappe 5) ---------------------------------------

    def _events_for_pi(self, events):
        """Bereinigt die Event-Liste auf das vom Pi/TV erwartete Format."""
        out = []
        for ev in (events or []):
            if not isinstance(ev, dict):
                continue
            out.append({
                "id": str(ev.get("id", "")),
                "titel": str(ev.get("titel", "")).strip(),
                "text": str(ev.get("text", "")).strip(),
                "arabisch": str(ev.get("arabisch", "")).strip(),
                "quelle": str(ev.get("quelle", "")).strip(),
                "kategorie": str(ev.get("kategorie", "")).strip(),
                "von": str(ev.get("von", "")).strip(),
                "bis": str(ev.get("bis", "")).strip(),
                "aktiv": bool(ev.get("aktiv", True)),
            })
        return out

    def _push_events(self, events):
        """Sendet die Termin-Liste an den Pi (config.events[]). Fehler werden
        zurückgemeldet, aber lokale Persistenz bleibt davon unberührt."""
        base = self._pi_base()
        clean = self._events_for_pi(events)
        if not base:
            return {"ok": False, "offline": True,
                    "error": "Keine Pi-Adresse konfiguriert", "events": clean}
        try:
            r = _http_post_json(base + "/api/config", {"events": clean})
            if isinstance(r, dict):
                r.setdefault("events", clean)
            return r
        except Exception as e:
            return {"ok": False, "error": _kurz(e), "events": clean}

    def save_event(self, eintrag):
        """
        Legt einen Termin an oder aktualisiert ihn (nach id) und sendet die
        gesamte Termin-Liste anschließend an den Pi.
        eintrag = {id?, titel, text, arabisch?, quelle?, kategorie?,
                   von?, bis?, aktiv?}
        von/bis sind Strings im Format "YYYY-MM-DDTHH:MM" (datetime-local) oder leer.
        """
        lib = self.get_library()
        events = lib.get("events", [])

        kat = eintrag.get("kategorie", "Sonstiges")
        if kat not in KATEGORIEN:
            kat = "Sonstiges"

        event_id = eintrag.get("id") or str(_uuid.uuid4())[:8]
        neu = {
            "id": event_id,
            "titel": str(eintrag.get("titel", "")).strip(),
            "text": str(eintrag.get("text", "")).strip(),
            "arabisch": str(eintrag.get("arabisch", "")).strip(),
            "quelle": str(eintrag.get("quelle", "")).strip(),
            "kategorie": kat,
            "von": str(eintrag.get("von", "")).strip(),
            "bis": str(eintrag.get("bis", "")).strip(),
            "aktiv": bool(eintrag.get("aktiv", True)),
        }
        if not neu["titel"] and not neu["text"] and not neu["arabisch"]:
            return {"ok": False,
                    "error": "Titel, Text oder arabischer Text muss gefüllt sein."}

        idx = next((i for i, e in enumerate(events)
                    if e.get("id") == event_id), None)
        if idx is not None:
            events[idx] = neu
        else:
            events.append(neu)

        lib["events"] = events
        _atomic_write_json(LIBRARY_FILE, lib)

        push = self._push_events(events)
        return {"ok": True, "library": lib, "event": neu, "push": push}

    def delete_event(self, event_id):
        """Löscht einen Termin und überträgt die neue Liste an den Pi."""
        lib = self.get_library()
        vorher = len(lib.get("events", []))
        lib["events"] = [e for e in lib.get("events", [])
                         if e.get("id") != event_id]
        _atomic_write_json(LIBRARY_FILE, lib)
        push = self._push_events(lib["events"])
        return {"ok": True, "deleted": len(lib["events"]) < vorher,
                "library": lib, "push": push}

    # ---- Live-Senden (NEU Etappe 2) -----------------------------------------

    def send_live(self):
        """
        Liest lokale Bibliothek + Pool-Einstellungen und sendet
        infotext + pool an den Pi (/api/config).
        """
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}

        lib = _read_json(LIBRARY_FILE, DEFAULT_LIBRARY)
        pool_lokal = lib.get("pool", {})
        texte = lib.get("texte", [])

        # Pool-Einträge für Pi aufbauen: nur ausgewählte Texte, in Reihenfolge der Auswahl
        auswahl_ids = pool_lokal.get("auswahl", [])
        by_id = {t["id"]: t for t in texte if "id" in t}
        pool_eintraege = [by_id[i] for i in auswahl_ids if i in by_id]

        # Einzeltext (bei inaktivem Pool): der erste in der Auswahl, sonst None
        if not pool_lokal.get("aktiv") and auswahl_ids:
            erster = by_id.get(auswahl_ids[0])
            infotext_payload = {
                "titel": erster.get("titel", "") if erster else "",
                "text": erster.get("text", "") if erster else "",
                "arabisch": erster.get("arabisch", "") if erster else "",
                "quelle": erster.get("quelle", "") if erster else "",
                "kategorie": erster.get("kategorie", "") if erster else "",
            } if erster else None
        else:
            infotext_payload = None

        payload = {
            "infotext": infotext_payload,
            "pool": {
                "aktiv": bool(pool_lokal.get("aktiv")),
                "intervall": pool_lokal.get("intervall", "30"),
                "eintraege": pool_eintraege
            },
            "events": self._events_for_pi(lib.get("events", []))
        }

        try:
            result = _http_post_json(base + "/api/config", payload)
            return result
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    # ---- Gebetszeiten-Import (NEU Etappe 2) ----------------------------------

    def preview_csv(self, csv_text):
        """
        Analysiert den CSV-Text lokal und gibt Vorschau-Info zurück,
        ohne etwas an den Pi zu senden.
        """
        info = _analyse_csv(csv_text)
        return info

    def import_csv_from_url(self, url):
        """
        Lädt eine CSV von einer URL (Google-Sheets-Export-Link),
        prüft sie lokal und sendet sie an den Pi.
        """
        url = (url or "").strip()
        if not url:
            return {"ok": False, "error": "Keine URL angegeben."}
        if not (url.startswith("http://") or url.startswith("https://")):
            return {"ok": False, "error": "Bitte eine vollständige URL mit https:// einfügen."}

        # Google-Sheets-Link in eine direkte CSV-Export-URL umwandeln
        fetch_url = google_sheets_csv_url(url)

        # Browser-typischer User-Agent: Google liefert sonst teils eine
        # Consent-/HTML-Seite statt der CSV.
        headers = {
            "User-Agent": "Mozilla/5.0 (Takvim-Manager/" + VERSION + ")",
            "Accept": "text/csv,text/plain,*/*",
        }
        try:
            req = urllib.request.Request(fetch_url, headers=headers)
            with urllib.request.urlopen(req, timeout=20.0) as resp:
                raw = resp.read()
                final_url = resp.geturl()
                ctype = (resp.headers.get("Content-Type") or "").lower()
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return {"ok": False, "error":
                        "Tabelle nicht gefunden (404). Bitte den Link prüfen — und "
                        "sicherstellen, dass die Tabelle öffentlich freigegeben ist "
                        "(„Jeder mit dem Link · Betrachter“)."}
            if e.code in (401, 403):
                return {"ok": False, "error":
                        "Zugriff verweigert (%d). Die Google-Tabelle ist nicht "
                        "öffentlich freigegeben." % e.code}
            return {"ok": False, "error": "Download fehlgeschlagen (HTTP %d)." % e.code}
        except Exception as e:
            return {"ok": False, "error": "Download fehlgeschlagen: " + _kurz(e)}

        if not raw:
            return {"ok": False, "error": "Die Quelle hat keine Daten geliefert."}

        # Encoding erkennen
        try:
            csv_text = raw.decode("utf-8-sig")
        except UnicodeDecodeError:
            try:
                csv_text = raw.decode("latin-1")
            except Exception:
                return {"ok": False, "error": "CSV-Zeichenkodierung nicht lesbar."}

        # HTML statt CSV? Dann ist die Tabelle meist nicht öffentlich oder es
        # wurde der Bearbeiten-Link (statt Export) erwischt.
        is_google = "docs.google.com" in (final_url or fetch_url)
        if "text/html" in ctype or _looks_like_html(csv_text):
            if is_google:
                return {"ok": False, "error":
                        "Es kam eine HTML-Seite statt einer CSV zurück.\n"
                        "Wahrscheinliche Ursache: Die Tabelle ist nicht öffentlich "
                        "freigegeben. Im Sheet: Freigeben → „Jeder mit dem Link · "
                        "Betrachter“ — danach den Link erneut einfügen.\n"
                        "Alternativ: Datei → Herunterladen → CSV und die Datei "
                        "über „CSV-Datei vom Computer“ importieren."}
            return {"ok": False, "error":
                    "Die URL liefert HTML statt CSV — bitte einen direkten "
                    "CSV-Export-Link verwenden."}

        return self._send_csv_to_pi(csv_text)

    def import_csv_from_text(self, csv_text):
        """
        Nimmt einen CSV-Text (aus Datei-Auswahl-Dialog im Browser)
        und sendet ihn nach Prüfung an den Pi.
        """
        if not csv_text or not csv_text.strip():
            return {"ok": False, "error": "Kein CSV-Inhalt übergeben."}
        return self._send_csv_to_pi(csv_text)

    def _send_csv_to_pi(self, csv_text):
        """Gemeinsame Methode: CSV prüfen + an Pi senden."""
        info = _analyse_csv(csv_text)
        if not info["ok"]:
            return info  # Fehler direkt zurück

        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert.\n"
                                          "Bitte erst unter ⚙️ System die Pi-IP eintragen."}
        try:
            raw_bytes = csv_text.encode("utf-8")
            result = _http_post_raw(base + "/api/csv", raw_bytes,
                                    content_type="text/plain; charset=utf-8",
                                    timeout=15.0)
            # Pi antwortet mit {ok, rows, first, last}
            if result.get("ok"):
                result["local_preview"] = info  # lokale Analyse ebenfalls zurückgeben
            return result
        except Exception as e:
            return {"ok": False, "error": "Übertragung fehlgeschlagen: " + _kurz(e)}

    # ---- Selbst-Update + Rollback (Etappe 6) --------------------------------
    def check_update(self):
        """
        Prüft die Update-Quelle. Erwartet unter cfg.update.url ein Manifest-JSON:
            { "version": "1.7.0", "url": "https://…/Takvim-Manager-1.7.0.zip",
              "notes": "Änderungen…" }
        Gibt zurück: {ok, available, current, latest?, download_url?, notes?, info}.
        """
        cfg = self.get_config()
        url = (cfg.get("update", {}) or {}).get("url", "").strip()
        if not url:
            return {"ok": True, "available": False, "current": VERSION,
                    "info": "Keine Update-Quelle konfiguriert."}
        if not (url.startswith("http://") or url.startswith("https://")):
            return {"ok": False, "available": False, "current": VERSION,
                    "error": "Update-URL muss mit http(s):// beginnen."}
        try:
            manifest = _http_get_json(url, timeout=8.0)
        except Exception as e:
            return {"ok": False, "available": False, "current": VERSION,
                    "error": "Update-Quelle nicht erreichbar: " + _kurz(e)}
        if not isinstance(manifest, dict):
            return {"ok": False, "available": False, "current": VERSION,
                    "error": "Ungültiges Update-Manifest."}
        latest = str(manifest.get("version", "")).strip()
        dl = str(manifest.get("url", "")).strip()
        notes = str(manifest.get("notes", "")).strip()
        available = bool(latest) and bool(dl) and _version_gt(latest, VERSION)
        return {
            "ok": True, "available": available, "current": VERSION,
            "latest": latest, "download_url": dl, "notes": notes,
            "info": (("Update verfügbar: v%s" % latest) if available
                     else "Software ist aktuell (v%s)." % VERSION)
        }

    def download_update(self):
        """Lädt das im Manifest genannte ZIP herunter und legt es atomar in
        temp_update/ ab. Gibt {ok, downloaded, size?, version?, path?} zurück."""
        info = self.check_update()
        if not info.get("ok"):
            return info
        if not info.get("available"):
            return {"ok": True, "downloaded": False, "info": info.get("info")}
        dl = info.get("download_url", "")
        try:
            os.makedirs(TEMP_DIR, exist_ok=True)
            req = urllib.request.Request(
                dl, headers={"User-Agent": "Takvim-Manager/" + VERSION})
            with urllib.request.urlopen(req, timeout=180.0) as resp:
                data = resp.read()
        except Exception as e:
            return {"ok": False, "error": "Download fehlgeschlagen: " + _kurz(e)}
        if not data or data[:2] != b"PK":
            return {"ok": False, "error": "Die Quelle lieferte kein gültiges "
                                          "ZIP-Paket."}
        try:
            tmp = UPDATE_ZIP + ".part"
            with open(tmp, "wb") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
            os.replace(tmp, UPDATE_ZIP)
        except Exception as e:
            return {"ok": False, "error": "Speichern fehlgeschlagen: " + _kurz(e)}
        return {"ok": True, "downloaded": True, "size": len(data),
                "version": info.get("latest"), "path": UPDATE_ZIP}

    def install_update(self):
        """
        Prüft das heruntergeladene Archiv, startet installer.bat ABGEKOPPELT
        und beendet danach die App, damit der Installer die Dateien tauschen
        kann. installer.bat: wartet auf das App-Ende, entpackt das ZIP,
        überschreibt app/ (Sperrzone data/ bleibt unberührt) und startet neu.
        """
        if not os.path.isfile(UPDATE_ZIP):
            return {"ok": False, "error": "Kein heruntergeladenes Update "
                                          "gefunden. Bitte zuerst herunterladen."}
        import zipfile
        try:
            with zipfile.ZipFile(UPDATE_ZIP) as zf:
                bad = zf.testzip()
                if bad is not None:
                    return {"ok": False, "error": "Update-Archiv beschädigt (%s)."
                            % bad}
        except Exception as e:
            return {"ok": False, "error": "Update-Archiv unlesbar: " + _kurz(e)}

        if os.name != "nt":
            return {"ok": False, "error": "Die automatische Installation läuft "
                    "nur unter Windows. Auf anderen Systemen das ZIP manuell "
                    "über app/ entpacken (data/ nicht überschreiben)."}
        if not os.path.isfile(INSTALLER_BAT):
            return {"ok": False, "error": "installer.bat wurde nicht gefunden."}

        relaunch = sys.executable if getattr(sys, "frozen", False) \
            else os.path.join(BASE, "start_manager.bat")
        pid = os.getpid()

        try:
            flags = 0
            if hasattr(subprocess, "DETACHED_PROCESS"):
                flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
            subprocess.Popen(
                [INSTALLER_BAT, UPDATE_ZIP, BASE, relaunch, str(pid)],
                cwd=BASE, close_fds=True, creationflags=flags)
        except Exception as e:
            return {"ok": False, "error": "Installer-Start fehlgeschlagen: "
                    + _kurz(e)}

        # App nach kurzer Verzögerung beenden, damit der Installer übernehmen kann
        threading.Timer(1.2, self._shutdown_app).start()
        return {"ok": True, "installing": True,
                "info": "Installation gestartet — die App schließt sich und "
                        "startet anschließend automatisch neu."}

    def _shutdown_app(self):
        """Beendet die Anwendung sauber (für den Installer-Neustart)."""
        try:
            import webview
            for w in list(getattr(webview, "windows", [])):
                try:
                    w.destroy()
                except Exception:
                    pass
        except Exception:
            pass
        os._exit(0)

    def rollback_pi(self):
        """
        Notfall-Rollback (Modul 3.2): sendet das hochpriorisierte Express-Signal
        an den Pi. Der Pi stellt backup_previous -> takvim-app wieder her und
        startet den Browser in < 5 s neu.
        """
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            return _http_post_json(base + "/api/rollback", {}, timeout=10.0)
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def get_pi_update_status(self):
        """Liest Backup-/Update-Status des Pi (GET /api/update)."""
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        try:
            return _http_get_json(base + "/api/update", timeout=5.0)
        except Exception as e:
            return {"ok": False, "error": _kurz(e)}

    def push_tv_update(self, filename, b64data):
        """
        Lädt ein TV-App-Update-ZIP (vom Datei-Dialog, Base64) zum Pi hoch
        (POST /api/update). Der Pi legt es in /updates/ ab; der Wartungs-Dienst
        spielt es im nächsten Wartungsfenster ein (mit Backup).
        """
        import urllib.parse
        base = self._pi_base()
        if not base:
            return {"ok": False, "error": "Keine Pi-Adresse konfiguriert"}
        if not filename:
            return {"ok": False, "error": "Kein Dateiname übergeben"}
        if isinstance(b64data, str) and b64data[:5] == "data:" and "," in b64data[:64]:
            b64data = b64data.split(",", 1)[1]
        try:
            raw = base64.b64decode(b64data, validate=False)
        except (binascii.Error, ValueError):
            return {"ok": False, "error": "Update-Daten konnten nicht dekodiert werden"}
        if not raw or raw[:2] != b"PK":
            return {"ok": False, "error": "Kein gültiges ZIP-Paket"}
        url = base + "/api/update?name=" + urllib.parse.quote(filename)
        try:
            return _http_post_raw(url, raw,
                                  content_type="application/octet-stream",
                                  timeout=120.0)
        except Exception as e:
            return {"ok": False, "error": "Upload fehlgeschlagen: " + _kurz(e)}

    # ---- Splash-Sequenz (parallel) ------------------------------------------
    def startup(self):
        results = {}

        def t_update():
            results["update"] = self.check_update()

        def t_ping():
            results["pi"] = self.ping_pi()

        threads = [threading.Thread(target=t_update, daemon=True),
                   threading.Thread(target=t_ping, daemon=True)]
        for t in threads:
            t.start()
        for t in threads:
            t.join(timeout=4.0)

        results.setdefault("update", {"available": False, "current": VERSION,
                                      "info": "Prüfung nicht abgeschlossen"})
        results.setdefault("pi", {"online": False, "error": "Zeitüberschreitung"})
        results["version"] = VERSION
        return results


def _version_gt(a, b):
    """True, wenn Versions-String a > b (rein numerisch, z. B. '1.6.0')."""
    def _parts(v):
        out = []
        for tok in str(v).strip().lstrip("vV").split("."):
            num = "".join(ch for ch in tok if ch.isdigit())
            out.append(int(num) if num else 0)
        return out
    pa, pb = _parts(a), _parts(b)
    n = max(len(pa), len(pb))
    pa += [0] * (n - len(pa))
    pb += [0] * (n - len(pb))
    return pa > pb


def _kurz(exc):
    s = str(exc)
    if isinstance(exc, urllib.error.URLError):
        s = str(exc.reason)
    if "timed out" in s.lower():
        return "Zeitüberschreitung — Pi antwortet nicht"
    if "refused" in s.lower():
        return "Verbindung abgelehnt — läuft der Pi-Dienst?"
    if "unreachable" in s.lower() or "no route" in s.lower():
        return "Netzwerk nicht erreichbar"
    if "getaddrinfo" in s.lower() or "name or service" in s.lower():
        return "Adresse nicht auflösbar — IP prüfen"
    return s[:120]


# ── Fensterstart ─────────────────────────────────────────────────────────────
def start_gui():
    import webview

    api = Api()
    webview.create_window(
        title="Takvim-Manager v1.6",
        url=os.path.join(APP_DIR, "index.html"),
        js_api=api,
        width=1280, height=830,
        min_size=(1080, 700),
        background_color="#0a0f1e"
    )
    webview.start()


if __name__ == "__main__":
    ensure_data()
    start_gui()
