@echo off
REM ============================================================================
REM  MOSCHEE-TAKVIM  -  Takvim-Manager Self-Update-Installer        (Etappe 6)
REM ----------------------------------------------------------------------------
REM  Wird von der App (install_update) ABGEKOPPELT gestartet. Ablauf:
REM    1. Wartet, bis die laufende App (PID) beendet ist.
REM    2. Entpackt das Update-ZIP in einen Staging-Ordner.
REM    3. Ueberschreibt den Ordner app\  (Sperrzone data\ bleibt UNberuehrt).
REM    4. Aktualisiert die uebrigen Programmdateien (ohne data\ / temp_update\).
REM    5. Startet die App automatisch neu.
REM
REM  Aufruf:  installer.bat  <ZIP>  <ROOT>  <RELAUNCH>  <PID>
REM    %1 ZIP      = Pfad zum heruntergeladenen Update-Paket
REM    %2 ROOT     = Programmordner (wird aktualisiert)
REM    %3 RELAUNCH = nach der Installation zu startendes Programm (.exe/.bat)
REM    %4 PID      = Prozess-ID der App, auf deren Ende gewartet wird
REM ============================================================================
setlocal enabledelayedexpansion

set "ZIP=%~1"
set "ROOT=%~2"
set "RELAUNCH=%~3"
set "PID=%~4"

set "STAGE=%TEMP%\takvim_update_stage"
set "LOG=%ROOT%\temp_update\installer.log"

call :log "==============================================================="
call :log "Installer gestartet."
call :log "ZIP=%ZIP%"
call :log "ROOT=%ROOT%"
call :log "RELAUNCH=%RELAUNCH%"
call :log "PID=%PID%"

REM --- 1) Auf das Ende der laufenden App warten -------------------------------
if not "%PID%"=="" (
  call :log "Warte auf Beenden der App (PID %PID%) ..."
  powershell -NoProfile -Command "try { Wait-Process -Id %PID% -Timeout 60 -ErrorAction Stop } catch {}"
)
REM kleine Sicherheitspause, damit Dateihandles freigegeben werden
ping -n 3 127.0.0.1 >nul

REM --- 2) Update-ZIP entpacken ------------------------------------------------
if not exist "%ZIP%" (
  call :log "FEHLER: Update-ZIP nicht gefunden - Abbruch."
  goto :relaunch
)
call :log "Entpacke Update ..."
if exist "%STAGE%" rmdir /s /q "%STAGE%"
powershell -NoProfile -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '%STAGE%' -Force"
if errorlevel 1 (
  call :log "FEHLER: Entpacken fehlgeschlagen - Abbruch."
  goto :relaunch
)

REM --- 3) Nutzlast-Wurzel finden (Ordner, der app\index.html enthaelt) --------
set "PAYLOAD="
for /f "usebackq delims=" %%I in (`powershell -NoProfile -Command "$h=Get-ChildItem -LiteralPath '%STAGE%' -Recurse -Filter index.html -ErrorAction SilentlyContinue ^| Where-Object { $_.FullName -like '*\app\index.html' } ^| Select-Object -First 1; if ($h) { Split-Path (Split-Path $h.FullName -Parent) -Parent }"`) do set "PAYLOAD=%%I"

if "%PAYLOAD%"=="" (
  call :log "FEHLER: Im Update kein app\index.html gefunden - Abbruch."
  goto :relaunch
)
call :log "Nutzlast-Wurzel: %PAYLOAD%"

REM --- 4) app\ spiegeln (loescht entfernte Dateien, behaelt aber data\) -------
call :log "Aktualisiere app\ ..."
robocopy "%PAYLOAD%\app" "%ROOT%\app" /MIR /NFL /NDL /NJH /NJS /R:2 /W:1 >>"%LOG%" 2>&1
if errorlevel 8 (
  call :log "FEHLER: Kopieren von app\ fehlgeschlagen - Abbruch."
  goto :relaunch
)

REM --- 5) Uebrige Programmdateien aktualisieren (NUR hinzufuegen/ueberschreiben)
REM     /E = inkl. Unterordner, KEIN Loeschen -> data\ kann nie verschwinden.
REM     Ausgeschlossen: app (schon gespiegelt), data (Sperrzone),
REM     temp_update (Wartezimmer) sowie installer.bat und das ZIP selbst.
call :log "Aktualisiere Programmdateien (ohne data\) ..."
robocopy "%PAYLOAD%" "%ROOT%" /E /XD "%PAYLOAD%\app" "%PAYLOAD%\data" "%PAYLOAD%\temp_update" /XF installer.bat update.zip /R:2 /W:1 >>"%LOG%" 2>&1
if errorlevel 8 (
  call :log "WARNUNG: Aktualisierung der Programmdateien meldete Fehler."
)

call :log "Installation abgeschlossen."

REM --- 6) Aufraeumen ----------------------------------------------------------
if exist "%STAGE%" rmdir /s /q "%STAGE%"
if exist "%ZIP%" del /q "%ZIP%"

:relaunch
call :log "Starte App neu: %RELAUNCH%"
if not "%RELAUNCH%"=="" (
  start "" "%RELAUNCH%"
)
call :log "Installer beendet."
endlocal
exit /b 0

REM ---------------------------------------------------------------------------
:log
echo [%date% %time%] %~1>>"%LOG%"
goto :eof
