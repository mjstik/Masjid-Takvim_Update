@echo off
REM ============================================================
REM  Takvim-Manager v1.0 starten (Entwicklungs-Modus)
REM  Installiert beim ersten Start automatisch 'pywebview'.
REM  In Etappe 6 wird daraus die fertige Takvim-Manager v1.0.exe
REM ============================================================
cd /d %~dp0
title Takvim-Manager v1.0
python -m pip show pywebview >nul 2>&1 || (
  echo Erste Einrichtung: installiere pywebview ...
  python -m pip install pywebview
)
python "Takvim-Manager.py"
if errorlevel 1 pause
