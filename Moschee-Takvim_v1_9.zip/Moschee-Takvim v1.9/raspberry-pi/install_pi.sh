#!/bin/bash
# ==============================================================================
#  MOSCHEE-TAKVIM — Installation auf dem Raspberry Pi 5            (Etappe 6)
# ------------------------------------------------------------------------------
#  Ausführen auf dem Pi:   bash install_pi.sh
#  Legt die Verzeichnisstruktur nach Pflichtenheft 7B an, kopiert den Dienst
#  und richtet ihn als systemd-Service ein (startet automatisch beim Booten).
#  NEU Etappe 6: Wartungs-Dienst (Wartungsfenster + Express-Rollback) als
#  Autostart im grafischen Login + HDMI-CEC-Werkzeuge (cec-utils).
# ==============================================================================
set -e

ZIEL="/home/pi/moschee-takvim"
HIER="$(cd "$(dirname "$0")" && pwd)"

echo "── Moschee-Takvim Installation ──────────────────────────────"

# 1) Verzeichnisstruktur (Pflichtenheft 7B)
mkdir -p "$ZIEL/takvim-app" "$ZIEL/takvim-data" "$ZIEL/mediathek" \
         "$ZIEL/backup_previous" "$ZIEL/updates"
echo "✓ Verzeichnisstruktur unter $ZIEL"

# 2) Dienst + TV-App kopieren (Sperrzonen takvim-data/mediathek bleiben unberührt)
cp "$HIER/pi_server.py" "$ZIEL/pi_server.py"
cp "$HIER/wartung.py"   "$ZIEL/wartung.py"
if [ -d "$HIER/takvim-app" ]; then
  cp -r "$HIER/takvim-app/." "$ZIEL/takvim-app/"
fi
if [ -f "$HIER/start_kiosk.sh" ]; then
  cp "$HIER/start_kiosk.sh" "$ZIEL/start_kiosk.sh"
  chmod +x "$ZIEL/start_kiosk.sh"
fi
echo "✓ Dienst, Wartungs-Dienst und TV-App kopiert"

# 2b) HDMI-CEC-Werkzeuge (für TV ein/aus im Wartungsfenster)
if ! command -v cec-client >/dev/null; then
  echo "── Installiere cec-utils (HDMI-CEC) ─────────────────────────"
  sudo apt-get update -y && sudo apt-get install -y cec-utils || \
    echo "⚠ cec-utils konnte nicht installiert werden — TV ein/aus ist dann inaktiv."
fi

# 3) systemd-Service einrichten
sudo tee /etc/systemd/system/moschee-takvim.service >/dev/null <<'EOF'
[Unit]
Description=Moschee-Takvim Empfaenger-Dienst
After=network.target

[Service]
Type=simple
User=pi
WorkingDirectory=/home/pi/moschee-takvim
ExecStart=/usr/bin/python3 /home/pi/moschee-takvim/pi_server.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reload
sudo systemctl enable moschee-takvim.service
sudo systemctl restart moschee-takvim.service
echo "✓ systemd-Dienst 'moschee-takvim' aktiviert und gestartet"

# 4) Chromium-Kiosk-Autostart (NEU Etappe 3)
#    XDG-Autostart funktioniert sowohl unter Wayland/labwc (Pi 5 Standard)
#    als auch unter X11. Voraussetzung: Desktop-Autologin ist aktiviert
#    (raspi-config -> System Options -> Boot -> Desktop Autologin).
mkdir -p /home/pi/.config/autostart
tee /home/pi/.config/autostart/takvim-kiosk.desktop >/dev/null <<'EOD'
[Desktop Entry]
Type=Application
Name=Moschee-Takvim Kiosk
Comment=Startet die TV-Anzeige im Chromium-Vollbild
Exec=/home/pi/moschee-takvim/start_kiosk.sh
X-GNOME-Autostart-enabled=true
EOD
echo "✓ Kiosk-Autostart eingerichtet (Chromium startet nach dem Booten)"

# 4b) Wartungs-Dienst-Autostart (NEU Etappe 6)
#     Läuft IM grafischen Login (wie der Kiosk), damit er Zugriff auf
#     Bildschirm/CEC und die Chromium-Instanz hat. Berechnet das nächtliche
#     Wartungsfenster (Isha+60) und führt den Express-Rollback aus.
tee /home/pi/.config/autostart/takvim-wartung.desktop >/dev/null <<'EOW'
[Desktop Entry]
Type=Application
Name=Moschee-Takvim Wartung
Comment=Wartungsfenster (TV aus/an, Cache, Update) + Express-Rollback
Exec=/usr/bin/python3 /home/pi/moschee-takvim/wartung.py
X-GNOME-Autostart-enabled=true
EOW
echo "✓ Wartungs-Dienst-Autostart eingerichtet (Wartungsfenster + Rollback)"

# 5) Bildschirm-Standby/Blanking deaktivieren (TV soll nie schwarz werden)
if command -v raspi-config >/dev/null; then
  sudo raspi-config nonint do_blanking 1 || true
  echo "✓ Bildschirm-Blanking deaktiviert"
fi

# 6) IP anzeigen
IP=$(hostname -I | awk '{print $1}')
echo "─────────────────────────────────────────────────────────────"
echo "  Fertig! Diese Adresse im Takvim-Manager unter ⚙ System eintragen:"
echo "     IP:   $IP      Port: 8080"
echo "  TV-Anzeige im Browser:  http://$IP:8080/"
echo "  Dienst-Status prüfen:   systemctl status moschee-takvim"
echo "  Wartungs-Log:           tail -f $ZIEL/takvim-data/wartung.log"
echo "  Wartungsfenster:        Isha + 60 Min  →  Aufwachen Fajr − 30 Min"
echo "  Hinweis: Kiosk & Wartung starten beim nächsten Desktop-Login (Neustart)."
echo "─────────────────────────────────────────────────────────────"
