@echo off
REM ============================================================
REM  Pi-Dienst LOKAL auf dem Laptop testen (ohne Raspberry Pi)
REM  Im Takvim-Manager dann als IP eintragen:  127.0.0.1
REM ============================================================
cd /d %~dp0
title Moschee-Takvim - Pi-Dienst (lokaler Test)
python pi_server.py
pause
