#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 MOSCHEE-TAKVIM  —  WARTUNGS-DIENST (Pi)                            Etappe 6
================================================================================
 Dynamisches Wartungsfenster + Express-Rollback-Ausführung.

 Dieser Dienst läuft im GRAFISCHEN Benutzer-Login (wie der Kiosk, per
 XDG-Autostart), NICHT als systemd-System-Dienst — denn er braucht Zugriff
 auf den Bildschirm/CEC (cec-client) und auf die Chromium-Instanz der Anzeige.

 ── Modul 2: Dynamisches Wartungsfenster ────────────────────────────────────
   Startzeit  = Isha-Gebetszeit (CSV-Spalte c12) + 60 Minuten.
   Ablauf (5 Schritte nacheinander):
     1. TV-Standby   (HDMI-CEC: cec-client „standby 0")
     2. Cache löschen (Chromium-Cache im Benutzerprofil radikal leeren)
     3. Staged Update (falls in /updates/ etwas liegt: takvim-app -> backup,
                        Update -> takvim-app)
     4. Browser-Neustart (Chromium killen und im Kiosk neu starten)
     5. TV-Aufwachen  (HDMI-CEC „on 0") zum Zeitpunkt Fajr-Gebet − 30 Min
                        (Fajr-Gebetszeit = CSV-Spalte c4 / „Sabah", identisch
                         zur Athan-Zeit der TV-App).

   Schritte 1–4 laufen am Fenster-Start sofort hintereinander; danach bleibt
   der TV bis zur Aufwachzeit im Standby. Während dieser Zeit (und immer)
   pollt der Dienst die Steuerdatei für den Express-Rollback.

 ── Modul 3.2: Express-Rollback (Ausführung) ────────────────────────────────
   Der Pi-Dienst (pi_server.py) kann keinen Browser neu starten (kein
   Display). Er kopiert beim Rollback backup_previous -> takvim-app und
   schreibt eine Steuerdatei (control.json). Dieser Wartungs-Dienst pollt
   sie im Sekundentakt und führt den Browser-Neustart aus — Gesamtzeit vom
   Signal bis zum Neustart << 5 s.
================================================================================
"""
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta

VERSION = "1.8.0"

# ── Basisverzeichnis (identisch zu pi_server.py) ─────────────────────────────
BASE = os.environ.get("TAKVIM_BASE") or os.path.dirname(os.path.abspath(__file__))

APP_DIR     = os.path.join(BASE, "takvim-app")
DATA_DIR    = os.path.join(BASE, "takvim-data")
BACKUP_DIR  = os.path.join(BASE, "backup_previous")
UPDATES_DIR = os.path.join(BASE, "updates")

CSV_FILE     = os.path.join(DATA_DIR, "gebetszeiten_jahr.csv")
CONTROL_FILE = os.path.join(DATA_DIR, "control.json")
STATE_FILE   = os.path.join(DATA_DIR, "wartung_state.json")
LOG_FILE     = os.path.join(DATA_DIR, "wartung.log")

START_KIOSK = os.path.join(BASE, "start_kiosk.sh")
KIOSK_URL   = "http://localhost:8080/"

# CSV-Spaltenzuordnung (wie altes Google-Sheet / TV-App):
#   c0=Datum  c3=Fajr(Imsak)  c4=Sabah(Fajr-Gebet)  c6=Dhuhr  c10=Maghrib
#   c12=Isha  c13=Isha-Adhan
COL_DATE   = 0
COL_FAJR   = 4    # „Sabah" = Fajr-Gebetszeit (Athan), wie in der TV-App
COL_ISHA   = 12

# Wartungsfenster-Parameter (Vorgabe Übergabe Etappe 6)
ISHA_OFFSET_MIN = 60     # Start = Isha + 60 Min
FAJR_OFFSET_MIN = 30     # Aufwachen = Fajr − 30 Min

POLL_INTERVAL_S = 1.0    # Steuerdatei-Poll (Express-Rollback reaktionsschnell)


# ── Logging ──────────────────────────────────────────────────────────────────
def log(msg):
    line = "[%s] %s" % (datetime.now().strftime("%Y-%m-%d %H:%M:%S"), msg)
    print(line, flush=True)                       # -> journal/stdout
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


# ── Zeit-Helfer ──────────────────────────────────────────────────────────────
def _parse_hhmm(s):
    """'HH:MM' -> Minuten seit Mitternacht; None bei Fehler."""
    try:
        s = (s or "").strip().strip('"')
        parts = s.split(":")
        return int(parts[0]) * 60 + int(parts[1])
    except Exception:
        return None


def _read_csv_rows():
    """Liest die Gebetszeiten-CSV als { 'dd.mm.yyyy': [zellen...] }."""
    rows = {}
    if not os.path.isfile(CSV_FILE):
        return rows
    try:
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                cells = [c.strip().strip('"') for c in line.split(",")]
                d = cells[COL_DATE] if cells else ""
                if len(d) == 10 and d[2] == "." and d[5] == ".":
                    rows[d] = cells
    except Exception as e:
        log("CSV-Lesefehler: %s" % e)
    return rows


def _row_for_date(rows, date_obj):
    return rows.get(date_obj.strftime("%d.%m.%Y"))


def isha_start_for(date_obj):
    """Liefert den Wartungsfenster-Start (datetime) für das Datum date_obj
    oder None, wenn keine gültige Isha-Zeit vorliegt."""
    rows = _read_csv_rows()
    row = _row_for_date(rows, date_obj)
    if not row or len(row) <= COL_ISHA:
        return None
    m = _parse_hhmm(row[COL_ISHA])
    if m is None:
        return None
    base = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
    return base + timedelta(minutes=m + ISHA_OFFSET_MIN)


def fajr_wake_after(start_dt):
    """Aufwachzeit = nächste Fajr-Zeit NACH dem Wartungsstart, minus 30 Min.
    Da das Fenster spätabends beginnt, ist das die Fajr-Zeit des Folgetages."""
    rows = _read_csv_rows()
    # Kandidaten: Folgetag zuerst (Normalfall), dann gleicher Tag (Sicherheit)
    for delta in (1, 0, 2):
        day = (start_dt + timedelta(days=delta)).replace(
            hour=0, minute=0, second=0, microsecond=0)
        row = _row_for_date(rows, day)
        if not row or len(row) <= COL_FAJR:
            continue
        m = _parse_hhmm(row[COL_FAJR])
        if m is None:
            continue
        wake = day + timedelta(minutes=m - FAJR_OFFSET_MIN)
        if wake > start_dt:
            return wake
    # Fallback: feste 6 Stunden nach Start, falls keine CSV-Zeit ermittelbar
    log("⚠ Keine Fajr-Zeit für Aufwachen gefunden — Fallback Start+6 h.")
    return start_dt + timedelta(hours=6)


# ── Zustands-Persistenz (übersteht Neustart des Dienstes) ────────────────────
def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_state(state):
    try:
        os.makedirs(DATA_DIR, exist_ok=True)
        tmp = STATE_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, STATE_FILE)
    except Exception as e:
        log("State-Schreibfehler: %s" % e)


# ── Schritt 1 & 5: HDMI-CEC (TV ein/aus) ─────────────────────────────────────
def _cec(command):
    """Sendet einen CEC-Befehl an den TV (logische Adresse 0)."""
    if shutil.which("cec-client") is None:
        log("⚠ cec-client nicht gefunden — CEC-Befehl '%s' übersprungen "
            "(sudo apt install cec-utils)." % command)
        return False
    try:
        p = subprocess.run(
            ["cec-client", "-s", "-d", "1"],
            input=("%s 0\n" % command).encode("utf-8"),
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            timeout=15)
        log("CEC '%s 0' gesendet (rc=%s)." % (command, p.returncode))
        return p.returncode == 0
    except Exception as e:
        log("CEC-Fehler bei '%s': %s" % (command, e))
        return False


def tv_standby():
    log("Schritt 1/5: TV in Standby (CEC).")
    _cec("standby")


def tv_wake():
    log("Schritt 5/5: TV aufwecken (CEC).")
    _cec("on")


# ── Schritt 2: Chromium-Cache radikal leeren ─────────────────────────────────
def _clear_dir_contents(path):
    """Löscht den INHALT eines Ordners (Ordner selbst bleibt). Anzahl gelöscht."""
    n = 0
    if not os.path.isdir(path):
        return 0
    for entry in os.listdir(path):
        full = os.path.join(path, entry)
        try:
            if os.path.isdir(full) and not os.path.islink(full):
                shutil.rmtree(full, ignore_errors=True)
            else:
                os.remove(full)
            n += 1
        except Exception:
            pass
    return n


def clear_browser_cache():
    log("Schritt 2/5: Chromium-Cache leeren.")
    home = os.path.expanduser("~")
    targets = [
        os.path.join(home, ".cache", "chromium"),
        os.path.join(home, ".cache", "chromium-browser"),
    ]
    # Cache-Ordner innerhalb der Chromium-Profile
    for cfg in (os.path.join(home, ".config", "chromium"),
                os.path.join(home, ".config", "chromium-browser")):
        if not os.path.isdir(cfg):
            continue
        for prof in os.listdir(cfg):
            pdir = os.path.join(cfg, prof)
            if not os.path.isdir(pdir):
                continue
            for sub in ("Cache", "Code Cache", "GPUCache",
                        "Service Worker", "Application Cache"):
                targets.append(os.path.join(pdir, sub))
    total = 0
    for t in targets:
        total += _clear_dir_contents(t)
    log("Cache geleert: %d Einträge entfernt." % total)


# ── Schritt 3: Staged Update der TV-App ──────────────────────────────────────
def _find_app_root(path):
    """Findet im Update-Verzeichnis den Ordner, der die TV-App enthält
    (erkennt an Takvim-App.html). Gibt den Pfad oder None zurück."""
    marker = "Takvim-App.html"
    if os.path.isfile(os.path.join(path, marker)):
        return path
    for root, _dirs, files in os.walk(path):
        if marker in files:
            return root
    return None


def _stage_zip_updates():
    """Entpackt evtl. vorhandene .zip-Pakete im updates/-Ordner an Ort und
    Stelle (in einen temporären Unterordner), damit _find_app_root sie sieht."""
    import zipfile
    staged = []
    try:
        zips = [f for f in os.listdir(UPDATES_DIR)
                if f.lower().endswith(".zip")
                and os.path.isfile(os.path.join(UPDATES_DIR, f))]
    except Exception:
        return staged
    for z in sorted(zips):
        zpath = os.path.join(UPDATES_DIR, z)
        dest = os.path.join(UPDATES_DIR, "_entpackt_" + os.path.splitext(z)[0])
        try:
            shutil.rmtree(dest, ignore_errors=True)
            os.makedirs(dest, exist_ok=True)
            with zipfile.ZipFile(zpath) as zf:
                zf.extractall(dest)
            staged.append(dest)
            log("Update-ZIP entpackt: %s" % z)
        except Exception as e:
            log("ZIP-Entpackfehler (%s): %s" % (z, e))
    return staged


def staged_update():
    """Prüft updates/ auf eine neue TV-App und installiert sie mit Backup."""
    log("Schritt 3/5: Staged Update prüfen.")
    os.makedirs(UPDATES_DIR, exist_ok=True)

    _stage_zip_updates()
    src_root = _find_app_root(UPDATES_DIR)
    if not src_root:
        log("Kein Update in /updates/ gefunden — übersprungen.")
        return False

    log("Update gefunden in: %s" % src_root)
    try:
        # a) Aktuelle App als Backup sichern (altes Backup ersetzen)
        if os.path.isdir(APP_DIR):
            shutil.rmtree(BACKUP_DIR, ignore_errors=True)
            shutil.copytree(APP_DIR, BACKUP_DIR)
            log("Backup angelegt: takvim-app -> backup_previous.")

        # b) Neue App atomar einspielen: erst in Nachbarordner, dann tauschen
        new_dir = APP_DIR + ".new"
        shutil.rmtree(new_dir, ignore_errors=True)
        shutil.copytree(src_root, new_dir)
        old_dir = APP_DIR + ".old"
        shutil.rmtree(old_dir, ignore_errors=True)
        if os.path.isdir(APP_DIR):
            os.replace(APP_DIR, old_dir)
        os.replace(new_dir, APP_DIR)
        shutil.rmtree(old_dir, ignore_errors=True)
        log("✓ Update installiert -> takvim-app.")

        # c) updates/ leeren (verarbeitete Pakete entfernen)
        _clear_dir_contents(UPDATES_DIR)
        return True
    except Exception as e:
        log("✗ Update fehlgeschlagen: %s — versuche Rollback." % e)
        _restore_from_backup()
        return False


# ── Schritt 4: Browser-Neustart ──────────────────────────────────────────────
def kill_browser():
    for name in ("chromium-browser", "chromium", "chrome"):
        try:
            subprocess.run(["pkill", "-f", name],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=10)
        except Exception:
            pass


def start_browser():
    """Startet den Kiosk neu (über start_kiosk.sh, im Hintergrund/abgekoppelt)."""
    if os.path.isfile(START_KIOSK):
        try:
            subprocess.Popen(
                ["setsid", "bash", START_KIOSK],
                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                start_new_session=True)
            return True
        except Exception as e:
            log("start_kiosk.sh-Fehler: %s — Direktstart wird versucht." % e)
    # Fallback: Chromium direkt starten
    chrome = shutil.which("chromium-browser") or shutil.which("chromium")
    if not chrome:
        log("✗ Chromium nicht gefunden — Browser-Neustart fehlgeschlagen.")
        return False
    try:
        subprocess.Popen(
            [chrome, "--kiosk", "--noerrdialogs", "--disable-infobars",
             "--disable-session-crashed-bubble", KIOSK_URL],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            start_new_session=True)
        return True
    except Exception as e:
        log("✗ Browser-Direktstart fehlgeschlagen: %s" % e)
        return False


def restart_browser(reason=""):
    log("Schritt 4/5: Browser-Neustart%s." %
        ((" (" + reason + ")") if reason else ""))
    kill_browser()
    time.sleep(2)
    ok = start_browser()
    log("Browser neu gestartet: %s" % ("OK" if ok else "FEHLER"))
    return ok


# ── Rollback-Hilfe (für Express-Signal) ──────────────────────────────────────
def _restore_from_backup():
    """Kopiert backup_previous -> takvim-app (Wiederherstellung)."""
    if not os.path.isdir(BACKUP_DIR) or not os.listdir(BACKUP_DIR):
        log("⚠ Kein Backup vorhanden — Wiederherstellung nicht möglich.")
        return False
    try:
        new_dir = APP_DIR + ".rb"
        shutil.rmtree(new_dir, ignore_errors=True)
        shutil.copytree(BACKUP_DIR, new_dir)
        old_dir = APP_DIR + ".old"
        shutil.rmtree(old_dir, ignore_errors=True)
        if os.path.isdir(APP_DIR):
            os.replace(APP_DIR, old_dir)
        os.replace(new_dir, APP_DIR)
        shutil.rmtree(old_dir, ignore_errors=True)
        log("✓ takvim-app aus backup_previous wiederhergestellt.")
        return True
    except Exception as e:
        log("✗ Wiederherstellung fehlgeschlagen: %s" % e)
        return False


# ── Steuerdatei (Express-Rollback / Fernbefehle von pi_server) ───────────────
def handle_control_file():
    """Prüft die Steuerdatei und führt angeforderte Aktionen aus.
    Die Datei wird vom pi_server.py geschrieben (z. B. beim Express-Rollback)
    und hier nach Ausführung wieder geleert/aktualisiert (per 'seq')."""
    if not os.path.isfile(CONTROL_FILE):
        return
    try:
        with open(CONTROL_FILE, "r", encoding="utf-8") as f:
            ctrl = json.load(f)
    except Exception:
        return
    if not isinstance(ctrl, dict):
        return

    seq = ctrl.get("seq")
    state = load_state()
    if seq is not None and seq == state.get("last_control_seq"):
        return  # bereits abgearbeitet

    action = ctrl.get("action")
    if action == "restart_browser":
        log("Steuerbefehl empfangen: Browser-Neustart (%s)."
            % ctrl.get("reason", ""))
        # Beim Rollback hat pi_server takvim-app bereits zurückkopiert.
        # Sicherheitshalber den TV einschalten (falls im Standby) und neu starten.
        if ctrl.get("wake_tv"):
            tv_wake()
        restart_browser(reason=ctrl.get("reason", "Fernbefehl"))
        # Aufwach-/Schlafzustand aufheben: nach Rollback läuft die Anzeige normal
        state["pending_wake_at"] = None

    state["last_control_seq"] = seq
    save_state(state)


# ── Wartungs-Sequenz (Schritte 1–4 am Fensterstart) ──────────────────────────
def run_maintenance_open(start_dt):
    log("════ WARTUNGSFENSTER GESTARTET (%s) ════"
        % start_dt.strftime("%d.%m.%Y %H:%M"))
    tv_standby()                 # 1
    clear_browser_cache()        # 2
    staged_update()              # 3
    restart_browser("Wartung")   # 4
    wake_at = fajr_wake_after(start_dt)
    log("TV bleibt bis %s im Standby (Schritt 5 folgt automatisch)."
        % wake_at.strftime("%d.%m.%Y %H:%M"))
    return wake_at


# ── Hauptschleife ────────────────────────────────────────────────────────────
def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    log("=" * 62)
    log("MOSCHEE-TAKVIM · Wartungs-Dienst v%s gestartet." % VERSION)
    log("Basis: %s" % BASE)
    log("Fenster-Start = Isha + %d Min · Aufwachen = Fajr − %d Min."
        % (ISHA_OFFSET_MIN, FAJR_OFFSET_MIN))
    log("=" * 62)

    state = load_state()
    pending_wake_at = None
    if state.get("pending_wake_at"):
        try:
            pending_wake_at = datetime.fromisoformat(state["pending_wake_at"])
        except Exception:
            pending_wake_at = None

    last_maint_date = state.get("last_maintenance_date")
    logged_schedule_for = None

    while True:
        try:
            now = datetime.now()

            # (A) Express-Befehle stets zuerst (reaktionsschnell)
            handle_control_file()

            # Zustand könnte durch Rollback verändert worden sein
            st = load_state()
            if st.get("pending_wake_at") is None and "pending_wake_at" in st:
                pending_wake_at = None

            # (B) Aufwachen, wenn die Aufwachzeit erreicht ist
            if pending_wake_at is not None:
                if now >= pending_wake_at:
                    tv_wake()    # Schritt 5
                    log("════ WARTUNGSFENSTER BEENDET — TV wieder aktiv ════")
                    pending_wake_at = None
                    st["pending_wake_at"] = None
                    save_state(st)
                # während des Standbys nur weiter pollen
                time.sleep(POLL_INTERVAL_S)
                continue

            # (C) Fensterstart prüfen (einmal pro Kalendertag)
            today = now.date()
            start_dt = isha_start_for(now)

            if start_dt is not None and logged_schedule_for != today:
                log("Heutiges Wartungsfenster geplant für %s."
                    % start_dt.strftime("%H:%M"))
                logged_schedule_for = today

            already = (last_maint_date == today.isoformat())
            if (start_dt is not None and not already
                    and now >= start_dt
                    and now < start_dt + timedelta(hours=4)):
                # Fenster öffnen (Schritte 1–4) und Aufwachzeit setzen
                pending_wake_at = run_maintenance_open(start_dt)
                last_maint_date = today.isoformat()
                st = load_state()
                st["last_maintenance_date"] = last_maint_date
                st["pending_wake_at"] = pending_wake_at.isoformat()
                save_state(st)

            time.sleep(POLL_INTERVAL_S)

        except KeyboardInterrupt:
            log("Wartungs-Dienst beendet (STRG+C).")
            break
        except Exception as e:
            log("Unerwarteter Fehler in Hauptschleife: %s" % e)
            time.sleep(5)


if __name__ == "__main__":
    main()
