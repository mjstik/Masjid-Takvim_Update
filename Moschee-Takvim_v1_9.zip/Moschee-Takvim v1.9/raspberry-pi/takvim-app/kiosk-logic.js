/* ============================================================================
   MOSCHEE-TAKVIM · TV-ANZEIGE · kiosk-logic.js                          v1.7
   ----------------------------------------------------------------------------
   100 % offline-first: Alle Daten kommen vom lokalen Pi-Dienst (Port 8080).
   Neu in v1.7:
     · InfoTexte: Kategorie wird auf der TV NICHT mehr angezeigt (nur im
       Manager). Quellenangabe bleibt erhalten.
     · Next-Prayer: separate Leiste entfernt; der Countdown (HH:MM:SS) wird
       dezent in die aktive Gebetskachel integriert (updateTileCountdown).
     · Adhan/Ikamah-State-Machine ab Eintreffen der Gebetszeit (focusState):
       Phase 1 Adhan-Signal (~6 s) → Phase 2 Ikamah-Countdown (10 Min, Maghrib
       ausgenommen) mit Adhan-Du'a → Phase 3 (Restzeit ≤ 02:00): Du'a aus,
       Fokus nur auf der Ikamah-Restzeit.
     · Datum-Hierarchie: Gregorianisch zuerst/dominant, Hijri zurueckgenommen.
   Aus Etappe 5/4:
     · Termin-Events (CFG.events[]) ueberholen den Infotext-Pool zeitgesteuert.
     · Sprache wird ausschliesslich vom Manager gesetzt (config.sprache).
     · layout / override_layout (Design-Studio) werden ausgewertet (applyLayout).
     · /api/csv     -> Gebetszeiten (Spaltenzuordnung c0=Datum c1=Hijri c3=Fajr
                       c4=Sabah c5=Aufgang c6=Dhuhr c8=Asr c10=Maghrib
                       c12=Isha c13=Isha-Adhan)
     · /api/config  -> current_config.json (infotext, pool, design,
                       hintergrund, fokus, sprache)
     · /api/status  -> Poll; bei geaendertem updated_at wird die Konfiguration
                       neu geladen (Pool-Rotation laeuft auf dem Pi).
   ============================================================================ */

"use strict";

/* ── Sprachen (übernommen aus takvim1.html, + Fokus-Texte) ────────────────── */
const LANG = {
  de: { prayers: ['Morgengebet','Mittagsgebet','Nachmittagsgebet','Abendgebet','Nachtgebet'],
        ar: ['الفجر','الظهر','العصر','المغرب','العشاء'],
        next: 'Nächstes Gebet', nextTom: 'Nächstes Gebet (morgen)',
        beginn: 'Beginn', aufgang: 'Aufgang',
        days: ['So','Mo','Di','Mi','Do','Fr','Sa'],
        months: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
        fokusIn: 'in', adhan: 'Adhan', iqama: 'Iqama in',
        phones: 'Bitte Mobiltelefone ausschalten' },
  al: { prayers: ['Sabahu','Dreka','Ikindia','Akshami','Jacia'],
        ar: ['الفجر','الظهر','العصر','المغرب','العشاء'],
        next: 'Namazi i ardhshëm', nextTom: 'Namazi i ardhshëm (nesër)',
        beginn: 'Imsaku', aufgang: 'Lindja',
        days: ['Die','Hën','Mar','Mër','Enj','Pre','Sht'],
        months: ['Jan','Shk','Mar','Pri','Maj','Qer','Kor','Gus','Sht','Tet','Nën','Dhj'],
        fokusIn: 'pas', adhan: 'Ezani', iqama: 'Ikameti pas',
        phones: 'Ju lutemi fikni telefonat' },
  ar: { prayers: ['Fadschr','Dhuhr','Asr','Maghrib','Ischa'],
        ar: ['الفجر','الظهر','العصر','المغرب','العشاء'],
        next: 'Nächstes Gebet', nextTom: 'Nächstes Gebet (morgen)',
        beginn: 'Beginn', aufgang: 'Aufgang',
        days: ['So','Mo','Di','Mi','Do','Fr','Sa'],
        months: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'],
        fokusIn: 'in', adhan: 'الأذان · Adhan', iqama: 'الإقامة · Iqama in',
        phones: 'الرجاء إطفاء الهواتف · Bitte Mobiltelefone ausschalten' },
  en: { prayers: ['Fajr','Dhuhr','Asr','Maghrib','Isha'],
        ar: ['الفجر','الظهر','العصر','المغرب','العشاء'],
        next: 'Next Prayer', nextTom: 'Next Prayer (tomorrow)',
        beginn: 'Imsak', aufgang: 'Sunrise',
        days: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
        months: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'],
        fokusIn: 'in', adhan: 'Adhan', iqama: 'Iqama in',
        phones: 'Please switch off mobile phones' }
};

/* ── Statisches Duʿā' nach dem Adhān (Etappe 5, fester Text — NICHT aus der
   dynamischen Hadith-Bibliothek). Wird während des Iqama-Countdowns (Phase 3)
   ober- und unterhalb der Countdown-Kachel angezeigt. Dreisprachig, daher auf
   mehrere Balken verteilt, damit die Schrift groß bleibt. ───────────────────── */
const DUA_AFTER_ADHAN = {
  titel: '🕌 Das Duʿā’ nach dem Adhān',
  arabisch: 'اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ، وَالصَّلَاةِ الْقَائِمَةِ، آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ، وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ',
  de: '„O Allah, Herr dieses vollkommenen Rufes und des bevorstehenden Gebets, gewähre Muhammad die Wasilah (die höchste Stufe im Paradies) und die Vorzüglichkeit und erwecke ihn zu der lobenswerten Stellung, die Du ihm versprochen hast.“',
  al: '“O Allah, Zoti i këtij thirrjeje të përsosur dhe i këtij namazi që po falet, jepi Muhamedit wasilën (gradën më të lartë në Xhenet) dhe virtytin, dhe ringjalle atë në pozitën e lavdëruar që ia ke premtuar.”',
  quelle: 'Sahih al-Buchari, Nr. 614'
};

/* ── Zustand ──────────────────────────────────────────────────────────────── */
let CFG  = null;                 // current_config.json vom Pi
let DATA = {};                   // { 'dd.mm.yyyy': [fajr,sabah,aufgang,dhuhr,asr,maghrib,isha,ishaAdhan,hijri] }
let lang = 'de';
let lastUpdatedAt = null;        // config_updated_at vom letzten Status-Poll
let lastCsvRows   = -1;          // prayer.rows vom letzten Status-Poll
let lastRenderKey = '';          // verhindert unnötiges Neu-Rendern des Grids
let focusPhase    = 0;           // 0 = normal, 1–4 = Fokus-Phasen
let infoSig       = '';          // Signatur des aktuell angezeigten Infotexts
let nextPrayerKey      = null;   // data-key des naechsten Gebets (fuer Tile-Countdown)
let nextPrayerTargetSec = NaN;   // Ziel-Sekunde des Tages des naechsten Gebets

const IVS = { '30': 30*60*1000, '60': 60*60*1000, 'day': 24*60*60*1000 };
const I   = { fajr:0, sabah:1, sunrise:2, dhuhr:3, asr:4, maghrib:5, isha:6, isha_adhan:7, hijri:8 };
const KEYS = ['fajr','dhuhr','asr','maghrib','isha'];

const $ = id => document.getElementById(id);
const pad = n => String(n).padStart(2,'0');
const clean = t => (t||'').replace(/:00$/,'') || '--:--';
function tMin(t){ const p = clean(t).split(':'); return parseInt(p[0])*60 + parseInt(p[1]); }
function tSec(t){ const m = tMin(t); return isNaN(m) ? NaN : m*60; }
function dateKey(d){ return pad(d.getDate())+'.'+pad(d.getMonth()+1)+'.'+d.getFullYear(); }

/* v1.8 (Anf. 5 · WYSIWYG): Alle px-Angaben aus dem Design-Studio (Schriftgroessen,
   Positions-Offsets) sind auf die TV-Referenzaufloesung 1920 px bezogen — exakt
   wie im Manager-Editor (tvScale dort = Buehnenbreite/1920). Hier skalieren wir
   sie spiegelbildlich mit der TATSAECHLICHEN TV-Breite, damit ein im Editor
   gezogenes/skaliertes Element massstabsgetreu an derselben Stelle und Groesse
   landet — unabhaengig davon, ob das TV 1920, 1280 oder 3840 px breit ist. */
const TV_REF_W = 1920;
function tvScale(){
  const w = window.innerWidth || document.documentElement.clientWidth || TV_REF_W;
  return w / TV_REF_W;
}
/* Standard-Icon-Skalierung (identisch zu TE_DEFAULTS.iconScale im Manager),
   damit Editor-Vorschau und TV bei unveraenderter Kachel gleich aussehen. */
const DEFAULT_ICON_SCALE = 130;

/* ── Icons (1:1 aus takvim1.html) ─────────────────────────────────────────── */
const G = '#c5a55a';
const S = b => `<svg viewBox="0 0 32 32" width="34" height="34">${b}</svg>`;
const L  = `stroke="${G}" stroke-width="1.5" stroke-linecap="round"`;
const LT = `stroke="${G}" stroke-width="1.2" stroke-linecap="round"`;
const ICONS = {
  fajr:S(`<line x1="3" y1="25" x2="29" y2="25" ${L}/><path d="M 8 25 A 8 8 0 0 0 24 25" fill="rgba(197,165,90,.2)" stroke="${G}" stroke-width="1.5"/><line x1="16" y1="13" x2="16" y2="10" ${L}/><line x1="21" y1="15.5" x2="23" y2="13" ${L}/><line x1="11" y1="15.5" x2="9" y2="13" ${L}/><line x1="24.5" y1="20" x2="27" y2="19" ${L}/><line x1="7.5" y1="20" x2="5" y2="19" ${L}/><polyline points="13,8 16,5 19,8" fill="none" stroke="${G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  dhuhr:S(`<circle cx="16" cy="16" r="6" fill="rgba(197,165,90,.2)" stroke="${G}" stroke-width="1.5"/><line x1="16" y1="7" x2="16" y2="4" ${L}/><line x1="16" y1="25" x2="16" y2="28" ${L}/><line x1="7" y1="16" x2="4" y2="16" ${L}/><line x1="25" y1="16" x2="28" y2="16" ${L}/><line x1="10" y1="10" x2="8" y2="8" ${L}/><line x1="22" y1="22" x2="24" y2="24" ${L}/><line x1="22" y1="10" x2="24" y2="8" ${L}/><line x1="10" y1="22" x2="8" y2="24" ${L}/>`),
  asr:S(`<circle cx="16" cy="17" r="6" fill="rgba(197,165,90,.18)" stroke="${G}" stroke-width="1.5"/><line x1="16" y1="8" x2="16" y2="5" ${LT} opacity=".35"/><line x1="16" y1="26" x2="16" y2="29" ${L}/><line x1="7" y1="17" x2="4" y2="17" ${LT} opacity=".35"/><line x1="25" y1="17" x2="28" y2="17" ${L}/><line x1="10.5" y1="11.5" x2="8.5" y2="9.5" ${LT} opacity=".35"/><line x1="21.5" y1="22.5" x2="23.5" y2="24.5" ${L}/><line x1="21.5" y1="11.5" x2="23.5" y2="9.5" ${L}/><line x1="10.5" y1="22.5" x2="8.5" y2="24.5" ${L}/><path d="M 3 13 Q 10 8 16 11" fill="none" stroke="${G}" stroke-width="1" stroke-linecap="round" stroke-dasharray="1.5 2" opacity=".5"/>`),
  maghrib:S(`<line x1="3" y1="23" x2="29" y2="23" ${L}/><path d="M 8 23 A 8 8 0 0 0 24 23" fill="rgba(197,165,90,.2)" stroke="${G}" stroke-width="1.5"/><line x1="16" y1="11" x2="16" y2="8" ${L}/><line x1="21" y1="13.5" x2="23" y2="11" ${L}/><line x1="11" y1="13.5" x2="9" y2="11" ${L}/><line x1="24.5" y1="18" x2="27" y2="17" ${L}/><line x1="7.5" y1="18" x2="5" y2="17" ${L}/><polyline points="13,27 16,30 19,27" fill="none" stroke="${G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  isha:S(`<path d="M 20 7 A 10 10 0 1 0 20 25 A 6.5 6.5 0 1 1 20 7 Z" fill="rgba(197,165,90,.2)" stroke="${G}" stroke-width="1.5" stroke-linejoin="round"/><circle cx="22" cy="10" r="1" fill="${G}" opacity=".6"/><circle cx="24" cy="14" r=".8" fill="${G}" opacity=".4"/>`)
};

/* ════════════════════════════════════════════════════════════════════════════
   1) DATEN VOM PI
   ════════════════════════════════════════════════════════════════════════════ */

function parsePrayerCSV(text){
  const result = {};
  for (const line of text.split('\n')){
    if (!line.trim()) continue;
    const c = line.split(',').map(s => s.trim().replace(/^"|"$/g,''));
    if (!c[0] || !/^\d{2}\.\d{2}\.\d{4}$/.test(c[0])) continue;   // Kopf-/Leerzeilen
    result[c[0]] = [c[3], c[4], c[5], c[6], c[8], c[10], c[12], c[13], c[1]];
  }
  return result;
}

async function fetchCSV(){
  try {
    const r = await fetch('/api/csv', { cache: 'no-store' });
    if (!r.ok) throw new Error('keine CSV');
    const parsed = parsePrayerCSV(await r.text());
    if (Object.keys(parsed).length){ DATA = parsed; lastRenderKey = ''; }
  } catch (e) { /* offline-first: vorhandene DATA weiterverwenden */ }
  updateDataStatus();
}

async function fetchConfig(){
  try {
    const r = await fetch('/api/config', { cache: 'no-store' });
    const j = await r.json();
    if (j && j.ok && j.config){
      CFG = j.config;
      lastUpdatedAt = CFG.updated_at || null;
      applyConfig();
    }
  } catch (e) { /* Pi-Dienst kurz nicht erreichbar — Anzeige läuft weiter */ }
}

/* Status-Poll: erkennt neue Konfiguration & neue CSV vom Manager */
async function pollStatus(){
  try {
    const r = await fetch('/api/status', { cache: 'no-store' });
    const j = await r.json();
    $('led').className = 'led';
    if (!j || !j.ok) return;
    if (j.config_updated_at !== lastUpdatedAt) await fetchConfig();
    const rows = j.prayer ? (j.prayer.rows|0) : 0;
    if (rows !== lastCsvRows){ lastCsvRows = rows; if (rows > 0) await fetchCSV(); }
  } catch (e) {
    $('led').className = 'led off';
  }
}

/* ════════════════════════════════════════════════════════════════════════════
   2) KONFIGURATION ANWENDEN (Sprache · Design · Hintergrund · Infotext)
   ════════════════════════════════════════════════════════════════════════════ */

function applyConfig(){
  if (!CFG) return;

  // Sprache (überlebt Cache-Löschung, da in current_config.json gespeichert)
  const l = CFG.sprache;
  if (l && LANG[l] && l !== lang){ lang = l; lastRenderKey = ''; }
  markLangButtons();

  // Design-Slider (Etappe 4 steuert diese Werte; Standardwerte greifen sofort)
  const d = CFG.design || {};
  const root = document.documentElement.style;
  if (typeof d.blur    === 'number') root.setProperty('--tile-blur',  d.blur + 'px');
  if (typeof d.opacity === 'number') root.setProperty('--tile-alpha', (d.opacity/100).toFixed(2));
  if (typeof d.darken  === 'number') root.setProperty('--bg-darken',  (d.darken/100).toFixed(2));

  // Hintergrund aus der Mediathek
  const bg = $('bg');
  if (CFG.background){
    bg.classList.remove('default');
    bg.style.backgroundImage = "url('/mediathek/" + encodeURIComponent(CFG.background) + "')";
  } else {
    bg.classList.add('default');
    bg.style.backgroundImage = 'none';
  }

  applyLayout();
  applyInfotext();
  rerender();
}

/* Layout aus dem Design-Studio.
   v1.8 (Anf. 6): Der frueher waehlbare BLOCK-Modus (Verschieben/Skalieren des
   gesamten #app-Blocks ueber CFG.layout) wurde vollstaendig entfernt. Es gibt nur
   noch zwei Zustaende:
     1) FREIES Layout (CFG.override_layout.enabled) — jede Kachel wird einzeln und
        unabhaengig absolut positioniert. Dies ist das Standard-Verhalten, sobald
        im Manager etwas angeordnet wurde.
     2) Kein override gesetzt — die TV zeigt das normale Raster (Default-Anzeige).
   Ein evtl. in Bestands-Configs noch vorhandenes CFG.layout wird bewusst ignoriert
   (abwaertskompatibel, kein Block-Transform mehr). */
function applyLayout(){
  const app = $('app');
  const ov  = (CFG && CFG.override_layout) || null;

  if (ov && ov.enabled && ov.elements){
    document.body.classList.add('free-layout');
    app.style.transform = '';
    applyOverride(ov.elements);
    return;
  }

  // Standard-Raster (kein Einzel-Layout gesetzt)
  document.body.classList.remove('free-layout');
  clearOverride();
  app.style.transform = '';
}

/* Zuordnung Layout-ID -> DOM-Element auf der TV-Seite.
   v1.7: 'nextbar' entfaellt (separate Next-Prayer-Leiste wurde entfernt). */
function overrideTargets(){
  const app = $('app');
  const map = {
    clock:   app.querySelector('.clock'),
    info:    $('infoBox')
  };
  app.querySelectorAll('.grid .card[data-key]').forEach(card => {
    map['tile_' + card.dataset.key] = card;
  });
  return map;
}

function clampPct(v, lo, hi, d){
  return (typeof v === 'number' && isFinite(v)) ? Math.max(lo, Math.min(hi, v)) : d;
}

function clampOverrideBox(box){
  const w = clampPct(box.w, 3, 100, 20);
  const h = clampPct(box.h, 3, 100, 15);
  return {
    x: clampPct(box.x, 0, 100 - w, 0),
    y: clampPct(box.y, 0, 100 - h, 0),
    w, h,
  };
}

/* Positioniert die einzelnen Elemente absolut anhand der Prozent-Boxen
   und wendet pro-Kachel-Stile (Schriftgröße, Farbe, Deckkraft) an. */
function applyOverride(elements){
  const map = overrideTargets();
  Object.keys(map).forEach(id => {
    const el = map[id]; if (!el) return;
    const box = elements[id];
    if (box){
      const b = clampOverrideBox(box);
      el.style.position = 'absolute';
      el.style.left   = b.x + '%';
      el.style.top    = b.y + '%';
      el.style.width  = b.w + '%';
      el.style.height = b.h + '%';
      el.style.margin = '0';
      el.style.zIndex = '3';
      /* Per-Kachel-Stile (aus dem Design-Studio) */
      if (box.style) applyTileStyle(el, box.style);
    } else {
      el.style.position = 'absolute';
      el.style.left = '-9999px';
      el.style.top  = '0';
    }
  });
}

/* Wendet individuelle Schrift-/Farbeinstellungen auf ein TV-Element an.
   v1.8: Pixel-Werte (Schrift + Positions-Offsets) werden massstabsgetreu mit der
   TV-Breite skaliert (siehe tvScale), Offsets ebenso. iconScale ist ein reines
   Verhaeltnis und wird zusammen mit der responsiven Icon-Basis (CSS) angewandt;
   so kommt eine Vergroesserung des Symbols 1:1 auf der TV an (Anf. 5d). */
function applyTileStyle(el, sty){
  sty = sty || {};
  const sc  = tvScale();
  const fpx = v => (typeof v === 'number' && v > 0) ? (v * sc).toFixed(1) + 'px' : '';
  const off = v => (typeof v === 'number' ? v : 0) * sc;
  const trans = (x, y) => (x || y) ? 'translate(' + off(x).toFixed(1) + 'px,' + off(y).toFixed(1) + 'px)' : '';

  /* v1.9 (Anf. 2): Die Uhr ist ein vollwertiges Textelement. Sie traegt KEINE
     .ptime/.fajr-main, sondern .time-big (+ optional .secs). Wird unten separat
     behandelt, damit die Sekundenanzeige proportional mitskaliert. */
  const isClock = el.classList && el.classList.contains('clock');
  const clockEl = isClock ? el.querySelector('.time-big') : null;
  const secEl   = isClock ? el.querySelector('.secs')     : null;

  const timeEl = clockEl
              || el.querySelector('.ptime') || el.querySelector('.fajr-main');
  const nameEl = el.querySelector('.name-de') || el.querySelector('.hadith-text');
  const arEl   = el.querySelector('.name-ar') || el.querySelector('.hadith-arabic');
  const iconEl = el.querySelector('.icon');
  const srcEl  = el.querySelector('.hadith-quelle');
  if (timeEl){
    timeEl.style.fontSize  = fpx(sty.timeFontSize);
    timeEl.style.color     = sty.timeColor || '';
    /* Innere Verschiebung nur für Kachel-Uhrzeit, nicht für die Uhr selbst
       (deren Position regelt die override-Box — analog zum Editor). */
    timeEl.style.transform = isClock ? '' : trans(sty.pos_ptime_x, sty.pos_ptime_y);
  }
  /* Sekunden der Uhr proportional zur Hauptgroesse halten (~0,46 wie im CSS:
     4vw / 8.6vw), wenn eine eigene Uhr-Schriftgroesse gesetzt wurde. */
  if (secEl && typeof sty.timeFontSize === 'number' && sty.timeFontSize > 0){
    secEl.style.fontSize = (sty.timeFontSize * sc * 0.46).toFixed(1) + 'px';
  }
  if (nameEl){
    nameEl.style.fontSize  = fpx(sty.nameFontSize);
    nameEl.style.color     = sty.nameColor || '';
    nameEl.style.transform = trans(sty.pos_nameDe_x, sty.pos_nameDe_y);
  }
  if (arEl){
    arEl.style.fontSize  = fpx(sty.arFontSize);
    arEl.style.color     = sty.arColor || '';
    arEl.style.transform = trans(sty.pos_nameAr_x, sty.pos_nameAr_y);
  }
  /* Quelle (Hadith) — bewusst eher klein gehalten, aber individuell setzbar */
  if (srcEl){
    srcEl.style.fontSize = fpx(sty.srcFontSize);
    srcEl.style.color    = sty.srcColor || '';
  }
  /* Icon: iconScale wird IMMER gesetzt (Default 130), damit die Datenbindung
     eindeutig ist und Editor/TV bei gleicher Basis identisch aussehen. */
  if (iconEl){
    const s = ((typeof sty.iconScale === 'number' ? sty.iconScale : DEFAULT_ICON_SCALE) / 100).toFixed(2);
    const t = trans(sty.pos_icon_x, sty.pos_icon_y);
    iconEl.style.transform = 'scale(' + s + ')' + (t ? ' ' + t : '');
  }
  /* Fajr: Beginn/Aufgang Sub-Elemente */
  el.querySelectorAll('.fajr-sub-label').forEach(lb => {
    if (sty.fajrLabelSize) lb.style.fontSize = fpx(sty.fajrLabelSize);
    if (sty.fajrLabelColor) lb.style.color = sty.fajrLabelColor;
  });
  el.querySelectorAll('.fajr-sub-time').forEach(tm => {
    if (sty.fajrTimeSize) tm.style.fontSize = fpx(sty.fajrTimeSize);
    if (sty.fajrTimeColor) tm.style.color = sty.fajrTimeColor;
  });
  if (typeof sty.bgOpacity === 'number'){
    el.style.background = 'rgba(13,20,38,' + (sty.bgOpacity/100).toFixed(2) + ')';
  }
}

function clearOverride(){
  const map = overrideTargets();
  Object.keys(map).forEach(id => {
    const el = map[id]; if (!el) return;
    el.style.position = '';
    el.style.left = el.style.top = el.style.width = el.style.height = '';
    el.style.margin = el.style.zIndex = '';
  });
}

/* Parst eine "von"/"bis"-Angabe eines Termins in einen Zeitstempel (ms).
   Akzeptiert ISO-artige lokale Angaben "YYYY-MM-DDTHH:MM" (datetime-local) und
   "YYYY-MM-DD HH:MM". Gibt NaN zurück, wenn leer/ungültig. */
function parseEventTs(v){
  if (!v) return NaN;
  const s = String(v).trim().replace(' ', 'T');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
  if (m){
    return new Date(+m[1], +m[2]-1, +m[3], +m[4], +m[5], 0).getTime();
  }
  const t = Date.parse(s);
  return isNaN(t) ? NaN : t;
}

/* Aktiven Termin bestimmen (Etappe 5): der ERSTE Termin in CFG.events, der
   aktiviert ist und dessen Zeitfenster [von, bis] die aktuelle Zeit enthält.
   Fehlt "von" -> gilt ab sofort; fehlt "bis" -> gilt unbegrenzt. Termine
   überholen den Pool und blenden sich nach Ablauf selbst aus. */
function currentEvent(){
  if (!CFG || !Array.isArray(CFG.events)) return null;
  const now = Date.now();
  for (const ev of CFG.events){
    if (!ev || ev.aktiv === false) continue;
    const hasContent = (ev.text||'').trim() || (ev.titel||'').trim() || (ev.arabisch||'').trim();
    if (!hasContent) continue;
    const von = parseEventTs(ev.von);
    const bis = parseEventTs(ev.bis);
    if (!isNaN(von) && now < von) continue;     // noch nicht begonnen
    if (!isNaN(bis) && now > bis) continue;     // bereits abgelaufen -> ausblenden
    return ev;
  }
  return null;
}

/* Aktiven Infotext bestimmen: Termin-Event (Vorrang) -> Pool-Rotation ->
   fixer Einzeltext. */
function currentInfotext(){
  if (!CFG) return null;

  // 1) Termin-Event hat Vorrang vor allem (Etappe 5)
  const ev = currentEvent();
  if (ev) return ev;

  // 2) Pool-Rotation
  const pool = CFG.pool || {};
  if (pool.aktiv && Array.isArray(pool.eintraege) && pool.eintraege.length){
    const iv = IVS[pool.intervall] || IVS['30'];
    return pool.eintraege[Math.floor(Date.now()/iv) % pool.eintraege.length];
  }

  // 3) fixer Einzeltext
  const t = CFG.infotext;
  if (t && ((t.text||'').trim() || (t.titel||'').trim() || (t.arabisch||'').trim())) return t;
  return null;
}

function applyInfotext(){
  const t = currentInfotext();
  const box = $('infoBox');
  if (!t){
    box.classList.add('hidden');
    infoSig = '';
    return;
  }
  const sig = JSON.stringify([t.titel, t.arabisch, t.text, t.kategorie, t.quelle]);
  if (sig === infoSig) return;                       // unverändert -> kein DOM-Update
  infoSig = sig;

  box.classList.remove('hidden');
  $('hLoad').style.display = 'none';
  $('hContent').style.display = 'block';

  $('hTitel').textContent = (t.titel||'').trim();

  const arab = (t.arabisch||'').trim();
  $('hArabic').textContent = arab;
  $('hArabic').className = arab ? 'hadith-arabic visible' : 'hadith-arabic';

  const txt = (t.text||'').trim();
  const el = $('hText');
  el.textContent = txt;
  el.style.display = txt ? '' : 'none';

  /* Automatische Schriftgröße nur setzen, wenn KEINE benutzerdefinierte
     Schriftgröße über das Design-Studio (override_layout) gesetzt ist.
     Werte für TV-Lesbarkeit aus der Entfernung deutlich vergrößert (Etappe 5). */
  const infoSty = CFG && CFG.override_layout && CFG.override_layout.enabled
    && CFG.override_layout.elements && CFG.override_layout.elements.info
    && CFG.override_layout.elements.info.style;
  if (!infoSty || !infoSty.nameFontSize) {
    el.style.fontSize  = txt.length < 100 ? '2.5vw' : txt.length < 220 ? '2.1vw' : '1.8vw';
  }
  el.style.lineHeight = txt.length < 100 ? '1.5' : txt.length < 220 ? '1.45' : '1.4';

  /* v1.7: Kategorie wird auf der TV NICHT mehr angezeigt (nur im Manager).
     Das fruehere #hKat-Element wurde aus dem HTML entfernt. */

  const quelle = (t.quelle||'').trim();
  $('hQuelle').textContent = quelle;
  $('hQuelle').style.display = quelle ? 'inline-block' : 'none';

  $('hStat').className = 'hadith-status ok';
}

/* ════════════════════════════════════════════════════════════════════════════
   3) SPRACHE (Auswahl wird im Pi gespeichert -> übersteht Cache-Löschung)
   ════════════════════════════════════════════════════════════════════════════ */

function markLangButtons(){
  /* Die Sprach-Buttons saßen früher im Zahnrad-Panel der TV-Seite. Dieses
     Panel wurde in Etappe 5 entfernt (Sprache kommt vom Manager). Falls die
     Buttons fehlen, ist dies ein No-Op. */
  ['DE','AL','AR','EN'].forEach(x => {
    const b = $('btn'+x);
    if (b) b.className = 's-btn' + (lang === x.toLowerCase() ? ' active' : '');
  });
}

async function setLang(l){
  if (!LANG[l]) return;
  lang = l; lastRenderKey = '';
  markLangButtons();
  const sp = $('settingsPanel');
  if (sp) sp.className = 'settings-panel';
  rerender();
  try {
    await fetch('/api/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sprache: l })
    });
  } catch (e) { /* lokal bereits umgeschaltet */ }
}
window.setLang = setLang;

/* ════════════════════════════════════════════════════════════════════════════
   4) GEBETSZEITEN-ANZEIGE (Basis: takvim1.html)
   ════════════════════════════════════════════════════════════════════════════ */

function renderFajr(d){
  const LL = LANG[lang], main = clean(d[I.sabah]), bg = clean(d[I.fajr]), sr = clean(d[I.sunrise]);
  return `<div class="card" data-key="fajr"><div class="icon">${ICONS.fajr}</div><div><div class="name-de">${LL.prayers[0]}</div><div class="name-ar">${LL.ar[0]}</div></div><div class="ptime-block"><div class="fajr-main">${main}</div><div class="tile-countdown" data-cd="fajr"></div></div><div class="fajr-sub"><div style="text-align:left"><span class="fajr-sub-label">${LL.beginn}</span><span class="fajr-sub-time">${bg}</span></div><div style="text-align:right"><span class="fajr-sub-label">${LL.aufgang}</span><span class="fajr-sub-time">${sr}</span></div></div></div>`;
}

function renderGrid(d){
  const LL = LANG[lang];
  $('grid').innerHTML = KEYS.map((k,i)=>{
    if (k === 'fajr') return renderFajr(d);
    const idx = [I.dhuhr, I.asr, I.maghrib, I.isha][i-1], t = clean(d[idx]);
    let sub = '';
    if (k === 'isha'){
      const ia = clean(d[I.isha_adhan]), it = clean(d[I.isha]);
      if (ia !== '--:--' && ia !== it)
        sub = `<div style="margin-top:6px;padding-top:5px;border-top:1px solid rgba(255,255,255,.12);font-size:10px;color:#8a96b6;width:100%">Adhan <span style="color:#ffd966;font-size:12px;font-weight:600">${ia}</span></div>`;
    }
    return `<div class="card" data-key="${k}"><div class="icon">${ICONS[k]}</div><div><div class="name-de">${LL.prayers[i]}</div><div class="name-ar">${LL.ar[i]}</div></div><div class="ptime-block"><div class="ptime">${t}</div><div class="tile-countdown" data-cd="${k}"></div></div><div>${sub}</div></div>`;
  }).join('');
}

/* Naechstes Gebet bestimmen + Kachel-Zustaende setzen (minuetlich, via rerender).
   v1.7: Die separate Next-Prayer-Leiste entfaellt. Stattdessen wird die Kachel
   des naechsten Gebets als .active markiert und der Sekunden-Countdown direkt
   dort eingeblendet (updateTileCountdown). */
function updateStates(d, tom){
  const now = new Date(), cur = now.getHours()*60 + now.getMinutes();
  const times = KEYS.map(k => ({ key:k,
    t: tMin(k==='fajr' ? d[I.sabah] : k==='dhuhr' ? d[I.dhuhr] : k==='asr' ? d[I.asr] : k==='maghrib' ? d[I.maghrib] : d[I.isha]) }));
  let ni = -1, nm = Infinity;
  times.forEach((p,i)=>{ if (p.t > cur && p.t < nm){ nm = p.t; ni = i; } });
  let nd = false;
  if (ni === -1 && tom){ ni = 0; nm = tMin(tom[I.sabah]) + 1440; nd = true; }
  else if (ni === -1){ ni = 0; nd = true; }

  const nextKey = times[ni] ? times[ni].key : null;
  document.querySelectorAll('.card[data-key]').forEach(c=>{
    const k = c.dataset.key, f = times.find(x=>x.key===k); if (!f) return;
    c.className = 'card';
    // Naechstes Gebet hervorheben — auch wenn es erst morgen ist (Fajr).
    if (k === nextKey) c.className = 'card active';
    else if (!nd && f.t < cur) c.className = 'card passed';
    else if (nd) c.className = 'card passed';
  });

  // Ziel-Sekunde des Tages fuer den Countdown merken (NaN -> kein Countdown).
  nextPrayerKey = (nextKey && isFinite(nm)) ? nextKey : null;
  nextPrayerTargetSec = isFinite(nm) ? (nm % 1440) * 60 : NaN;
}

function rerender(){
  const now = new Date(), tk = dateKey(now), d = DATA[tk];
  if (!d) return;
  const t2 = new Date(now); t2.setDate(t2.getDate()+1);
  renderGrid(d);
  updateStates(d, DATA[dateKey(t2)] || null);
  // Kacheln wurden neu erzeugt -> Freies Layout erneut anwenden
  if (document.body.classList.contains('free-layout')) applyLayout();
  updateTileCountdown(now);
}

/* HH:MM:SS-Formatierung fuer den in die Gebetskachel integrierten Countdown. */
function fmtHMS(totalSec){
  const s = Math.max(0, Math.floor(totalSec));
  return pad(Math.floor(s/3600)) + ':' + pad(Math.floor((s%3600)/60)) + ':' + pad(s%60);
}

/* Sekuendlicher Countdown zum naechsten Gebet, direkt in der aktiven Kachel
   (v1.7, Anf. 2). Die Gebetszeit bleibt das dominante Element; der Countdown
   ist als dezente, sekundaere Information darunter platziert. Nur die aktive
   Kachel zeigt ihn (CSS), daher genuegt es, den Text dort zu setzen. */
function updateTileCountdown(now){
  const all = document.querySelectorAll('.tile-countdown');
  if (!nextPrayerKey || !isFinite(nextPrayerTargetSec)){
    all.forEach(el => { el.textContent = ''; });
    return;
  }
  const nowSec = now.getHours()*3600 + now.getMinutes()*60 + now.getSeconds();
  let remain = nextPrayerTargetSec - nowSec;
  if (remain < 0) remain += 86400;               // naechstes Gebet ist morgen
  const txt = fmtHMS(remain);
  all.forEach(el => {
    el.textContent = (el.dataset.cd === nextPrayerKey) ? txt : '';
  });
}

function updateDataStatus(){
  /* #dataStatus saß früher im (in Etappe 5 entfernten) Einstellungs-Panel der
     TV-Seite. Auf der TV existiert das Element nicht mehr — daher abgesichert,
     damit fetchCSV()/init() nicht abbrechen. */
  const el = $('dataStatus');
  if (!el) return;
  const n = Object.keys(DATA).length;
  const today = DATA[dateKey(new Date())];
  el.innerHTML = n
    ? `Gebetszeiten: <b>${n} Tage</b> lokal auf dem Pi<br>Heute: <b>${today ? '✓ vorhanden' : '⚠ fehlt'}</b>`
    : '⚠ Keine Gebetszeiten — bitte im Takvim-Manager importieren';
}

/* ════════════════════════════════════════════════════════════════════════════
   5) FOKUS-MODUS — Adhan/Ikamah-State-Machine ab Eintreffen der Gebetszeit (v1.7)
      Ablauf je Gebet exakt ab dem Adhan-Zeitpunkt t:

      Phase 1  (Adhan-Signal):   t … t + sig      — eine fokussierte Kachel
               signalisiert, dass der Adhan gerufen wird (sig = adhan_signal_sec,
               ca. 5–8 s).
      Phase 2  (Ikamah + Du'a):  t + sig … (t + iq) − 120
               Fliessender Wechsel zum Ikamah-Countdown; parallel werden die
               Du'a-Balken (DUA_AFTER_ADHAN) ein-/oben-/untergeblendet.
               iq = 10 Min fuer Fajr/Dhuhr/Asr/Isha. Maghrib: iq = 0 → keine
               Phase 2/3 (Anf. 3A: sofortige Ikamah ohne Countdown).
      Phase 3  (Fokus-Wechsel):  (t + iq) − 120 … t + iq   (Restzeit ≤ 02:00)
               Du'a wird ausgeblendet; der Fokus liegt ausschliesslich auf der
               Ikamah-Restzeit.
      Phase 4  (optional):       t + iq … t + iq + dark — TV abdunkeln
               (abdunkeln_min; Standard 0 = aus). Bei Maghrib ab t + sig.
   ════════════════════════════════════════════════════════════════════════════ */

function fokusCfg(){
  const f = (CFG && CFG.fokus) || {};
  /* Dauer des Adhan-Signals (Phase 1): konfigurierbar, Standard 6 s, auf den
     vom Pflichtenheft genannten Bereich 5–8 s begrenzt. */
  let sig = f.adhan_signal_sec ?? 6;
  sig = Math.max(5, Math.min(8, sig));
  return {
    sig,
    iq:   (f.iqama_countdown_min ?? 10) * 60,
    dark: (f.abdunkeln_min       ?? 0)  * 60
  };
}

/* Athan-Zeitpunkte des Tages in Sekunden (Isha: Adhan-Spalte, falls vorhanden) */
function athanTimes(d){
  const list = [];
  KEYS.forEach((k,i)=>{
    let t;
    if (k === 'fajr')      t = tSec(d[I.sabah]);
    else if (k === 'dhuhr') t = tSec(d[I.dhuhr]);
    else if (k === 'asr')   t = tSec(d[I.asr]);
    else if (k === 'maghrib') t = tSec(d[I.maghrib]);
    else { const ad = tSec(d[I.isha_adhan]); t = isNaN(ad) ? tSec(d[I.isha]) : ad; }
    if (!isNaN(t)) list.push({ key:k, i, t });
  });
  return list;
}

function fmtCd(s){ return pad(Math.floor(s/60)) + ':' + pad(s % 60); }

/* Iqama-Dauer je Gebet (Anf. 3A/3B):
   Maghrib hat KEINEN Ikamah-Countdown (sofortige Ikamah ohne Wartezeit).
   Fajr, Dhuhr, Asr, Isha: konfigurierte Dauer (Standard 10 Min). */
function iqamaSecondsFor(key, F){
  return key === 'maghrib' ? 0 : F.iq;
}

/* Schwelle fuer den Fokus-Wechsel (Phase 3): letzte 2 Minuten (≤ 02:00). */
const IKAMAH_FOCUS_THRESHOLD = 120;

function focusState(now, d){
  const F = fokusCfg();
  const sec = now.getHours()*3600 + now.getMinutes()*60 + now.getSeconds();
  for (const p of athanTimes(d)){
    const t  = p.t;                       // Adhan-Zeitpunkt
    const iq = iqamaSecondsFor(p.key, F); // Ikamah-Dauer (0 = Maghrib)

    // Phase 1: Adhan-Signal exakt ab Eintreffen, fuer sig Sekunden.
    if (sec >= t && sec < t + F.sig) return { phase:1, p };

    if (iq > 0){
      const iqEnd  = t + iq;                                   // Ikamah-Ende
      const p3Start = Math.max(t + F.sig, iqEnd - IKAMAH_FOCUS_THRESHOLD);
      // Phase 2: Ikamah-Countdown mit Du'a (bis Restzeit 02:00 erreicht ist).
      if (sec >= t + F.sig && sec < p3Start)
        return { phase:2, p, remain: iqEnd - sec };
      // Phase 3: letzte 2 Minuten — Du'a aus, Fokus nur auf Ikamah-Restzeit.
      if (sec >= p3Start && sec < iqEnd)
        return { phase:3, p, remain: iqEnd - sec };
      // Phase 4: optionales Abdunkeln nach Ablauf der Ikamah.
      if (F.dark > 0 && sec >= iqEnd && sec < iqEnd + F.dark)
        return { phase:4, p };
    } else {
      // Maghrib: keine Ikamah → nach dem Adhan-Signal optional abdunkeln.
      if (F.dark > 0 && sec >= t + F.sig && sec < t + F.sig + F.dark)
        return { phase:4, p };
    }
  }
  return null;
}

/* Füllt die statischen Duʿā'-Balken einmalig mit dem festen Text. */
let duaFilled = false;
function fillDuaBars(){
  if (duaFilled) return;
  const set = (id, val) => { const el = $(id); if (el) el.textContent = val; };
  set('duaTitle',  DUA_AFTER_ADHAN.titel);
  set('duaArabic', DUA_AFTER_ADHAN.arabisch);
  set('duaDe',     DUA_AFTER_ADHAN.de);
  set('duaAl',     DUA_AFTER_ADHAN.al);
  set('duaSrc',    DUA_AFTER_ADHAN.quelle);
  duaFilled = true;
}

function applyFocus(now){
  const d = DATA[dateKey(now)];
  const st = d ? focusState(now, d) : null;
  const phase = st ? st.phase : 0;

  document.body.classList.toggle('focus-active', phase >= 1 && phase <= 3);
  document.body.classList.toggle('phase-1', phase === 1);   // Adhan-Signal (pulsiert)
  document.body.classList.toggle('phase-3', phase === 3);   // exklusiver Ikamah-Fokus
  document.body.classList.toggle('phase-4', phase === 4);   // Abdunkeln
  /* Du'a-Balken nur waehrend des Ikamah-Countdowns mit Restzeit > 02:00
     (Phase 2). In Phase 3 (letzte 2 Min) und bei Maghrib werden sie nie
     gezeigt (Anf. 3). */
  document.body.classList.toggle('dua-active', phase === 2);
  if (phase === 2) fillDuaBars();

  if (!st){ focusPhase = 0; return; }
  focusPhase = phase;
  if (phase === 4) return;                       // nur Blackout, keine Karte

  const LL = LANG[lang], p = st.p;
  $('fIcon').innerHTML = ICONS[p.key];
  $('fAr').textContent   = LL.ar[p.i];
  $('fName').textContent = LL.prayers[p.i];

  if (phase === 1){
    // Adhan-Signal: kein Countdown, klares Adhan-Signal.
    $('fBig').textContent = LL.adhan;
    $('fSub').textContent = '';
  } else {
    // Phase 2 + 3: Ikamah-Countdown (Phase 3 ohne Du'a, voller Fokus).
    $('fBig').textContent = fmtCd(st.remain);
    $('fSub').innerHTML = LL.iqama + ' ' + fmtCd(st.remain)
      + '<span class="phone">📵 ' + LL.phones + '</span>';
  }
}

/* ════════════════════════════════════════════════════════════════════════════
   6) UHR-TICK & STARTSEQUENZ
   ════════════════════════════════════════════════════════════════════════════ */

function tick(){
  const now = new Date(), LL = LANG[lang];
  $('hm').textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
  $('sc').textContent = ':' + pad(now.getSeconds());
  $('bClock').textContent = pad(now.getHours()) + ':' + pad(now.getMinutes());
  $('greg').textContent = LL.days[now.getDay()] + ', ' + now.getDate() + '. '
                        + LL.months[now.getMonth()] + ' ' + now.getFullYear();

  const d = DATA[dateKey(now)];
  if (d) $('hijri').textContent = (d[I.hijri]||'').trim() ? d[I.hijri] + ' H' : '—';

  // Grid/Status nur neu rendern, wenn Minute, Tag oder Sprache wechselt
  const rk = dateKey(now) + '|' + now.getHours() + ':' + now.getMinutes() + '|' + lang;
  if (rk !== lastRenderKey){ lastRenderKey = rk; rerender(); applyInfotext(); }

  updateTileCountdown(now);         // Countdown in der Gebetskachel (sekundengenau)

  applyFocus(now);                 // sekundengenau (Countdowns)
}

/* Einstellungen-Panel wurde in Etappe 5 entfernt — keine Klick-Handler mehr.
   Alle Änderungen (inkl. Sprache) erfolgen ausschließlich über den Manager. */

/* Start: Konfiguration + Gebetszeiten vom Pi, dann Uhr & Polling */
(async function init(){
  markLangButtons();

  // Ohne Pi-Dienst geöffnet (file://)? Dann Hinweis zeigen — die Uhr läuft
  // trotzdem, aber Gebetszeiten/Config können nicht geladen werden.
  if (location.protocol === 'file:'){
    const w = $('fileWarn'); if (w) w.classList.add('show');
  }

  await fetchConfig();
  await fetchCSV();
  tick();
  setInterval(tick, 1000);
  setInterval(pollStatus, 2000);                 // Manager-Änderungen erkennen
  setInterval(fetchCSV, 6*60*60*1000);           // Sicherheitsnetz: alle 6 h

  /* v1.8 (Anf. 5c): Aendert sich die TV-Aufloesung/Fenstergroesse, die
     massstabsgetreuen px-Werte des Frei-Layouts neu berechnen, damit die
     Anordnung proportional erhalten bleibt. */
  let _rsz = null;
  window.addEventListener('resize', () => {
    clearTimeout(_rsz);
    _rsz = setTimeout(() => { if (document.body.classList.contains('free-layout')) applyLayout(); }, 150);
  });
})();
