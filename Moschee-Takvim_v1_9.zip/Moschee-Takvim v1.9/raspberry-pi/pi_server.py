#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
================================================================================
 MOSCHEE-TAKVIM  —  PI-EMPFÄNGER-DIENST                              Etappe 6
================================================================================
 Neu in Etappe 6 (Persistenz, Wartung, Update/Rollback):
   POST /api/update?name=….zip -> TV-App-Update als ZIP in /updates/ ablegen
                                  (der Wartungs-Dienst spielt es nachts ein).
   POST /api/rollback          -> EXPRESS-ROLLBACK (hochpriorisiert):
                                  kopiert sofort backup_previous/ -> takvim-app/
                                  und schreibt control.json, woraufhin der
                                  Wartungs-Dienst den Browser in < 5 s neu
                                  startet (Notfall: „letzte stabile Version").
   GET  /api/update            -> Status zu Backup & wartendem Update.
   /api/status enthält zusätzlich backup_present / update_pending.
   Persistenz (Modul 1): alle Schreibvorgänge bereits atomar (atomic_write:
   Temp-Datei + fsync + os.replace); Boot lädt lokal aus takvim-data/ (100 %
   Offline-First) — der systemd-Dienst startet automatisch beim Booten.
================================================================================
 Neu in Etappe 4 (Design-Studio):
   GET    /api/media        -> Liste der Mediathek-Bilder (Name, Größe, Maße)
                               + aktuell gesetzter Hintergrund
   POST   /api/media?name=… -> Bild-Upload (Roh-Bytes im Body) in mediathek/
   DELETE /api/media?name=… -> Bild löschen (entfernt es auch als Hintergrund,
                               falls es gerade aktiv war)
   CORS-Header jetzt auch für /mediathek/ (damit die Kontrast-Analyse im
   Manager das Bild auf eine Canvas lesen darf, ohne sie zu „verunreinigen")
   design.blur/opacity/darken, background und layout werden über das bereits
   bestehende /api/config gepflegt (Top-Level-Merge) — die TV-App wertet sie aus.

 Neu in Etappe 3:
   GET /api/csv       -> gespeicherte Gebetszeiten-CSV ausliefern (für die
                         neue Takvim-App.html auf dem TV)
   "sprache" im Config-Schema (TV-Sprachwahl überlebt Cache-Löschung)
   Kein Browser-Caching mehr für .css/.js der TV-App (Updates greifen sofort)
   /api/status wird nicht mehr geloggt (TV-App pollt alle 5 s)
   (alle Etappe-1/2-Endpunkte unverändert erhalten)
================================================================================
 Neu in Etappe 5 (Termin-Events):
   Die TV-App wertet jetzt config.events[] aus (Termine mit "von"/"bis", die
   den Infotext-Pool zeitgesteuert überholen und sich selbst wieder ausblenden).
   Auf der Server-Seite sind keine neuen Endpunkte nötig: events[] wird – wie
   alle Top-Level-Schlüssel – über das bestehende POST /api/config gepflegt
   (Top-Level-Merge) und über GET /api/config ausgeliefert. DEFAULT_CONFIG
   enthält events[] bereits seit Etappe 3.
   Bugfix: log_message() stellt das Unterdrücken der /api/ping- und
   /api/status-Logzeilen wieder her (war in Etappe 4 versehentlich in
   do_DELETE verschmolzen und dadurch wirkungslos).
================================================================================
"""
import json
import os
import re
import sys
import time
import socket
import struct
from datetime import datetime
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

VERSION = "1.9.0"
PORT = 8080

# Erlaubte Bild-Endungen für die Mediathek
MEDIA_EXTS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
MEDIA_MAX_BYTES = 15 * 1024 * 1024   # 15 MB pro Bild

# ── Basisverzeichnis ─────────────────────────────────────────────────────────
BASE = os.environ.get("TAKVIM_BASE") or os.path.dirname(os.path.abspath(__file__))

APP_DIR     = os.path.join(BASE, "takvim-app")
DATA_DIR    = os.path.join(BASE, "takvim-data")
MEDIA_DIR   = os.path.join(BASE, "mediathek")
BACKUP_DIR  = os.path.join(BASE, "backup_previous")
UPDATES_DIR = os.path.join(BASE, "updates")

CONFIG_FILE = os.path.join(DATA_DIR, "current_config.json")
CSV_FILE    = os.path.join(DATA_DIR, "gebetszeiten_jahr.csv")
# Steuerdatei: Brücke vom (display-losen) Server zum Wartungs-Dienst,
# der im grafischen Login läuft und den Browser neu starten kann.
CONTROL_FILE = os.path.join(DATA_DIR, "control.json")

# Erlaubte Endung für TV-App-Update-Pakete (Modul 3 / Staged Update)
UPDATE_EXTS = {".zip"}
UPDATE_MAX_BYTES = 100 * 1024 * 1024   # 100 MB pro Update-Paket

START_TIME = time.time()

# ── Standard-Konfiguration ───────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "schema": 1,
    "updated_at": None,
    "sprache": "de",
    "infotext": None,
    "pool": {
        "aktiv": False,
        "intervall": "30",
        "eintraege": []
    },
    "events": [],
    "background": None,
    "design": {
        "blur": 12,
        "opacity": 55,
        "darken": 30
    },
    "layout": {},
    "fokus": {
        "adhan_signal_sec": 6,
        "iqama_countdown_min": 10,
        "abdunkeln_min": 0
    },
    "override_layout": None
}


# ── Hilfsfunktionen: Persistenz ──────────────────────────────────────────────
def ensure_dirs():
    for d in (APP_DIR, DATA_DIR, MEDIA_DIR, BACKUP_DIR, UPDATES_DIR):
        os.makedirs(d, exist_ok=True)


def atomic_write(path, data_bytes):
    """
    Sofort-Persistenz: erst Temp-Datei, fsync, dann atomar umbenennen.
    """
    tmp = path + ".tmp"
    with open(tmp, "wb") as f:
        f.write(data_bytes)
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError
        return data
    except Exception:
        return json.loads(json.dumps(DEFAULT_CONFIG))


def save_config(cfg):
    atomic_write(CONFIG_FILE, json.dumps(cfg, ensure_ascii=False, indent=2).encode("utf-8"))


# ── NEU Etappe 6: Steuerdatei für den Wartungs-Dienst ────────────────────────
def write_control(action, **extra):
    """
    Schreibt einen Steuerbefehl für den Wartungs-Dienst (wartung.py), der im
    grafischen Login läuft und im Sekundentakt pollt. Jeder Befehl bekommt eine
    fortlaufende 'seq', damit er genau einmal ausgeführt wird.
    """
    prev_seq = 0
    try:
        with open(CONTROL_FILE, "r", encoding="utf-8") as f:
            prev = json.load(f)
            prev_seq = int(prev.get("seq", 0))
    except Exception:
        prev_seq = 0
    payload = {
        "seq": prev_seq + 1,
        "action": action,
        "ts": datetime.now().isoformat(timespec="seconds"),
    }
    payload.update(extra)
    atomic_write(CONTROL_FILE, json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8"))
    return payload


def _copytree_replace(src, dst):
    """Kopiert src -> dst atomar (über Nachbarordner + os.replace)."""
    import shutil
    new_dir = dst + ".new"
    shutil.rmtree(new_dir, ignore_errors=True)
    shutil.copytree(src, new_dir)
    old_dir = dst + ".old"
    shutil.rmtree(old_dir, ignore_errors=True)
    if os.path.isdir(dst):
        os.replace(dst, old_dir)
    os.replace(new_dir, dst)
    shutil.rmtree(old_dir, ignore_errors=True)


def express_rollback():
    """
    EXPRESS-ROLLBACK (Modul 3.2): Stellt sofort die letzte stabile TV-App aus
    backup_previous/ wieder her und beauftragt den Wartungs-Dienst, den Browser
    binnen weniger Sekunden neu zu starten (und den TV nötigenfalls einzuschalten).
    Gibt {ok, restored, error?} zurück.
    """
    if not os.path.isdir(BACKUP_DIR) or not os.listdir(BACKUP_DIR):
        return {"ok": False, "restored": False,
                "error": "Kein Backup vorhanden (backup_previous/ ist leer)."}
    try:
        _copytree_replace(BACKUP_DIR, APP_DIR)
    except Exception as e:
        return {"ok": False, "restored": False,
                "error": "Wiederherstellung fehlgeschlagen: %s" % e}
    # Wartungs-Dienst zum sofortigen Browser-Neustart beauftragen
    write_control("restart_browser", reason="rollback", wake_tv=True)
    sys.stderr.write("[%s] EXPRESS-ROLLBACK: backup_previous -> takvim-app "
                     "wiederhergestellt, Browser-Neustart beauftragt.\n"
                     % datetime.now().strftime("%H:%M:%S"))
    return {"ok": True, "restored": True}


# ── Hilfsfunktionen: Status ──────────────────────────────────────────────────
def prayer_status():
    """Prüft die lokale Gebetszeiten-CSV und liefert Statusinformationen."""
    if not os.path.isfile(CSV_FILE):
        return {"csv_present": False, "rows": 0, "today_ok": False}
    try:
        today = datetime.now().strftime("%d.%m.%Y")
        rows = 0
        today_ok = False
        with open(CSV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rows += 1
                parts = line.split(",")
                if parts and parts[0].strip().strip('"') == today:
                    today_ok = True
        return {"csv_present": True, "rows": rows, "today_ok": today_ok}
    except Exception:
        return {"csv_present": True, "rows": 0, "today_ok": False, "error": "Lesefehler"}


def mediathek_count():
    try:
        return sum(
            1 for f in os.listdir(MEDIA_DIR)
            if os.path.splitext(f.lower())[1] in MEDIA_EXTS
        )
    except Exception:
        return 0


# ── NEU Etappe 6: Backup-/Update-Status ──────────────────────────────────────
def backup_present():
    try:
        return os.path.isdir(BACKUP_DIR) and bool(os.listdir(BACKUP_DIR))
    except Exception:
        return False


def update_pending():
    """True, wenn in /updates/ ein noch nicht eingespieltes Paket liegt."""
    try:
        return any(not f.startswith(".") for f in os.listdir(UPDATES_DIR))
    except Exception:
        return False


def safe_update_name(name):
    """Sicherer Dateiname für ein Update-ZIP (kein Pfad-Ausbruch)."""
    if not name:
        return None
    name = os.path.basename(name.replace("\\", "/")).strip()
    if not name or name in (".", ".."):
        return None
    base, ext = os.path.splitext(name)
    if ext.lower() not in UPDATE_EXTS:
        return None
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._") or "update"
    return base[:80] + ext.lower()


# ── NEU Etappe 4: Mediathek-Helfer ───────────────────────────────────────────
def safe_media_name(name):
    """
    Macht aus einem beliebigen Dateinamen einen sicheren Mediathek-Namen:
    nur Basisname, erlaubte Zeichen, gültige Bild-Endung. Verhindert
    Pfad-Ausbruch (kein '/', '\\', '..'). Gibt None zurück, wenn unzulässig.
    """
    if not name:
        return None
    name = os.path.basename(name.replace("\\", "/")).strip()
    if not name or name in (".", ".."):
        return None
    base, ext = os.path.splitext(name)
    ext = ext.lower()
    if ext not in MEDIA_EXTS:
        return None
    base = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._") or "bild"
    return (base[:80] + ext)


def unique_media_path(name):
    """Sorgt für einen kollisionsfreien Zielpfad (hängt _1, _2 … an)."""
    base, ext = os.path.splitext(name)
    candidate = name
    i = 1
    while os.path.exists(os.path.join(MEDIA_DIR, candidate)):
        candidate = "%s_%d%s" % (base, i, ext)
        i += 1
    return candidate


def image_size(path):
    """
    Liest Breite/Höhe eines Bildes nur aus dem Datei-Header (reine stdlib,
    kein Pillow nötig). Unterstützt PNG, JPEG, GIF und WebP.
    Gibt (w, h) oder (None, None) zurück.
    """
    try:
        with open(path, "rb") as f:
            head = f.read(32)
            # PNG: 8-Byte-Signatur, dann IHDR mit width/height als 32-Bit
            if head[:8] == b"\x89PNG\r\n\x1a\n":
                w, h = struct.unpack(">II", head[16:24])
                return int(w), int(h)
            # GIF: 'GIF87a'/'GIF89a', dann width/height als 16-Bit little-endian
            if head[:6] in (b"GIF87a", b"GIF89a"):
                w, h = struct.unpack("<HH", head[6:10])
                return int(w), int(h)
            # WebP: 'RIFF'....'WEBP'
            if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
                fmt = head[12:16]
                if fmt == b"VP8 ":
                    f.seek(26)
                    b = f.read(4)
                    w = (b[0] | (b[1] << 8)) & 0x3fff
                    h = (b[2] | (b[3] << 8)) & 0x3fff
                    return int(w), int(h)
                if fmt == b"VP8L":
                    f.seek(21)
                    b = f.read(4)
                    bits = b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24)
                    w = (bits & 0x3fff) + 1
                    h = ((bits >> 14) & 0x3fff) + 1
                    return int(w), int(h)
                if fmt == b"VP8X":
                    f.seek(24)
                    b = f.read(6)
                    w = (b[0] | (b[1] << 8) | (b[2] << 16)) + 1
                    h = (b[3] | (b[4] << 8) | (b[5] << 16)) + 1
                    return int(w), int(h)
            # JPEG: SOFn-Marker suchen
            if head[:2] == b"\xff\xd8":
                f.seek(2)
                while True:
                    byte = f.read(1)
                    if not byte:
                        break
                    if byte != b"\xff":
                        continue
                    marker = f.read(1)
                    while marker == b"\xff":
                        marker = f.read(1)
                    if not marker:
                        break
                    m = marker[0]
                    # SOF0..SOF15 außer DHT(c4)/DNL(c8)/DAC(cc)
                    if 0xc0 <= m <= 0xcf and m not in (0xc4, 0xc8, 0xcc):
                        f.read(3)  # length(2) + precision(1)
                        hh = struct.unpack(">H", f.read(2))[0]
                        ww = struct.unpack(">H", f.read(2))[0]
                        return int(ww), int(hh)
                    seg = f.read(2)
                    if len(seg) < 2:
                        break
                    length = struct.unpack(">H", seg)[0]
                    f.seek(length - 2, 1)
    except Exception:
        pass
    return None, None


def list_media():
    """Liefert die Mediathek-Bilder mit Name, Größe (Bytes) und Maßen."""
    items = []
    try:
        for fn in sorted(os.listdir(MEDIA_DIR)):
            if os.path.splitext(fn.lower())[1] not in MEDIA_EXTS:
                continue
            full = os.path.join(MEDIA_DIR, fn)
            if not os.path.isfile(full):
                continue
            w, h = image_size(full)
            items.append({
                "name": fn,
                "size": os.path.getsize(full),
                "w": w, "h": h
            })
    except Exception:
        pass
    return items


def local_ips():
    ips = []
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.append(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    try:
        host_ip = socket.gethostbyname(socket.gethostname())
        if host_ip not in ips and not host_ip.startswith("127."):
            ips.append(host_ip)
    except Exception:
        pass
    return ips or ["<IP nicht ermittelbar>"]


# ── NEU Etappe 2: CSV-Analyse ────────────────────────────────────────────────
def analyse_csv(raw_text):
    """
    Prüft und analysiert eine empfangene Gebetszeiten-CSV.
    Erwartet: c0=Datum dd.mm.yyyy, c1=Hijri, c3=Fajr, c4=Sabah,
              c5=Sonnenaufgang, c6=Dhuhr, c8=Asr, c10=Maghrib,
              c12=Isha, c13=Isha-Adhan
    Gibt zurück: {"ok": bool, "rows": int, "first": str, "last": str,
                  "error": str|None}
    """
    lines = [l.strip() for l in raw_text.splitlines() if l.strip()]
    data_rows = []
    for line in lines:
        parts = line.split(",")
        if not parts:
            continue
        first_cell = parts[0].strip().strip('"')
        # Datumszeilen haben Format dd.mm.yyyy
        if len(first_cell) == 10 and first_cell[2] == "." and first_cell[5] == ".":
            try:
                datetime.strptime(first_cell, "%d.%m.%Y")
                data_rows.append(first_cell)
            except ValueError:
                continue
    if not data_rows:
        return {"ok": False, "rows": 0, "first": None, "last": None,
                "error": "Keine gültigen Datumszeilen gefunden. "
                         "Spalte A muss das Format dd.mm.yyyy haben."}
    return {
        "ok": True,
        "rows": len(data_rows),
        "first": data_rows[0],
        "last": data_rows[-1],
        "error": None
    }


# ── Platzhalter-TV-Seite ─────────────────────────────────────────────────────
PLACEHOLDER_HTML = """<!DOCTYPE html>
<html lang="de"><head><meta charset="UTF-8">
<title>Takvim-App</title>
<style>
html,body{margin:0;height:100%;background:#0a0f1e;color:#e8e4d9;
font-family:'Segoe UI',system-ui,sans-serif;overflow:hidden}
body{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:14px}
.logo{opacity:.9}
.clock{font-size:11vw;font-weight:300;letter-spacing:-2px;color:#f0ece0;
line-height:1;font-variant-numeric:tabular-nums}
.date{font-size:2.4vw;color:#9aa5c4}
.note{margin-top:3vh;font-size:1.5vw;color:#6b7a99;border:1px solid rgba(197,165,90,.3);
border-radius:10px;padding:.6em 1.4em;background:rgba(197,165,90,.06)}
.note b{color:#c5a55a;font-weight:600}
.stat{position:fixed;bottom:14px;right:18px;font-size:12px;color:#3fa45c}
</style></head><body>
<svg class="logo" viewBox="0 0 64 64" width="90" height="90" fill="none"
 stroke="#c5a55a" stroke-width="2" stroke-linecap="round">
 <line x1="6" y1="52" x2="58" y2="52"/>
 <path d="M18 52 V40 Q18 26 32 19 Q46 26 46 40 V52" fill="rgba(197,165,90,.10)"/>
 <path d="M27 52 V46 Q27 41 32 41 Q37 41 37 46 V52"/>
 <line x1="32" y1="19" x2="32" y2="14"/>
 <path d="M35 6 A5 5 0 1 0 35 16 A4 4 0 1 1 35 6 Z" fill="rgba(197,165,90,.10)"/>
 <line x1="11" y1="52" x2="11" y2="32"/><path d="M8 32 Q11 26 14 32"/>
 <line x1="53" y1="52" x2="53" y2="32"/><path d="M50 32 Q53 26 56 32"/>
</svg>
<div class="clock" id="c">--:--</div>
<div class="date" id="d"></div>
<div class="note"><b>Takvim-App bereit</b> &nbsp;·&nbsp; wartet auf den Takvim-Manager
&nbsp;·&nbsp; Vollanzeige folgt in Etappe 3</div>
<div class="stat" id="s">●</div>
<script>
const T=['So','Mo','Di','Mi','Do','Fr','Sa'],
M=['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
function tick(){const n=new Date(),p=x=>String(x).padStart(2,'0');
document.getElementById('c').textContent=p(n.getHours())+':'+p(n.getMinutes());
document.getElementById('d').textContent=T[n.getDay()]+', '+n.getDate()+'. '+M[n.getMonth()]+' '+n.getFullYear();}
tick();setInterval(tick,1000);
async function ping(){try{await fetch('/api/ping',{cache:'no-store'});
document.getElementById('s').style.color='#3fa45c'}catch(e){
document.getElementById('s').style.color='#c0504d'}}
ping();setInterval(ping,30000);
</script></body></html>
"""


# ── HTTP-Handler ─────────────────────────────────────────────────────────────
class TakvimHandler(SimpleHTTPRequestHandler):
    server_version = "MoscheeTakvim/" + VERSION

    def end_headers(self):
        p = urlparse(self.path).path
        if p.startswith("/api/"):
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Cache-Control", "no-store")
        elif p.startswith("/mediathek/"):
            # CORS, damit die Kontrast-Analyse das Bild auf eine Canvas lesen
            # darf (sonst wird die Canvas „tainted" und Pixel sind nicht lesbar)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Cache-Control", "no-cache")
        elif p == "/" or p.endswith((".html", ".css", ".js")):
            self.send_header("Cache-Control", "no-cache")
        super().end_headers()

    def _json(self, obj, code=200):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_OPTIONS(self):
        self.send_response(204)
        self.end_headers()

    def do_GET(self):
        p = urlparse(self.path).path

        if p == "/api/ping":
            self._json({
                "ok": True,
                "service": "moschee-takvim",
                "version": VERSION,
                "time": datetime.now().isoformat(timespec="seconds")
            })
            return

        if p == "/api/status":
            cfg = load_config()
            self._json({
                "ok": True,
                "version": VERSION,
                "time": datetime.now().isoformat(timespec="seconds"),
                "uptime_s": int(time.time() - START_TIME),
                "config_updated_at": cfg.get("updated_at"),
                "pool_aktiv": bool(cfg.get("pool", {}).get("aktiv")),
                "prayer": prayer_status(),
                "mediathek_count": mediathek_count(),
                "backup_present": backup_present(),
                "update_pending": update_pending()
            })
            return

        if p == "/api/config":
            self._json({"ok": True, "config": load_config()})
            return

        # ── /api/csv (NEU Etappe 3): gespeicherte CSV an die TV-App liefern ──
        if p == "/api/csv":
            if not os.path.isfile(CSV_FILE):
                self._json({"ok": False, "error": "Keine Gebetszeiten-CSV vorhanden"}, 404)
                return
            try:
                with open(CSV_FILE, "rb") as f:
                    body = f.read()
            except Exception:
                self._json({"ok": False, "error": "CSV-Lesefehler"}, 500)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/csv; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass
            return

        # ── /api/media (NEU Etappe 4): Liste der Mediathek-Bilder ────────────
        if p == "/api/media":
            cfg = load_config()
            self._json({
                "ok": True,
                "files": list_media(),
                "background": cfg.get("background")
            })
            return

        # ── /api/update (NEU Etappe 6): Backup-/Update-Status ────────────────
        if p == "/api/update":
            try:
                pending = sorted(f for f in os.listdir(UPDATES_DIR)
                                 if not f.startswith("."))
            except Exception:
                pending = []
            self._json({
                "ok": True,
                "version": VERSION,
                "backup_present": backup_present(),
                "update_pending": bool(pending),
                "pending_files": pending
            })
            return

        if p == "/":
            # Redirect auf den echten Pfad, damit die RELATIVEN Asset-Pfade
            # (style.css / kiosk-logic.js) der TV-Seite korrekt unter
            # /takvim-app/ aufgelöst werden. Verhindert das „zerschossene
            # Layout", wenn Assets sonst gegen den Wurzelpfad liefen.
            self.send_response(302)
            self.send_header("Location", "/takvim-app/Takvim-App.html")
            self.send_header("Cache-Control", "no-cache")
            self.end_headers()
            return

        return super().do_GET()

    def do_POST(self):
        p = urlparse(self.path).path

        # Body einlesen
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length > 0 else b"{}"
        except Exception:
            self._json({"ok": False, "error": "Lesefehler beim Body"}, 400)
            return

        # ── /api/config ──────────────────────────────────────────────────────
        if p == "/api/config":
            try:
                body = json.loads(raw.decode("utf-8"))
                if not isinstance(body, dict):
                    raise ValueError
            except Exception:
                self._json({"ok": False, "error": "Ungültiger JSON-Body"}, 400)
                return

            cfg = load_config()
            for key, value in body.items():
                if key in ("schema", "updated_at"):
                    continue
                cfg[key] = value
            cfg["updated_at"] = datetime.now().isoformat(timespec="seconds")
            save_config(cfg)
            self._json({"ok": True, "updated_at": cfg["updated_at"]})
            return

        # ── /api/csv  (NEU Etappe 2) ─────────────────────────────────────────
        if p == "/api/csv":
            try:
                csv_text = raw.decode("utf-8")
            except UnicodeDecodeError:
                try:
                    csv_text = raw.decode("latin-1")
                except Exception:
                    self._json({"ok": False, "error": "CSV-Zeichenkodierung nicht lesbar"}, 400)
                    return

            info = analyse_csv(csv_text)
            if not info["ok"]:
                self._json({"ok": False, "error": info["error"]}, 422)
                return

            # Sofort-Persistenz: CSV atomar speichern
            atomic_write(CSV_FILE, csv_text.encode("utf-8"))

            sys.stderr.write("[%s] CSV gespeichert: %d Zeilen, %s – %s\n" % (
                datetime.now().strftime("%H:%M:%S"),
                info["rows"], info["first"], info["last"]
            ))
            self._json({
                "ok": True,
                "rows": info["rows"],
                "first": info["first"],
                "last": info["last"]
            })
            return

        # ── /api/media (NEU Etappe 4): Bild-Upload (Roh-Bytes im Body) ───────
        if p == "/api/media":
            qs = parse_qs(urlparse(self.path).query)
            raw_name = (qs.get("name", [""])[0]) or self.headers.get("X-Media-Name", "")
            name = safe_media_name(raw_name)
            if not name:
                self._json({"ok": False, "error": "Ungültiger oder fehlender Dateiname "
                            "(erlaubt: .jpg .jpeg .png .webp .gif)"}, 400)
                return
            if not raw or len(raw) == 0:
                self._json({"ok": False, "error": "Leerer Datei-Inhalt"}, 400)
                return
            if len(raw) > MEDIA_MAX_BYTES:
                self._json({"ok": False, "error": "Bild ist zu groß (max. %d MB)"
                            % (MEDIA_MAX_BYTES // (1024 * 1024))}, 413)
                return

            target_name = unique_media_path(name)
            target_path = os.path.join(MEDIA_DIR, target_name)
            try:
                atomic_write(target_path, raw)
            except Exception:
                self._json({"ok": False, "error": "Speichern fehlgeschlagen"}, 500)
                return

            w, h = image_size(target_path)
            sys.stderr.write("[%s] Mediathek-Upload: %s (%d Bytes, %sx%s)\n" % (
                datetime.now().strftime("%H:%M:%S"), target_name, len(raw), w, h))
            self._json({"ok": True, "name": target_name, "size": len(raw),
                        "w": w, "h": h})
            return

        # ── /api/update (NEU Etappe 6): TV-App-Update als ZIP ablegen ────────
        if p == "/api/update":
            qs = parse_qs(urlparse(self.path).query)
            raw_name = (qs.get("name", [""])[0]) or self.headers.get("X-Update-Name", "")
            name = safe_update_name(raw_name)
            if not name:
                self._json({"ok": False, "error": "Ungültiger Update-Name "
                            "(erlaubt: .zip)"}, 400)
                return
            if not raw or len(raw) == 0:
                self._json({"ok": False, "error": "Leeres Update-Paket"}, 400)
                return
            if len(raw) > UPDATE_MAX_BYTES:
                self._json({"ok": False, "error": "Update zu groß (max. %d MB)"
                            % (UPDATE_MAX_BYTES // (1024 * 1024))}, 413)
                return
            # ZIP-Signatur grob prüfen ("PK")
            if raw[:2] != b"PK":
                self._json({"ok": False, "error": "Kein gültiges ZIP-Paket"}, 422)
                return
            os.makedirs(UPDATES_DIR, exist_ok=True)
            try:
                atomic_write(os.path.join(UPDATES_DIR, name), raw)
            except Exception:
                self._json({"ok": False, "error": "Speichern fehlgeschlagen"}, 500)
                return
            sys.stderr.write("[%s] TV-Update abgelegt: %s (%d Bytes) — wird im "
                             "nächsten Wartungsfenster eingespielt.\n" % (
                                 datetime.now().strftime("%H:%M:%S"), name, len(raw)))
            self._json({"ok": True, "name": name, "size": len(raw),
                        "note": "Wird im nächsten Wartungsfenster installiert."})
            return

        # ── /api/rollback (NEU Etappe 6): Express-Rollback (Fail-Safe) ───────
        if p == "/api/rollback":
            result = express_rollback()
            self._json(result, 200 if result.get("ok") else 409)
            return

        self._json({"ok": False, "error": "Unbekannter Endpunkt"}, 404)

    def do_DELETE(self):
        p = urlparse(self.path).path
        if p == "/api/media":
            qs = parse_qs(urlparse(self.path).query)
            name = safe_media_name(qs.get("name", [""])[0])
            if not name:
                self._json({"ok": False, "error": "Ungültiger Dateiname"}, 400)
                return
            target = os.path.join(MEDIA_DIR, name)
            deleted = False
            if os.path.isfile(target):
                try:
                    os.remove(target)
                    deleted = True
                except Exception:
                    self._json({"ok": False, "error": "Löschen fehlgeschlagen"}, 500)
                    return
            # Falls das gelöschte Bild der aktive Hintergrund war -> zurücksetzen
            cleared = False
            cfg = load_config()
            if cfg.get("background") == name:
                cfg["background"] = None
                cfg["updated_at"] = datetime.now().isoformat(timespec="seconds")
                save_config(cfg)
                cleared = True
            sys.stderr.write("[%s] Mediathek-Löschung: %s (entfernt=%s, "
                             "Hintergrund zurückgesetzt=%s)\n" % (
                                 datetime.now().strftime("%H:%M:%S"),
                                 name, deleted, cleared))
            self._json({"ok": True, "deleted": deleted, "cleared_background": cleared})
            return

        self._json({"ok": False, "error": "Unbekannter Endpunkt"}, 404)

    def log_message(self, fmt, *args):
        """
        Eigene Zugriffs-Protokollierung. /api/ping (Manager alle 10 s) und
        /api/status (TV-App alle 2 s) werden NICHT geloggt, damit die Konsole
        nicht zugespammt wird. Alles andere kompakt mit Uhrzeit.
        """
        try:
            if "/api/ping" in self.path or "/api/status" in self.path:
                return
        except Exception:
            pass
        sys.stderr.write("[%s] %s\n" % (datetime.now().strftime("%H:%M:%S"),
                                        fmt % args))


# ── Start ────────────────────────────────────────────────────────────────────
def main():
    ensure_dirs()

    if not os.path.isfile(CONFIG_FILE):
        save_config(json.loads(json.dumps(DEFAULT_CONFIG)))

    app_html = os.path.join(APP_DIR, "Takvim-App.html")
    if not os.path.isfile(app_html):
        atomic_write(app_html, PLACEHOLDER_HTML.encode("utf-8"))

    handler = partial(TakvimHandler, directory=BASE)
    server = ThreadingHTTPServer(("", PORT), handler)

    print("=" * 62)
    print("  MOSCHEE-TAKVIM  ·  Pi-Empfänger-Dienst  v%s" % VERSION)
    print("=" * 62)
    print("  Basisordner : %s" % BASE)
    for ip in local_ips():
        print("  TV-Anzeige  : http://%s:%s/" % (ip, PORT))
        print("  API         : http://%s:%s/api/ping" % (ip, PORT))
    print("  Beenden mit STRG+C")
    print("=" * 62)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nDienst beendet.")


if __name__ == "__main__":
    main()
