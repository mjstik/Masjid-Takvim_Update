#!/bin/bash
# ==============================================================================
#  MOSCHEE-TAKVIM — Chromium-Kiosk-Start                            (Etappe 3)
# ------------------------------------------------------------------------------
#  Wird vom Desktop-Autostart aufgerufen. Wartet, bis der lokale Pi-Dienst
#  antwortet, und startet dann Chromium im Vollbild-Kiosk auf die TV-Anzeige.
#  Funktioniert unter Wayland (labwc, Standard auf Pi 5) und unter X11.
# ==============================================================================

URL="http://localhost:8080/"

# 1) Auf den Takvim-Dienst warten (max. ~60 s, danach trotzdem starten —
#    die App verbindet sich selbst nach, sobald der Dienst da ist)
for i in $(seq 1 30); do
  if curl -s --max-time 2 "http://localhost:8080/api/ping" >/dev/null; then
    break
  fi
  sleep 2
done

# 2) Chromium finden (Paketname je nach OS-Version unterschiedlich)
CHROME="$(command -v chromium-browser || command -v chromium)"
if [ -z "$CHROME" ]; then
  echo "Chromium nicht gefunden — bitte installieren: sudo apt install chromium-browser"
  exit 1
fi

# 3) Kiosk starten
#    --kiosk                          Vollbild ohne Bedienelemente
#    --noerrdialogs / -infobars       keine Störmeldungen auf dem TV
#    --disable-session-crashed-bubble keine "Wiederherstellen?"-Leiste
#    --check-for-update-interval      Chromium-Eigenupdates faktisch aus
exec "$CHROME" \
  --kiosk \
  --noerrdialogs \
  --disable-infobars \
  --disable-session-crashed-bubble \
  --disable-features=TranslateUI \
  --check-for-update-interval=31536000 \
  --hide-scrollbars \
  "$URL"
