# Moschee-Takvim — v1.8

Version **1.8.0** · baut direkt auf dem stabilen Stand v1.7.0 auf.

Diese Etappe setzt die drei Anforderungen 5–7 um: **CSS-Layout-Fixes &
WYSIWYG-Synchronisation**, **Entfernung des Block-Modus** und ein
**Preset-System** für Hintergründe und Layouts. Bestehende Daten (Sperrzone
`data/` im Manager, `takvim-data/` + `mediathek/` auf dem Pi) bleiben unberührt;
ältere Konfigurationen funktionieren ohne Eingriff weiter.

---

## 5 · CSS-Layout-Fixes & Editor-WYSIWYG-Synchronisation

### Maßstabsgetreues WYSIWYG (Editor → TV)
Kernursache: Der Editor skalierte Schrift-Pixel für die Vorschau mit
`Bühnenbreite ÷ 1920` (`tvScale`), die TV-Anzeige wendete dieselben px aber
**roh** an. Maßstabstreue galt damit nur, wenn das TV exakt 1920 px breit war.

- Die TV (`kiosk-logic.js`) skaliert jetzt **alle** px-Werte aus dem
  Design-Studio (Schriftgrößen **und** Positions-Offsets `pos_*`) spiegelbildlich
  mit der **tatsächlichen TV-Breite ÷ 1920** (neuer Helfer `tvScale`,
  Konstante `TV_REF_W = 1920` — identisch zum Editor). Ein im Editor gezogenes
  bzw. skaliertes Element landet so an derselben relativen Position und Größe –
  unabhängig von 1280, 1920 oder 4K.
- Ein **Resize-Listener** berechnet das Frei-Layout bei Auflösungswechsel neu.

### Icon-Skalierung (Sonne/Mond)
Kernursache: Das TV-Icon war fix (`svg width=34` + `.icon{transform:scale(2)}`),
das Editor-Icon dagegen responsiv (`clamp(...cqw)`). `iconScale` wurde zwar
übertragen, Basisgröße und Skalierungsmodell unterschieden sich aber.

- TV und Editor nutzen jetzt **dieselbe responsive Icon-Basis**
  `clamp(12px, 9cqi, 64px)` (relativ zur Kachelbreite) und **keinen** festen
  `scale(2)` mehr im Frei-Layout.
- `iconScale` wird in **beiden** immer gesetzt (Default **130**, identisch),
  sodass eine Vergrößerung des Symbols 1:1 auf dem TV ankommt.

### Overflow- & Box-Sizing-Fixes
- **Moschee-Bezeichnung vs. Uhr/Datum:** `.mosque-name` erhält `min-width:0`,
  damit `text-overflow:ellipsis` im Flex-Container greift und der Name nicht
  mehr in die Datums-/Uhr-Spalte hineinläuft.
- **Kacheln & Hadith-Box:** Innenelemente erhalten `min-width:0 / max-width:100%`
  und Wortumbruch; die Container sind `overflow:hidden`. Das Vergrößern von
  arabischem Text, Übersetzung oder Gebetszeiten schiebt nichts mehr aus der
  Kachel/über den Bildschirmrand — überschüssiger Inhalt wird sauber beschnitten.

## 6 · Vereinfachung des Hintergrund-Modus (Entfernung Block-Mode)

- Der **Block-Modus** wurde vollständig entfernt: UI-Umschalter (Block/Einzeln),
  Block-Logik im Manager (`DS_LAYOUT`, `setLayoutMode`, `applyBlockLayoutTo`,
  Block-Drag/-Skalierung in `initStageEditing`, `commitLayout`,
  `commitOverrideDisable`) sowie der Block-Transform auf der TV (`applyLayout`).
- Der bisherige **Einzeln-Modus ist jetzt das absolute Standard-Verhalten** und
  wird im UI nicht mehr benannt oder als Option angeboten. Beim Öffnen des
  Studios sind die Kacheln sofort frei platzierbar (Default-Boxen, falls noch
  nichts gespeichert wurde).
- Die Buttons **Entsperrt/Gesperrt** (🔒/🔓) und **Reset** (⟲) bleiben
  funktionsfähig; Reset setzt die Einzel-Anordnung auf die Standard-Boxen zurück.
- Ein evtl. in Bestands-Configs vorhandenes `layout`-Feld wird gefahrlos
  ignoriert. Die Backend-Methode `set_layout` bleibt als veraltete, nicht mehr
  aufgerufene Kompatibilitäts-Schnittstelle erhalten.

## 7 · Preset-System für Hintergründe und Layouts

- Neuer **Preset-Manager** im Reiter „🖼️ Hintergründe": aktuellen Stand
  (Kachel-Anordnung & -Stile, Hintergrund, Helligkeits-Regler) als **benanntes
  Preset speichern**.
- Gespeicherte Presets sind über ein **Dropdown** wählbar und werden per Klick
  auf **„▶ Anwenden"** direkt auf die TV-Anzeige geladen; Löschen per 🗑.
- **Speicherung:** `data/presets.json` in der Manager-Sperrzone (atomar,
  update-sicher). Gleicher Name = Überschreiben.
- **Anwenden:** überträgt Hintergrund, Design und Einzel-Anordnung in **einem
  einzigen gemergten `/api/config`-POST** an den Pi; danach werden Vorschauen
  und Regler aus dem dann gültigen Pi-Stand aktualisiert.
- Werte werden serverseitig validiert/geklemmt (Design 0–40/0–100/0–100;
  Box-Prozente 3–100 bzw. 0–100; nur erlaubte Stil-Schlüssel + `pos_*`).

---

## Zusätzlich (Backend/API/Stabilität)

- **API:** Vier neue Manager-Methoden `list_presets`, `save_preset`,
  `apply_preset`, `delete_preset`. Der Pi benötigt **keine** Änderung — das
  bestehende `POST /api/config` (Top-Level-Merge) reicht aus.
- **Redundanzen entfernt:** Block-Umschalter (HTML/CSS/JS), tote Funktion
  `clearOverrideOn`, doppelte Clamp-Logik. `set_design`/`set_override_layout`
  und der Preset-Manager teilen sich jetzt die zentralen Helfer
  `_clean_design_obj` / `_clean_override_obj`.
- **Version** überall auf **1.8.0** angehoben (Manager, Pi-Server, Wartung,
  Splash-/Footer-/System-Anzeige, `config.json`).

---

## Geänderte / neue Dateien

| Datei | Status | Inhalt der Änderung |
|-------|--------|---------------------|
| `raspberry-pi/takvim-app/kiosk-logic.js` | geändert | `tvScale`/`TV_REF_W`; px maßstabsgetreu skaliert (Schrift + `pos_*`); `iconScale`-Default 130 immer gebunden; Block-Transform aus `applyLayout` entfernt; Resize-Listener |
| `raspberry-pi/takvim-app/style.css` | geändert | `.mosque-name{min-width:0}`; Overflow-Absicherung Kacheln/Hadith-Box; responsive Icon-Basis im Frei-Layout (`clamp(12px,9cqi,64px)`, kein `scale(2)`) |
| `Moschee-Takvim-Manager/app/main.js` | geändert | Block-Modus entfernt (`DS_MODE` konstant „free"); `initStageEditing` nur Einzeln; `iconScale`-Default in Editor-Vorschau; **Preset-Manager** (init/list/save/apply/delete); tote Helfer entfernt |
| `Moschee-Takvim-Manager/app/index.html` | geändert | Block/Einzeln-Umschalter entfernt; **Preset-Karte** ergänzt; Versions-Platzhalter 1.8.0 |
| `Moschee-Takvim-Manager/app/style.css` | geändert | Umschalter-CSS entfernt; Editor-Icon an TV angeglichen; **Preset-Karten-Stile** |
| `Moschee-Takvim-Manager/Takvim-Manager.py` | geändert | `PRESETS_FILE` + `DEFAULT_PRESETS`; `_now_iso`, `_clean_design_obj`, `_clean_override_obj`; 4 Preset-Methoden; `set_design`/`set_override_layout` auf Helfer umgestellt; `set_layout` als veraltet markiert; Version 1.8.0 |
| `raspberry-pi/pi_server.py` | geändert | Version 1.8.0 |
| `raspberry-pi/wartung.py` | geändert | Version 1.8.0 |
| `Moschee-Takvim-Manager/data/config.json` | geändert | Version 1.8.0 |
| `AENDERUNGEN-v1.8.md` | **neu** | Dieses Dokument |

## Getestet

- **Preset-Backend (Einheit):** Speichern inkl. Clamping (Design 0–40/0–100,
  Box-Prozente), Stil-Whitelist (Fremd-Schlüssel verworfen, `pos_*` & `iconScale`
  erhalten), Überschreiben bei gleichem Namen (id stabil), `enabled:false →
  override null`, Löschen/Doppellöschen, Fehlerpfade (leerer Name, unbekannte id).
- **Preset-Anwenden:** „kein Pi konfiguriert" → klare Fehlermeldung; mit Pi →
  **genau ein** gemergter `/api/config`-POST mit `{background, design,
  override_layout}`.
- **WYSIWYG-Konstanten:** `TV_REF_W` (1920), Icon-Basis-`clamp` und
  `iconScale`-Default (130) in Editor **und** TV nachweislich identisch.
- **Struktur:** DOM-ID-Abgleich main.js ↔ index.html (keine fehlenden IDs),
  keine toten Referenzen (`DS_LAYOUT`, `setLayoutMode`, `commitLayout`,
  `applyBlockLayoutTo`, `commitOverrideDisable`), Block-Elemente vollständig
  entfernt.
- **Syntax:** `node --check` (main.js, kiosk-logic.js), `ast.parse`
  (Takvim-Manager.py, pi_server.py, wartung.py), JSON-Validierung (config.json)
  — fehlerfrei.
