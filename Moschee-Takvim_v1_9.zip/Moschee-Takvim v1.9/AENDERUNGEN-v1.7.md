# Moschee-Takvim — v1.7

Version **1.7.0** · baut direkt auf dem stabilen Stand v1.6.0 (Etappe 6) auf.

Diese Etappe setzt die vier Anforderungen aus dem v1.7-Auftrag um. Alle
funktionalen Änderungen betreffen das **Kiosk-Frontend (TV-Anzeige)**; im
**Manager** und auf dem **Pi-Server** wurden nur die dadurch entstandenen
Entwicklungsreste bereinigt bzw. die Fokus-Defaults angepasst. Bestehende
Daten (Sperrzone `data/`, `takvim-data/`, `mediathek/`) bleiben unberührt.

---

## 1 · InfoTexte — Kategorie nur noch im Manager

- Die **Kategorie** (z. B. „Hadithe") wird auf der TV **nicht mehr angezeigt**.
  Das frühere Badge-Element `#hKat` wurde aus dem TV-HTML entfernt; die
  Render-Logik setzt es nicht mehr. Die **Quellenangabe** (`#hQuelle`, z. B.
  „Sahih al-Buchari, Nr. 614") bleibt erhalten.
- Im **Manager unverändert**: Kategorie-Badges, der Kategorie-**Filter**
  (`#libFilter`, „Alle Kategorien / Hadithe / …") und die Bibliotheks-Liste
  funktionieren wie bisher.

## 2 · Next Prayer — Countdown in die Gebetskachel integriert

- Die separate **„Nächstes Gebet"-Leiste** wurde vollständig entfernt
  (TV-HTML, zugehörige Styles und Layout-Verknüpfungen).
- Der **Countdown** wird jetzt **direkt in der Kachel des nächsten Gebets**
  angezeigt (die Kachel ist als `.active` markiert):
  - Format **HH:MM:SS**, sekundengenau (eigene Funktion `updateTileCountdown`,
    Aufruf im Sekundentakt aus `tick()`).
  - **Keine zusätzliche Beschriftung**.
  - Optisch **dezent/eingraviert**: gedämpftes Gold, ~**35 % kleiner** als die
    Gebetszeit (4.4vw → 2.85vw) und direkt darunter platziert.
  - Die **Gebetszeit bleibt das dominante** Element der Kachel; es entsteht
    keine zusätzliche Zeile mit eigener Hervorhebung.
- Aufräumen im **Design-Studio des Managers**: das nun gegenstandslose Element
  `nextbar` (`.ds-nextbar`) wurde aus Standard-Layout, Bühnen-Markup,
  Stil-Logik und CSS entfernt. Vorhandene gespeicherte Layouts mit einer
  `nextbar`-Box werden vom TV-Code gefahrlos ignoriert.

## 3 · Gebetszeit-Ablaufsteuerung (Adhan- & Ikamah-State-Machine)

Die Fokus-Logik wurde als **State-Machine ab dem Eintreffen der Gebetszeit**
neu aufgebaut (`focusState`/`applyFocus`). Die frühere **Vor-Gebet-Übernahme**
(Vollbild-Countdown 10 Min davor) entfällt — sie stand im direkten Widerspruch
zur Vorgabe „Phase 1 erscheint **exakt mit Eintreffen** der Gebetszeit". Die
Annäherungs-Information übernimmt jetzt der Kachel-Countdown aus Punkt 2.

Ablauf je Gebet ab Adhan-Zeitpunkt `t`:

- **Phase 1 — Adhan-Signal** (`t … t + ~6 s`): eine einzelne, fokussierte,
  pulsierende Kachel signalisiert, dass der Adhan gerufen wird. Dauer
  konfigurierbar über `fokus.adhan_signal_sec` (Standard 6 s, begrenzt auf
  5–8 s).
- **Phase 2 — Ikamah-Countdown + Du'a** (`t + 6 s … (t + 10 min) − 2 min`):
  fließender Übergang zum **10-minütigen Ikamah-Countdown**; parallel werden
  die **Du'a-Balken nach dem Adhan** ein-/oben-/untergeblendet.
- **Phase 3 — Fokus-Wechsel** (letzte **2 Minuten**, Restzeit ≤ 02:00): die
  **Du'a wird automatisch ausgeblendet**; der Fokus liegt **ausschließlich**
  auf der Ikamah-Restzeit (Restzeit zusätzlich vergrößert).

Sonderfälle:

- **A) Maghrib:** **kein** Ikamah-Countdown. Nur das Adhan-Signal (Phase 1),
  danach zurück zur Normalanzeige; folglich auch keine Du'a-Balken.
- **B) Fajr, Dhuhr, Asr, Isha:** 10-minütiger Ikamah-Countdown, der **sofort
  und ohne Verzögerung** mit dem Eintreffen der Gebetszeit beginnt.
- **Optionales Abdunkeln** nach Ablauf der Ikamah bleibt erhalten
  (`fokus.abdunkeln_min`, Standard 0 = aus).

Für den **fließenden** Phasenübergang wurden CSS-Transitions auf der
Fokus-Kachel ergänzt (Größe/Schrift morphen statt zu springen).

## 4 · Datum-Hierarchie (oben rechts)

- Das **Gregorianische Datum** steht jetzt an **1. Stelle** (oben) und ist
  **dominant** (größer, kräftiger, heller).
- Das **Hijri-Datum** rückt an die **2. Stelle** (darunter) und ist visuell
  **zurückgenommen** (kleiner, gedämpftes Gold).

---

## Zusätzlich (Backend/API/Stabilität)

- **API/Backend nicht erforderlich:** Die Inhalte (inkl. Kategorie) fließen
  unverändert über `/api/config`; nur die TV-**Darstellung** der Kategorie
  entfällt. Es war keine Änderung an den Schnittstellen nötig.
- **Pi-Fokus-Defaults** (`pi_server.py`) an die neue State-Machine angepasst:
  `adhan_signal_sec` (neu) statt der obsoleten `athan_countdown_min` /
  `athan_anzeige_min`; `iqama_countdown_min` und `abdunkeln_min` unverändert.
  Der TV-Code liest neue **und** alte Konfigurationen robust (Default-Werte),
  Bestandsinstallationen funktionieren ohne Eingriff weiter.
- **Entwicklungsreste entfernt:** toter Kategorie-Badge-Stil, die komplette
  Next-Bar (HTML/CSS/JS/Design-Studio), verwaiste `nextbar`/`.cdwn`/
  `.next-name`-Referenzen sowie der nicht mehr im TV-HTML vorhandene
  `fokus`-Block der Manager-`config.json` (an v1.7 angeglichen).
- **Stabilität:** `updateDataStatus()` greift nicht mehr ungesichert auf das in
  Etappe 5 entfernte `#dataStatus`-Element zu (vermied einen möglichen Abbruch
  in `fetchCSV()`/`init()`).
- **Version** überall auf **1.7.0** angehoben (Manager, Pi-Server, Wartung,
  Splash-/Footer-/System-Anzeige).

---

## Geänderte / neue Dateien

| Datei | Status | Inhalt der Änderung |
|-------|--------|---------------------|
| `raspberry-pi/takvim-app/Takvim-App.html` | geändert | Datum-Reihenfolge getauscht; Next-Bar & `#hKat` entfernt; Kommentare/Version |
| `raspberry-pi/takvim-app/kiosk-logic.js` | geändert | Neue Adhan/Ikamah-State-Machine; Tile-Countdown (HH:MM:SS); Kategorie-Render & Next-Bar-Refs entfernt; `dataStatus` abgesichert |
| `raspberry-pi/takvim-app/style.css` | geändert | Datum-Hierarchie; `.tile-countdown`; Phasen-Stile (Pulse Phase 1, Fokus Phase 3, Transitions); Next-Bar-/Kategorie-Stile entfernt |
| `raspberry-pi/pi_server.py` | geändert | Fokus-Defaults (`adhan_signal_sec`); Version 1.7.0 |
| `raspberry-pi/wartung.py` | geändert | Version 1.7.0 |
| `Moschee-Takvim-Manager/app/main.js` | geändert | Design-Studio: `nextbar`/`ds-nextbar` entfernt |
| `Moschee-Takvim-Manager/app/style.css` | geändert | `.ds-nextbar`-Stile entfernt |
| `Moschee-Takvim-Manager/app/index.html` | geändert | Versions-Platzhalter 1.7.0 |
| `Moschee-Takvim-Manager/Takvim-Manager.py` | geändert | Version 1.7.0 |
| `Moschee-Takvim-Manager/data/config.json` | geändert | `fokus`-Block an v1.7 angeglichen; Version 1.7.0 |
| `AENDERUNGEN-v1.7.md` | **neu** | Dieses Dokument |

## Getestet

- **Logik (Unit):** Adhan/Ikamah-State-Machine über alle Phasengrenzen
  (Phase 1 = 0–6 s, Phase 2 bis Restzeit 02:00, Phase 3 = letzte 2 Min,
  sauberes Ende nach 10 Min), Maghrib ohne Ikamah, HH:MM:SS-Formatierung —
  15/15 bestanden.
- **Syntax:** `node --check` (kiosk-logic.js, main.js), `ast.parse`
  (pi_server.py, Takvim-Manager.py, wartung.py), JSON-Validierung
  (config.json) — fehlerfrei.
- **Struktur:** Abgleich aller vom JS referenzierten DOM-IDs gegen das
  TV-HTML; div-Tag-Balance; keine verwaisten Referenzen auf entfernte
  Elemente.
