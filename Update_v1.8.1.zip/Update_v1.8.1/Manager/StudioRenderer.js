/* ============================================================================
   StudioRenderer.js  ·  Moschee-Takvim Design-Studio                    v1.11
   ----------------------------------------------------------------------------
   KOMPLETT-REWRITE des Studio-Editors (siehe STUDIO-EDITOR-REWRITE-PITCH-FINAL.md).

   ROOT CAUSE (alt): Studio baute seine Vorschau mit Container-Query-Einheiten
   (cqw) GEGEN DIE BREITE DER STUDIO-BÜHNE auf, während das Dashboard die echte
   TV-App (1920×1080) per <iframe> + transform:scale() zeigte. Beides driftete
   auseinander, sobald Default-Werte (ohne expliziten Style-Override) griffen.

   LÖSUNG (neu): StudioRenderer baut die Bühne IMMER auf einem festen
   1920×1080-Layoutraum auf (= TV_REF_W/TV_REF_H, exakt wie kiosk-logic.js
   tvScale()) und skaliert NUR diesen Raum per CSS transform:scale() auf die
   tatsächliche Containergröße. Dashboard (iframe der echten TV-Seite) und
   Studio (dieser Renderer) teilen sich damit dieselbe Referenzgröße — beide
   sind danach reine Geometrie-Probleme (Containerbreite / 1920), keine
   unterschiedliche CSS-Einheiten-Mathematik mehr (Anforderung 1).

   v1.10 (Hadith-Box Rückbau): Die Infotext-Box ist wieder EINE zusammenhängende
   Kachel (Override-Ziel "info"), die als Ganzes gezogen/skaliert wird. Die vier
   Inhalte (Titel/Arabisch/Übersetzung/Quelle) liegen darin in fester Reihenfolge
   untereinander; individuelles Styling erfolgt per Akkordeon-Overlay (Doppelklick).

   WICHTIG zu den Style-Feldnamen: Die Pitch-Pseudocode-Beispiele verwenden
   generische Keys (style.fontSize, style.color). Die echte TV-App und das
   Python-Backend (_OVERRIDE_STYLE_KEYS in Takvim-Manager.py) verwenden aber
   FESTE, BENANNTE Felder (timeFontSize, nameFontSize, arFontSize,
   srcFontSize, titleFontSize, timeColor, ... ); ein generisches "fontSize"
   würde vom Backend stillschweigend verworfen UND von der TV-Seite nicht
   verstanden. Dieser Renderer übernimmt daher das bewährte benannte Schema
   1:1 (siehe PART_STYLE_FIELDS unten) — das ist keine Abweichung vom Pitch-
   ZIEL (entkoppelte, einzeln stylebare Elemente), sondern eine Anpassung der
   Pseudocode-Feldnamen an das tatsächlich funktionierende Backend/TV-Schema.
   ============================================================================ */
"use strict";

/* ════════════════════════════════════════════════════════════════════════════
   0) KONSTANTEN
   ════════════════════════════════════════════════════════════════════════════ */

/* TV-Referenzauflösung — identisch zu kiosk-logic.js TV_REF_W und der
   bisherigen tvScale()-Logik in main.js. ALLE px-Werte (Schriftgrößen,
   Boxen werden in % gespeichert, aber Schriftgrößen in px) beziehen sich
   auf diese Breite. */
const SR_TV_REF_W = 1920;
const SR_TV_REF_H = 1080;

/* TV-Icons (1:1 aus kiosk-logic.js / main.js TV_ICONS) */
const SR_G = '#c5a55a';
const SR_S = b => `<svg viewBox="0 0 32 32" width="34" height="34">${b}</svg>`;
const SR_L  = `stroke="${SR_G}" stroke-width="1.5" stroke-linecap="round"`;
const SR_LT = `stroke="${SR_G}" stroke-width="1.2" stroke-linecap="round"`;
const SR_ICONS = {
  fajr:SR_S(`<line x1="3" y1="25" x2="29" y2="25" ${SR_L}/><path d="M 8 25 A 8 8 0 0 0 24 25" fill="rgba(197,165,90,.2)" stroke="${SR_G}" stroke-width="1.5"/><line x1="16" y1="13" x2="16" y2="10" ${SR_L}/><line x1="21" y1="15.5" x2="23" y2="13" ${SR_L}/><line x1="11" y1="15.5" x2="9" y2="13" ${SR_L}/><line x1="24.5" y1="20" x2="27" y2="19" ${SR_L}/><line x1="7.5" y1="20" x2="5" y2="19" ${SR_L}/><polyline points="13,8 16,5 19,8" fill="none" stroke="${SR_G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  dhuhr:SR_S(`<circle cx="16" cy="16" r="6" fill="rgba(197,165,90,.2)" stroke="${SR_G}" stroke-width="1.5"/><line x1="16" y1="7" x2="16" y2="4" ${SR_L}/><line x1="16" y1="25" x2="16" y2="28" ${SR_L}/><line x1="7" y1="16" x2="4" y2="16" ${SR_L}/><line x1="25" y1="16" x2="28" y2="16" ${SR_L}/><line x1="10" y1="10" x2="8" y2="8" ${SR_L}/><line x1="22" y1="22" x2="24" y2="24" ${SR_L}/><line x1="22" y1="10" x2="24" y2="8" ${SR_L}/><line x1="10" y1="22" x2="8" y2="24" ${SR_L}/>`),
  asr:SR_S(`<circle cx="16" cy="17" r="6" fill="rgba(197,165,90,.18)" stroke="${SR_G}" stroke-width="1.5"/><line x1="16" y1="8" x2="16" y2="5" ${SR_LT} opacity=".35"/><line x1="16" y1="26" x2="16" y2="29" ${SR_L}/><line x1="7" y1="17" x2="4" y2="17" ${SR_LT} opacity=".35"/><line x1="25" y1="17" x2="28" y2="17" ${SR_L}/><line x1="10.5" y1="11.5" x2="8.5" y2="9.5" ${SR_LT} opacity=".35"/><line x1="21.5" y1="22.5" x2="23.5" y2="24.5" ${SR_L}/><line x1="21.5" y1="11.5" x2="23.5" y2="9.5" ${SR_L}/><line x1="10.5" y1="22.5" x2="8.5" y2="24.5" ${SR_L}/>`),
  maghrib:SR_S(`<line x1="3" y1="23" x2="29" y2="23" ${SR_L}/><path d="M 8 23 A 8 8 0 0 0 24 23" fill="rgba(197,165,90,.2)" stroke="${SR_G}" stroke-width="1.5"/><line x1="16" y1="11" x2="16" y2="8" ${SR_L}/><line x1="21" y1="13.5" x2="23" y2="11" ${SR_L}/><line x1="11" y1="13.5" x2="9" y2="11" ${SR_L}/><line x1="24.5" y1="18" x2="27" y2="17" ${SR_L}/><line x1="7.5" y1="18" x2="5" y2="17" ${SR_L}/><polyline points="13,27 16,30 19,27" fill="none" stroke="${SR_G}" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/>`),
  isha:SR_S(`<path d="M 20 7 A 10 10 0 1 0 20 25 A 6.5 6.5 0 1 1 20 7 Z" fill="rgba(197,165,90,.2)" stroke="${SR_G}" stroke-width="1.5" stroke-linejoin="round"/><circle cx="22" cy="10" r="1" fill="${SR_G}" opacity=".6"/><circle cx="24" cy="14" r=".8" fill="${SR_G}" opacity=".4"/>`)
};

/* Gebetsnamen/Datum — 1:1 aus kiosk-logic.js LANG (TV-Anzeigesprache). */
const SR_LANG = {
  de: { prayers: ['Morgengebet','Mittagsgebet','Nachmittagsgebet','Abendgebet','Nachtgebet'],
        ar: ['\u0627\u0644\u0641\u062c\u0631','\u0627\u0644\u0638\u0647\u0631','\u0627\u0644\u0639\u0635\u0631','\u0627\u0644\u0645\u063a\u0631\u0628','\u0627\u0644\u0639\u0634\u0627\u0621'],
        beginn: 'Beginn', aufgang: 'Aufgang',
        days: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
        months: ['Januar','Februar','M\u00e4rz','April','Mai','Juni','Juli','August',
                 'September','Oktober','November','Dezember'] },
  al: { prayers: ['Sabahu','Dreka','Ikindia','Akshami','Jacia'],
        ar: ['\u0627\u0644\u0641\u062c\u0631','\u0627\u0644\u0638\u0647\u0631','\u0627\u0644\u0639\u0635\u0631','\u0627\u0644\u0645\u063a\u0631\u0628','\u0627\u0644\u0639\u0634\u0627\u0621'],
        beginn: 'Imsaku', aufgang: 'Lindja',
        days: ['Die','H\u00ebn','Mar','M\u00ebr','Enj','Pre','Sht'],
        months: ['Jan','Shk','Mar','Pri','Maj','Qer','Kor','Gus','Sht','Tet','N\u00ebn','Dhj'] },
  ar: { prayers: ['Fadschr','Dhuhr','Asr','Maghrib','Ischa'],
        ar: ['\u0627\u0644\u0641\u062c\u0631','\u0627\u0644\u0638\u0647\u0631','\u0627\u0644\u0639\u0635\u0631','\u0627\u0644\u0645\u063a\u0631\u0628','\u0627\u0644\u0639\u0634\u0627\u0621'],
        beginn: 'Beginn', aufgang: 'Aufgang',
        days: ['So','Mo','Di','Mi','Do','Fr','Sa'],
        months: ['Jan','Feb','M\u00e4r','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'] },
  en: { prayers: ['Fajr','Dhuhr','Asr','Maghrib','Isha'],
        ar: ['\u0627\u0644\u0641\u062c\u0631','\u0627\u0644\u0638\u0647\u0631','\u0627\u0644\u0639\u0635\u0631','\u0627\u0644\u0645\u063a\u0631\u0628','\u0627\u0644\u0639\u0634\u0627\u0621'],
        beginn: 'Imsak', aufgang: 'Sunrise',
        days: ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'],
        months: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'] },
};
const SR_KEYS = ['fajr', 'dhuhr', 'asr', 'maghrib', 'isha'];
const SR_PRAYER_TILE_IDS = SR_KEYS.map(k => 'tile_' + k);
/* Hilfslinien: Einrasten + Anzeige wenn Element-/Gruppenmitte nahe Bühnenmitte (50%). */
const SR_GUIDE_CENTER = 50;
const SR_GUIDE_SNAP = 0.85;    /* % — Magnet beim Ziehen / Skalieren */
const SR_GUIDE_SHOW = 0.4;      /* % — Linie sichtbar wenn bereits ausgerichtet */

/* Demo-Zeiten für die Studio-Vorschau (kein Pi-Bezug nötig, rein optisch —
   identisch zur bisherigen STAGE_TILES-Tabelle in main.js). */
const SR_DEMO_TIMES = {
  fajr: '04:18', dhuhr: '13:16', asr: '17:02', maghrib: '20:44', isha: '22:21',
};
const SR_DEMO_FAJR_SUB = { beginn: '03:42', aufgang: '05:31' };
const SR_DEMO_MOSQUE = 'Islamisch-Albanisches-Kulturzentrum';

/* CSV-Spalten — identisch zu kiosk-logic.js (I-Indizes). */
const SR_PRAYER_I = { fajr: 0, sabah: 1, sunrise: 2, dhuhr: 3, asr: 4, maghrib: 5, isha: 6, isha_adhan: 7, hijri: 8 };

function SR_pad(n) { return String(n).padStart(2, '0'); }
function SR_clean(t) { return (t || '').replace(/:00$/, '') || '--:--'; }
function SR_tMin(t) { const p = SR_clean(t).split(':'); return parseInt(p[0], 10) * 60 + parseInt(p[1], 10); }
function SR_tSec(t) { const m = SR_tMin(t); return isNaN(m) ? NaN : m * 60; }
function SR_dateKey(d) { return SR_pad(d.getDate()) + '.' + SR_pad(d.getMonth() + 1) + '.' + d.getFullYear(); }
function SR_fmtHMS(totalSec) {
  const s = Math.max(0, Math.floor(totalSec));
  return SR_pad(Math.floor(s / 3600)) + ':' + SR_pad(Math.floor((s % 3600) / 60)) + ':' + SR_pad(s % 60);
}

function SR_parsePrayerCSV(text) {
  const result = {};
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim()) continue;
    const c = line.split(',').map(s => s.trim().replace(/^"|"$/g, ''));
    if (!c[0] || !/^\d{2}\.\d{2}\.\d{4}$/.test(c[0])) continue;
    result[c[0]] = [c[3], c[4], c[5], c[6], c[8], c[10], c[12], c[13], c[1]];
  }
  return result;
}

function SR_getTodayTomorrowPrayers(parsed) {
  if (!parsed || typeof parsed !== 'object') return { today: null, tomorrow: null };
  const now = new Date();
  const t2 = new Date(now);
  t2.setDate(t2.getDate() + 1);
  return { today: parsed[SR_dateKey(now)] || null, tomorrow: parsed[SR_dateKey(t2)] || null };
}

function SR_demoPrayerRow() {
  return [
    SR_DEMO_FAJR_SUB.beginn, SR_DEMO_TIMES.fajr, SR_DEMO_FAJR_SUB.aufgang,
    SR_DEMO_TIMES.dhuhr, SR_DEMO_TIMES.asr, SR_DEMO_TIMES.maghrib, SR_DEMO_TIMES.isha,
    SR_DEMO_TIMES.isha, '',
  ];
}

function SR_fokusCfg(fokus) {
  void fokus;
  return {};
}

function SR_computeNextPrayer(now, today, tomorrow, fokus) {
  void fokus;
  if (!today) return { key: null, targetSec: NaN, times: [], cur: 0, nd: false };
  const I = SR_PRAYER_I;
  const cur = now.getHours() * 60 + now.getMinutes();
  const times = SR_KEYS.map(k => {
    let t;
    if (k === 'fajr') t = SR_tMin(today[I.sabah]);
    else if (k === 'isha') {
      const ad = SR_tMin(today[I.isha_adhan]);
      t = isNaN(ad) ? SR_tMin(today[I.isha]) : ad;
    } else {
      const idx = k === 'dhuhr' ? I.dhuhr : k === 'asr' ? I.asr : I.maghrib;
      t = SR_tMin(today[idx]);
    }
    return { key: k, t };
  });
  let ni = -1, nm = Infinity;
  times.forEach((p, i) => { if (p.t > cur && p.t < nm) { nm = p.t; ni = i; } });
  let nd = false;
  if (ni === -1 && tomorrow) {
    ni = 0;
    nm = SR_tMin(tomorrow[I.sabah]) + 1440;
    nd = true;
  } else if (ni === -1) {
    ni = 0;
    nd = true;
  }
  const nextKey = times[ni] ? times[ni].key : null;
  return {
    key: nextKey,
    targetSec: isFinite(nm) ? (nm % 1440) * 60 : NaN,
    times, cur, nd,
  };
}

function SR_countdownRemain(now, nextKey, targetSec, today, fokus) {
  void nextKey; void today; void fokus;
  const nowSec = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  let remain = targetSec - nowSec;
  if (remain < 0) remain += 86400;
  return remain;
}

/* Standard-Boxen & Stile: siehe kiosk-base-defaults.js (KIOSK_BASE_DEFAULTS). */
const _KBD = window.KIOSK_BASE_DEFAULTS;
const SR_OVERRIDE_DEFAULTS = _KBD.override;
const SR_TILE_STYLE_DEFAULTS = _KBD.tile;
const SR_CLOCK_STYLE_DEFAULTS = _KBD.clock;
const SR_INFO_STYLE_DEFAULTS = _KBD.info;
const SR_FAJR_ONLY_PROPS = _KBD.fajrOnlyProps;
const SR_DHUHR_ONLY_PROPS = _KBD.dhuhrOnlyProps;
const SR_JUMUAH_DEFAULTS = _KBD.jumuahDefaults;
const SR_ICON_BASE_PX = _KBD.iconBasePx;
const SR_TILE_PAD = _KBD.tilePad;
const SR_ICON_MB = _KBD.iconMb;

const SR_RESIZE_EDGES = ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'];

function SR_resizeHandlesHTML(id) {
  return SR_RESIZE_EDGES.map(edge =>
    `<span class="ds-rs ds-rs-${edge}" data-rs="${id}" data-edge="${edge}" aria-hidden="true"></span>`
  ).join('');
}

/* Harte Schriftgrößen-Maxima je Teil (v1.10 — Regler-Obergrenzen statt Kaskade). */
const SR_INFO_SECTIONS = [
  { part: 'title',  field: 'titel',    label: 'Titel',             rtl: false,
    fontField: 'titleFontSize', colorField: 'titleColor', weightField: 'titleWeight',
    fontFamilyField: 'titleFontFamily', fontCategory: 'display',
    min: 18, max: 48, defaultSize: 34, defaultColor: '#c5a55a' },
  { part: 'arabic', field: 'arabisch', label: 'Arabischer Text',   rtl: true,
    fontField: 'arFontSize', colorField: 'arColor', weightField: null,
    fontFamilyField: 'arFontFamily', fontCategory: 'arabic',
    min: 24, max: 72, defaultSize: 48, defaultColor: '#c5a55a' },
  { part: 'text',   field: 'text',     label: 'Übersetzung (DE/AL)', rtl: false,
    fontField: 'nameFontSize', colorField: 'nameColor', weightField: null,
    fontFamilyField: 'nameFontFamily', fontCategory: 'display',
    min: 10, max: 50, defaultSize: 22, defaultColor: '#e8eefc' },
  { part: 'source', field: 'quelle',   label: 'Quelle',            rtl: false,
    fontField: 'srcFontSize', colorField: 'srcColor', weightField: null,
    fontFamilyField: 'srcFontFamily', fontCategory: 'latin',
    min: 8, max: 22, defaultSize: 18, defaultColor: '#8a96b6' },
];

const SR_SPLIT_INFO_KEYS = ['info_title', 'info_arabic', 'info_text', 'info_source'];

/* Migriert v1.9-Split-Layouts (4 Teile) auf eine info-Kachel. */
function migrateSplitInfoOverrides(overrides) {
  if (!overrides || typeof overrides !== 'object') return overrides;
  const hasSplit = SR_SPLIT_INFO_KEYS.some(k => overrides[k]);
  if (!hasSplit) return overrides;

  const mergedStyle = {};
  SR_SPLIT_INFO_KEYS.forEach(k => {
    const s = overrides[k] && overrides[k].style;
    if (s) Object.assign(mergedStyle, s);
  });

  if (!overrides.info) {
    let x = 100, y = 100, x2 = 0, y2 = 0;
    SR_SPLIT_INFO_KEYS.forEach(k => {
      const b = overrides[k];
      if (!b) return;
      x = Math.min(x, b.x);
      y = Math.min(y, b.y);
      x2 = Math.max(x2, b.x + b.w);
      y2 = Math.max(y2, b.y + b.h);
    });
    overrides.info = (x2 > x)
      ? { x, y, w: x2 - x, h: y2 - y }
      : { ...SR_OVERRIDE_DEFAULTS.info };
  }
  if (Object.keys(mergedStyle).length) {
    overrides.info.style = { ...(overrides.info.style || {}), ...mergedStyle };
  }
  SR_SPLIT_INFO_KEYS.forEach(k => { delete overrides[k]; });
  return overrides;
}

/* Vollständige Basis-Konfiguration (Position + Stil) — 1:1 wie der Live-Kiosk
   nach „Zurücksetzen“. Wird für resetLayout(), Erststart und defaultOverrideElements genutzt. */
function SR_tileBaseStyle(tileId) {
  const s = { ...SR_TILE_STYLE_DEFAULTS };
  delete s.bgOpacity;
  if (tileId !== 'tile_fajr') SR_FAJR_ONLY_PROPS.forEach(p => { delete s[p]; });
  if (tileId !== 'tile_dhuhr') SR_DHUHR_ONLY_PROPS.forEach(p => { delete s[p]; });
  return s;
}

function SR_baseStyleFor(id) {
  if (id === 'clock') return { ...SR_CLOCK_STYLE_DEFAULTS };
  if (id === 'info') {
    const s = { ...SR_INFO_STYLE_DEFAULTS };
    delete s.bgOpacity;
    return s;
  }
  if (id && id.indexOf('tile_') === 0) return SR_tileBaseStyle(id);
  return null;
}

/** bgOpacity gehört zum globalen Design-Regler — nicht in Basis-Overrides. */
function SR_stripDefaultBgOpacity(overrides) {
  if (!overrides || typeof overrides !== 'object') return overrides;
  Object.keys(overrides).forEach(k => {
    const sty = overrides[k] && overrides[k].style;
    if (sty && Object.prototype.hasOwnProperty.call(sty, 'bgOpacity')) {
      delete sty.bgOpacity;
    }
  });
  return overrides;
}

function SR_baseOverrideElement(id) {
  const box = SR_OVERRIDE_DEFAULTS[id];
  if (!box) return null;
  const el = { ...box };
  const sty = SR_baseStyleFor(id);
  if (sty) el.style = { ...sty };
  return el;
}

function SR_buildBaseOverrides(includeInfo) {
  const o = {};
  o.clock = SR_baseOverrideElement('clock');
  SR_KEYS.forEach(k => { o['tile_' + k] = SR_baseOverrideElement('tile_' + k); });
  if (includeInfo) o.info = SR_baseOverrideElement('info');
  return o;
}


/* ════════════════════════════════════════════════════════════════════════════
   StudioRenderer
   ════════════════════════════════════════════════════════════════════════════ */
class StudioRenderer {

  // ═══════════════════════════════════════════════════════════
  // 1. INITIALISIERUNG & DATEN
  // ═══════════════════════════════════════════════════════════

  constructor(containerElement, getPiBaseUrl) {
    this.container = containerElement;
    /* getPiBaseUrl ist ein Getter (Funktion), kein fester String — main.js
       aktualisiert DS_PI_BASE asynchron (pi_base_url()), der Renderer soll
       also bei JEDEM Render den aktuellsten Wert lesen, nicht den Stand vom
       Konstruktor-Aufruf einfrieren. */
    this._getPiBase = typeof getPiBaseUrl === 'function' ? getPiBaseUrl : (() => getPiBaseUrl || null);

    // State: einzige Source of Truth (Anforderung "Alles läuft durch this.state")
    this.state = {
      info: null,
      lang: 'de',
      design: { blur: 12, opacity: 55, darken: 30 },
      background: null,
      overrides: {},
      locked: true,
      prayersToday: null,
      prayersTomorrow: null,
      fokus: null,
    };
    this._lastPrayerRenderKey = '';

    // UI-State (Drag/Resize, Gruppenauswahl v1.11)
    this._drag = null;        // { id, mode, startX, startY, startBox, stageRect, groupStartBoxes? }
    this._selectedGroup = new Set();
    this._modalEl = null;     // aktuell offenes Style-Modal (Overlay-DOM)
    this._listenersAttached = false;
    this._escGroupAttached = false;
    this._boundMove = this._onPointerMove.bind(this);
    this._boundUp   = this._onPointerUp.bind(this);
    this._boundEsc  = this._onKeyDown.bind(this);
    this._sessionSnapshot = null;  /* Stand beim Öffnen des Design-Studios (Reset ⟲) */

    // Callback-Hooks, die main.js setzen kann, um auf Änderungen zu reagieren
    // (z. B. Layout-Readout aktualisieren) — optional, kein Pflichtfeld.
    this.onOverrideChange = null;  // () => void, nach jedem committeten Override
  }

  /* Lädt Design/Hintergrund/Layout/Infotext und rendert. Wird von main.js
     aus pullPreviewState() heraus mit den dort bereits geladenen Daten
     aufgerufen (siehe Integrationsguide) — KEINE eigenen pywebview-Aufrufe
     hier, um das bestehende, bewährte Laden (inkl. Online/Offline-Fallback
     auf die lokale Bibliothek) nicht zu duplizieren. */
  setState({ info, lang, design, background, overrides, prayersToday, prayersTomorrow, fokus } = {}) {
    if (info !== undefined) this.state.info = info;
    if (lang && SR_LANG[lang]) this.state.lang = lang;
    if (design) this.state.design = { ...design };
    if (background !== undefined) this.state.background = background || null;
    if (prayersToday !== undefined) this.state.prayersToday = prayersToday;
    if (prayersTomorrow !== undefined) this.state.prayersTomorrow = prayersTomorrow;
    if (fokus !== undefined) this.state.fokus = fokus;
    if (overrides) {
      this.state.overrides = this._ensureCompleteOverrides(
        SR_stripDefaultBgOpacity(migrateSplitInfoOverrides({ ...overrides }))
      );
    }
    this._syncInfoLayoutPresence();
    this.render();
  }

  _langPack() {
    return SR_LANG[this.state.lang] || SR_LANG.de;
  }

  /* Hadith-Kachel nur im Layout, wenn ein Infotext wirklich angezeigt wird. */
  _syncInfoLayoutPresence() {
    if (this.hasInfoContent(this.state.info)) {
      if (!this.state.overrides.info) {
        this.state.overrides.info = SR_baseOverrideElement('info');
      }
    } else {
      delete this.state.overrides.info;
    }
  }

  /* Fehlende Gebets-Kachel-Keys mit TV-Defaults ergänzen; info nur bei Inhalt. */
  _ensureCompleteOverrides(overrides) {
    const o = SR_stripDefaultBgOpacity(migrateSplitInfoOverrides({ ...(overrides || {}) }));
    Object.keys(SR_OVERRIDE_DEFAULTS).forEach(k => {
      if (k === 'info') return;
      if (!o[k]) o[k] = SR_baseOverrideElement(k);
    });
    if (this.hasInfoContent(this.state.info)) {
      if (!o.info) o.info = SR_baseOverrideElement('info');
    } else {
      delete o.info;
    }
    return o;
  }

  async refreshPrayers(piBase) {
    if (!piBase) return;
    try {
      const r = await fetch(piBase + '/api/csv', { cache: 'no-store' });
      if (!r.ok) return;
      const { today, tomorrow } = SR_getTodayTomorrowPrayers(SR_parsePrayerCSV(await r.text()));
      this.state.prayersToday = today;
      this.state.prayersTomorrow = tomorrow;
      this._lastPrayerRenderKey = '';
      if (this.container.querySelector('.ds-tile')) {
        this._syncTileTimesFromData();
        this.tickPrayerUI();
      }
    } catch (e) { /* offline: Demo-Zeiten bleiben */ }
  }

  _gregLabel(now) {
    const L = this._langPack();
    const d = now.getDate(), m = L.months[now.getMonth()], y = now.getFullYear();
    if (this.state.lang === 'de') {
      return L.days[now.getDay()] + ', ' + d + '. ' + m + ' ' + y;
    }
    return L.days[now.getDay()] + ', ' + d + '. ' + m + ' ' + y;
  }

  _hijriLabel() {
    const row = this.state.prayersToday;
    const h = row && row[SR_PRAYER_I.hijri] ? String(row[SR_PRAYER_I.hijri]).trim() : '';
    return h ? h + ' H' : '—';
  }

  _tileTimes(key) {
    const row = this.state.prayersToday;
    const I = SR_PRAYER_I;
    if (!row) {
      if (key === 'fajr') return { main: SR_DEMO_TIMES.fajr, sub: { ...SR_DEMO_FAJR_SUB } };
      return { main: SR_DEMO_TIMES[key], sub: null };
    }
    if (key === 'fajr') {
      return {
        main: SR_clean(row[I.sabah]),
        sub: { beginn: SR_clean(row[I.fajr]), aufgang: SR_clean(row[I.sunrise]) },
      };
    }
    const idx = key === 'dhuhr' ? I.dhuhr : key === 'asr' ? I.asr : key === 'maghrib' ? I.maghrib : I.isha;
    return { main: SR_clean(row[idx]), sub: null };
  }

  tickPrayerUI() {
    if (!this.container.querySelector('.ds-tile')) return;
    const now = new Date();
    const rk = SR_dateKey(now) + '|' + now.getHours() + ':' + now.getMinutes()
      + '|' + (this.state.prayersToday ? '1' : '0');
    if (rk !== this._lastPrayerRenderKey) {
      this._lastPrayerRenderKey = rk;
      this._syncTileTimesFromData();
    }

    const today = this.state.prayersToday || SR_demoPrayerRow();
    const np = SR_computeNextPrayer(now, today, this.state.prayersTomorrow, this.state.fokus);
    this.container.querySelectorAll('.ds-tile[data-key]').forEach(el => {
      const k = el.dataset.key;
      const f = np.times.find(x => x.key === k);
      el.classList.remove('demo-active', 'passed');
      if (k === np.key) el.classList.add('demo-active');
      else if (!np.nd && f && f.t < np.cur) el.classList.add('passed');
      else if (np.nd) el.classList.add('passed');

      const cd = el.querySelector('.ds-tile-countdown');
      if (!cd) return;
      if (k === np.key && isFinite(np.targetSec)) {
        cd.textContent = SR_fmtHMS(SR_countdownRemain(now, np.key, np.targetSec,
          today, this.state.fokus));
      } else {
        cd.textContent = '';
      }
    });

    const greg = this.container.querySelector('.ds-greg');
    const hijri = this.container.querySelector('.ds-hijri');
    if (greg) greg.textContent = this._gregLabel(now);
    if (hijri) hijri.textContent = this._hijriLabel();
  }

  _fajrLabelTexts(style) {
    const s = style || {};
    const L = this._langPack();
    return {
      beginn: String(s.fajrBeginnLabel || '').trim() || L.beginn,
      aufgang: String(s.fajrAufgangLabel || '').trim() || L.aufgang,
    };
  }

  _jumuahLabelTexts(style) {
    if (window.KIOSK_jumuahLabels) return window.KIOSK_jumuahLabels(style, this.state.lang);
    return { nameDe: SR_JUMUAH_DEFAULTS.de, nameAr: SR_JUMUAH_DEFAULTS.arLine };
  }

  _prayerTileNames(key, idx, style, when, forceJumuah) {
    const L = this._langPack();
    const isJumuah = forceJumuah || (key === 'dhuhr' && (window.KIOSK_isFriday
      ? window.KIOSK_isFriday(when || new Date())
      : (when || new Date()).getDay() === 5));
    if (isJumuah) return this._jumuahLabelTexts(style);
    return { nameDe: L.prayers[idx], nameAr: L.ar[idx] };
  }

  _fajrLabelsVisible(sty) {
    const s = { ...SR_TILE_STYLE_DEFAULTS, ...(sty || {}) };
    if (s.fajrLabelsVisible === 1) return true;
    if (s.fajrLabelsVisible === 0) return false;
    /* Alt: fajrSubVisible schaltete die ganze Zeile — nur noch Labels ableiten. */
    return s.fajrSubVisible === 1;
  }

  _fajrTileStyle() {
    const box = this.state.overrides.tile_fajr || {};
    return { ...SR_TILE_STYLE_DEFAULTS, ...(box.style || {}) };
  }

  _applyFajrLabelsLayout() {
    const sty = this._fajrTileStyle();
    const showLabels = this._fajrLabelsVisible(sty);
    const fajr = this.container.querySelector('.ds-tile[data-key="fajr"]');
    if (fajr) {
      fajr.querySelectorAll('.ds-fsub-label').forEach(lb => {
        lb.style.display = showLabels ? '' : 'none';
      });
    }
  }

  _syncTileTimesFromData() {
    this.container.querySelectorAll('.ds-tile[data-key]').forEach(el => {
      const key = el.dataset.key;
      const tt = this._tileTimes(key);
      const timeEl = el.querySelector('.ds-ptime');
      if (timeEl) timeEl.textContent = tt.main;
      if (key === 'fajr' && tt.sub) {
        const tBegin = el.querySelector('.ds-fajr-sub-begin .ds-fsub-time');
        const tRise = el.querySelector('.ds-fajr-sub-rise .ds-fsub-time');
        if (tBegin) tBegin.textContent = tt.sub.beginn;
        if (tRise) tRise.textContent = tt.sub.aufgang;
      }
    });
    this._syncTileNamesFromData();
  }

  _syncTileNamesFromData() {
    const now = new Date();
    this.container.querySelectorAll('.ds-tile[data-key]').forEach(el => {
      const key = el.dataset.key;
      const idx = SR_KEYS.indexOf(key);
      if (idx < 0) return;
      const id = 'tile_' + key;
      const sty = (this.state.overrides[id] && this.state.overrides[id].style) || {};
      const names = this._prayerTileNames(key, idx, sty, now);
      const nameDeEl = el.querySelector('.ds-name-de');
      const nameArEl = el.querySelector('.ds-name-ar');
      if (nameDeEl) nameDeEl.textContent = names.nameDe;
      if (nameArEl) nameArEl.textContent = names.nameAr;
    });
  }

  setLocked(locked) {
    this.state.locked = !!locked;
    if (this.state.locked) {
      this._hideGuides();
      this._clearGroupSelection();
    }
    const stage = this.container.closest('.ds-stage') || this.container;
    stage.classList.toggle('editing', !this.state.locked);
  }

  // ═══════════════════════════════════════════════════════════
  // 3. RENDERING
  // ═══════════════════════════════════════════════════════════

  render() {
    this._clearGroupSelection();
    this.container.innerHTML = this.buildStageHTML();
    this.applyAllStyles();
    this.applyBackground();
    this.attachEventListeners();
    this.setLocked(this.state.locked);
    this.tickPrayerUI();
  }

  buildStageHTML() {
    const tiles = SR_KEYS.map(key => this._buildTileHTML(key)).join('');
    const info = this._buildInfoBoxHTML();

    return `
      <div class="sr-viewport">
        <div class="sr-scale" data-role="scale">
          <div class="ds-bg default" data-role="bg"></div>
          <div class="ds-darken" data-role="darken"></div>
          <div class="ds-guide-layer" data-role="guides" aria-hidden="true">
            <div class="ds-guide-line v" data-guide="v"></div>
            <div class="ds-guide-line h" data-guide="h"></div>
            <div class="ds-guide-line h snap" data-guide="align-h"></div>
            <div class="ds-guide-line v snap" data-guide="align-v"></div>
          </div>
          <div class="ds-top">
            <div class="ds-mosque">
              ${typeof mosqueLogoHtml === 'function' ? mosqueLogoHtml({ className: 'ds-mosque-logo', strokeWidth: 2.4 }) : ''}
              <div class="ds-mosque-name">${this.escape(SR_DEMO_MOSQUE)}</div>
            </div>
            <div class="ds-dates">
              <div class="ds-greg"></div>
              <div class="ds-hijri"></div>
            </div>
          </div>
          <div class="ds-el ds-clock" data-el="clock">
            <div class="ds-time-big"><span class="ds-hm">12:45</span><span class="ds-secs">:00</span></div>
            ${SR_resizeHandlesHTML('clock')}
          </div>
          <div class="ds-tiles" data-role="tiles">${tiles}</div>
          ${info}
        </div>
      </div>`;
  }

  _buildTileHTML(key) {
    const idx = SR_KEYS.indexOf(key);
    const icon = SR_ICONS[key] || '';
    const id = 'tile_' + key;
    const tileStyle = (this.state.overrides[id] && this.state.overrides[id].style) || {};
    const names = this._prayerTileNames(key, idx, tileStyle, new Date());
    const nameDe = names.nameDe;
    const nameAr = names.nameAr;
    const tt = this._tileTimes(key);
    const cdHTML = `<div class="ds-tile-countdown countdown-inset" data-cd="${key}" data-part="countdown"></div>`;
    const fajrStyle = (this.state.overrides[id] && this.state.overrides[id].style) || {};
    const fajrLb = this._fajrLabelTexts(fajrStyle);

    const timeBlockHTML = `<div class="ptime-block"><div class="ds-ptime" data-part="time">${this.escape(tt.main)}</div>${cdHTML}</div>`;
    let fajrSubHTML = '';
    if (key === 'fajr') {
      fajrSubHTML = `<div class="ds-fajr-sub" data-part="fajrSub">` +
        `<div class="ds-fajr-sub-cell ds-fajr-sub-begin">` +
        `<span class="ds-fsub-time">${this.escape(tt.sub.beginn)}</span>` +
        `<span class="ds-fsub-label">${this.escape(fajrLb.beginn)}</span></div>` +
        `<div class="ds-fajr-sub-cell ds-fajr-sub-rise">` +
        `<span class="ds-fsub-time">${this.escape(tt.sub.aufgang)}</span>` +
        `<span class="ds-fsub-label">${this.escape(fajrLb.aufgang)}</span></div></div>`;
    }

    return `<div class="ds-el ds-tile" data-el="${id}" data-key="${key}">
      <div class="ds-tile-head">
        <div class="ds-icon" data-part="icon">${icon}</div>
        <div><div class="ds-name-de" data-part="nameDe">${this.escape(nameDe)}</div><div class="ds-name-ar" data-part="nameAr">${nameAr}</div></div>
        ${timeBlockHTML}
      </div>
      ${fajrSubHTML}
      ${SR_resizeHandlesHTML(id)}
    </div>`;
  }

  /* v1.10: Eine zusammenhängende Hadith-Kachel mit 4 Inhalts-Kindern in fester
     Reihenfolge (Titel → Trennlinie → Arabisch → Übersetzung → Quelle). */
  _buildInfoBoxHTML() {
    const info = this.state.info;
    if (!info || !this.hasInfoContent(info)) return '';

    const titel = String(info.titel || '').trim();
    const arab = String(info.arabisch || '').trim();
    const txt = String(info.text || '').trim();
    const quelle = String(info.quelle || '').trim();

    let inner = '';
    if (titel) {
      inner += `<div class="ds-info-title" data-part="title">${this.escape(titel)}</div>`;
      inner += '<div class="ds-info-divider"></div>';
    }
    if (arab) inner += `<div class="ds-info-arabic" data-part="arabic" dir="rtl">${this.escape(arab)}</div>`;
    if (txt) inner += `<div class="ds-info-text" data-part="text">${this.escape(txt)}</div>`;
    if (quelle) inner += `<div class="ds-info-source" data-part="source">${this.escape(quelle)}</div>`;

    return `<div class="ds-el ds-info" data-el="info">
      <div class="ds-info-inner">${inner}</div>
      ${SR_resizeHandlesHTML('info')}
    </div>`;
  }

  // ═══════════════════════════════════════════════════════════
  // STYLES ANWENDEN (Skalierung, Positionen, Design, Per-Element-Stile)
  // ═══════════════════════════════════════════════════════════

  /* Berechnet den transform:scale()-Faktor: tatsächliche .ds-stage-Breite
     geteilt durch die TV-Referenzbreite (1920px) — exakt dieselbe Formel wie
     kiosk-logic.js tvScale() und die bisherige scaleDashIframe() in main.js.
     Das ist der Kern von Anforderung 1 (maßstabsgetreue Darstellung):
     Studio und Dashboard nutzen jetzt identische Geometrie. */
  _stageScale() {
    const stage = this.container.closest('.ds-stage') || this.container;
    const w = stage.offsetWidth || 780;
    return w / SR_TV_REF_W;
  }

  applyAllStyles() {
    this._applyViewportScale();
    this._applyDesignVars();
    this.state_lastScale = this._stageScale();

    this.container.querySelectorAll('.ds-tile').forEach(el => {
      const id = el.dataset.el;
      const box = this.state.overrides[id];
      this._positionElement(el, box, SR_OVERRIDE_DEFAULTS[id]);
      this._applyTileStyle(el, (box && box.style) || null);
    });
    this._applyFajrLabelsLayout();

    const clockEl = this.container.querySelector('.ds-clock');
    if (clockEl) {
      this._positionElement(clockEl, this.state.overrides.clock, SR_OVERRIDE_DEFAULTS.clock);
      const csty = (this.state.overrides.clock && this.state.overrides.clock.style) || null;
      this._applyClockStyle(clockEl, csty);
    }

    const infoEl = this.container.querySelector('.ds-info');
    if (infoEl) {
      const box = this.state.overrides.info;
      this._positionElement(infoEl, box, SR_OVERRIDE_DEFAULTS.info);
      this._applyInfoStyle(infoEl, (box && box.style) || null);
    }

    if (this._fitPrayerTileHeights()) {
      SR_PRAYER_TILE_IDS.forEach(tid => {
        const el = this.container.querySelector('[data-el="' + tid + '"]');
        if (el) this._positionElement(el, this.state.overrides[tid], SR_OVERRIDE_DEFAULTS[tid]);
      });
    }
    this._scheduleTileGlass();
  }

  _scheduleTileGlass() {
    if (!window.KIOSK_scheduleTileGlass) return;
    window.KIOSK_scheduleTileGlass({
      container: this.container,
      bgEl: this.container.querySelector('[data-role="bg"]'),
      darkenEl: this.container.querySelector('[data-role="darken"]'),
    });
  }

  /* Fajr ist die Messlatte (Countdown + Beginn/Aufgang). Alle Gebetskacheln gleich
     hoch — exakt so hoch wie Fajr-Inhalt noetig, aber nie unter die Hadith-Box. */
  _fitPrayerTileHeights() {
    const fajr = this.container.querySelector('.ds-tile[data-key="fajr"]');
    const scaleEl = this.container.querySelector('[data-role="scale"]');
    if (!fajr || !scaleEl || fajr.clientHeight < 1 || scaleEl.clientHeight < 1) return false;

    const tileBox = this.state.overrides.tile_fajr || SR_OVERRIDE_DEFAULTS.tile_fajr;
    const infoBox = this.state.overrides.info || SR_OVERRIDE_DEFAULTS.info;
    const tileY = (typeof tileBox.y === 'number') ? tileBox.y : SR_OVERRIDE_DEFAULTS.tile_fajr.y;
    const infoY = (typeof infoBox.y === 'number') ? infoBox.y : SR_OVERRIDE_DEFAULTS.info.y;
    const maxH = Math.max(3, infoY - tileY - _KBD.tileInfoGapPct);

    const cdEl = fajr.querySelector('.ds-tile-countdown');
    const prevCd = cdEl ? cdEl.textContent : '';
    const wasActive = fajr.classList.contains('demo-active');
    fajr.classList.add('demo-active');
    if (cdEl) cdEl.textContent = _KBD.fajrMeasureCd;

    const needH = fajr.scrollHeight;
    const stageH = scaleEl.clientHeight;

    if (cdEl) cdEl.textContent = prevCd;
    if (!wasActive) fajr.classList.remove('demo-active');
    if (needH < 1 || stageH < 1) return false;

    const curH = (typeof tileBox.h === 'number') ? tileBox.h : SR_OVERRIDE_DEFAULTS.tile_fajr.h;
    const curPxH = fajr.clientHeight;
    /* Nur vergrößern wenn Inhalt wirklich überläuft — verhindert schleichendes Wachstum
       bei wiederholtem applyAllStyles / ⊞-Klick. */
    if (needH <= curPxH + 4) return false;

    const needPct = Math.ceil((needH / stageH) * 1000) / 10;
    const newH = Math.min(maxH, Math.max(curH, needPct));
    if (Math.abs(newH - curH) < 0.1) return false;

    SR_PRAYER_TILE_IDS.forEach(tid => {
      if (!this.state.overrides[tid]) this.state.overrides[tid] = { ...SR_OVERRIDE_DEFAULTS[tid] };
      this.state.overrides[tid].h = newH;
    });
    return true;
  }

  _repositionPrayerTiles() {
    SR_PRAYER_TILE_IDS.forEach(tid => {
      const el = this._findEl(tid);
      const box = this.state.overrides[tid];
      if (el && box) this._positionElement(el, box, SR_OVERRIDE_DEFAULTS[tid]);
    });
  }

  _applyViewportScale() {
    const scaleEl = this.container.querySelector('[data-role="scale"]');
    if (!scaleEl) return;
    const s = this._stageScale();
    scaleEl.style.transform = 'scale(' + s.toFixed(5) + ')';
  }

  _applyDesignVars() {
    const scaleEl = this.container.querySelector('[data-role="scale"]');
    if (!scaleEl) return;
    if (window.KIOSK_applyDesignVars) {
      window.KIOSK_applyDesignVars(scaleEl.style, this.state.design);
    } else {
      scaleEl.style.setProperty('--tile-blur', this.state.design.blur + 'px');
      scaleEl.style.setProperty('--tile-alpha', (this.state.design.opacity / 100).toFixed(2));
    }
    const darken = scaleEl.querySelector('[data-role="darken"]');
    if (darken) darken.style.opacity = (this.state.design.darken / 100).toFixed(2);
    /* Globale Regler: Kacheln ohne eigene Deckkraft nutzen CSS-Variablen. */
    this.container.querySelectorAll('.ds-tile, .ds-info').forEach(el => {
      const id = el.dataset.el;
      const sty = (this.state.overrides[id] && this.state.overrides[id].style) || {};
      if (!Object.prototype.hasOwnProperty.call(sty, 'bgOpacity') && window.KIOSK_setTileTint) {
        window.KIOSK_setTileTint(el, '');
      }
    });
    if (window.KIOSK_refreshAllTileDesign) {
      window.KIOSK_refreshAllTileDesign(this.container);
    }
    this._scheduleTileGlass();
  }

  /* Positioniert ein Element absolut auf dem 1920×1080-Layoutraum, in %
     relativ zur Bühne (Koordinatensystem laut Pitch: 0-100%). */
  _positionElement(el, box, fallback) {
    const b = box || fallback;
    if (!b) { el.style.display = 'none'; return; }
    el.style.position = 'absolute';
    el.style.left   = b.x + '%';
    el.style.top    = b.y + '%';
    el.style.width  = b.w + '%';
    el.style.height = b.h + '%';
    el.style.display = 'flex';
  }

  _applyClockStyle(el, sty) {
    sty = sty || {};
    const s = { ...SR_CLOCK_STYLE_DEFAULTS, ...sty };
    const fpx = v => (typeof v === 'number' && v > 0) ? (v + 'px') : '';
    const big = el.querySelector('.ds-time-big');
    const secs = el.querySelector('.ds-secs');
    if (big) {
      big.style.fontSize = fpx(s.clockFontSize);
      big.style.color = s.clockColor || SR_CLOCK_STYLE_DEFAULTS.clockColor;
      big.style.fontWeight = '300';
      big.style.letterSpacing = '-2px';
      big.style.lineHeight = '1';
      big.style.fontVariantNumeric = 'tabular-nums';
      big.style.textShadow = '0 2px 12px rgba(0,0,0,.6)';
      window.KIOSK_applyFontFamily(big, s.clockFontFamily, 'display');
    }
    if (secs) {
      secs.style.fontSize = fpx(s.secsFontSize);
      secs.style.color = s.secsColor || SR_CLOCK_STYLE_DEFAULTS.secsColor;
      secs.style.fontWeight = '300';
      secs.style.fontVariantNumeric = 'tabular-nums';
      secs.style.fontFeatureSettings = '"tnum" 1';
      window.KIOSK_applyFontFamily(secs, s.clockFontFamily, 'display');
    }
    el.style.fontSize = '';
    el.style.color = '';
  }

  /* Gebets-Kachel-Stile: TV-Referenz-Pixel (1920px-Basis) direkt auf die Bühne.
     Die visuelle Skalierung übernimmt transform:scale() auf .sr-scale — KEIN
     zusätzliches _stageScale() auf Schriftgrößen (sonst Doppel-Skalierung). */
  _applyTileStyle(el, sty) {
    sty = sty || {};
    const s = { ...SR_TILE_STYLE_DEFAULTS, ...sty };
    const fpx = v => (typeof v === 'number' && v > 0) ? (v + 'px') : '';

    const timeEl = el.querySelector('.ds-ptime');
    const nameEl = el.querySelector('.ds-name-de');
    const arEl   = el.querySelector('.ds-name-ar');
    const iconEl = el.querySelector('.ds-icon');

    if (timeEl) {
      timeEl.style.fontSize = fpx(s.timeFontSize);
      timeEl.style.color    = sty.timeColor || s.timeColor || '';
      window.KIOSK_applyFontFamily(timeEl, s.timeFontFamily, 'latin');
    }
    if (nameEl) {
      nameEl.style.fontSize = fpx(s.nameFontSize);
      nameEl.style.color    = sty.nameColor || s.nameColor || '';
      window.KIOSK_applyFontFamily(nameEl, s.nameFontFamily, 'latin');
    }
    if (arEl) {
      arEl.style.fontSize = fpx(s.arFontSize);
      arEl.style.color    = sty.arColor || s.arColor || '';
      window.KIOSK_applyFontFamily(arEl, s.arFontFamily, 'arabic');
    }
    if (iconEl) {
      const isc = (typeof s.iconScale === 'number') ? s.iconScale : SR_TILE_STYLE_DEFAULTS.iconScale;
      const svg = iconEl.querySelector('svg');
      const dim = Math.round(SR_ICON_BASE_PX * isc / 100) + 'px';
      if (svg) {
        svg.style.width = dim;
        svg.style.height = dim;
      }
      iconEl.style.transform = '';
      iconEl.style.marginBottom = SR_ICON_MB + 'px';
      iconEl.style.flexShrink = '0';
    }
    el.querySelectorAll('.ds-fsub-label').forEach(lb => {
      lb.style.fontSize = fpx(s.fajrLabelSize);
      if (s.fajrLabelColor) lb.style.color = s.fajrLabelColor;
      window.KIOSK_applyFontFamily(lb, s.fajrLabelFontFamily, 'latin');
    });
    el.querySelectorAll('.ds-fsub-time').forEach(tm => {
      tm.style.fontSize = fpx(s.fajrTimeSize);
      if (s.fajrTimeColor) tm.style.color = s.fajrTimeColor;
      window.KIOSK_applyFontFamily(tm, s.fajrTimeFontFamily, 'latin');
    });
    if (el.dataset.key === 'fajr') {
      const lbs = this._fajrLabelTexts(sty);
      const lbB = el.querySelector('.ds-fajr-sub-begin .ds-fsub-label');
      const lbR = el.querySelector('.ds-fajr-sub-rise .ds-fsub-label');
      if (lbB) lbB.textContent = lbs.beginn;
      if (lbR) lbR.textContent = lbs.aufgang;
    }
    if (el.dataset.key === 'dhuhr' && window.KIOSK_isFriday && window.KIOSK_isFriday()) {
      const lbs = this._jumuahLabelTexts(sty);
      if (nameEl) nameEl.textContent = lbs.nameDe;
      if (arEl) arEl.textContent = lbs.nameAr;
    }
    const cdEl = el.querySelector('.ds-tile-countdown');
    if (cdEl) {
      const cdSize = (typeof s.countdownFontSize === 'number') ? s.countdownFontSize : SR_TILE_STYLE_DEFAULTS.countdownFontSize;
      cdEl.style.fontSize = fpx(cdSize);
      cdEl.style.minHeight = (cdSize * 1.25) + 'px';
      if (s.countdownColor) cdEl.style.color = s.countdownColor;
      window.KIOSK_applyFontFamily(cdEl, s.countdownFontFamily, 'latin');
    }
    const p = SR_TILE_PAD;
    el.style.padding = p.top + 'px ' + p.x + 'px ' + p.bottom + 'px';
    el.style.gap = '1px';
    el.style.boxSizing = 'border-box';
    el.style.display = 'flex';
    el.style.flexDirection = 'column';
    el.style.alignItems = 'center';
    el.style.justifyContent = 'flex-start';
    el.style.minHeight = '0';
    const rgba = (Object.prototype.hasOwnProperty.call(sty, 'bgOpacity') && typeof sty.bgOpacity === 'number')
      ? 'rgba(13,20,38,' + (sty.bgOpacity / 100).toFixed(2) + ')'
      : '';
    if (window.KIOSK_setTileTint) window.KIOSK_setTileTint(el, rgba);
    else el.style.background = rgba;
  }

  /* Hadith-Kachel-Stile: alle vier Teile in EINER Box, benannte Backend-Felder. */
  _applyInfoStyle(el, sty) {
    sty = sty || {};
    const def = SR_INFO_STYLE_DEFAULTS;
    const fpx = v => (typeof v === 'number' && v > 0) ? (v + 'px') : '';

    const titleEl = el.querySelector('.ds-info-title');
    const arEl = el.querySelector('.ds-info-arabic');
    const textEl = el.querySelector('.ds-info-text');
    const srcEl = el.querySelector('.ds-info-source');

    if (titleEl) {
      titleEl.style.fontSize = fpx(sty.titleFontSize || def.titleFontSize);
      titleEl.style.color = sty.titleColor || def.titleColor;
      titleEl.style.fontWeight = sty.titleWeight || def.titleWeight;
      window.KIOSK_applyFontFamily(titleEl, sty.titleFontFamily || def.titleFontFamily, 'display');
    }
    if (arEl) {
      arEl.style.fontSize = fpx(sty.arFontSize || def.arFontSize);
      arEl.style.color = sty.arColor || def.arColor;
      window.KIOSK_applyFontFamily(arEl, sty.arFontFamily || def.arFontFamily, 'arabic');
    }
    if (textEl) {
      textEl.style.fontSize = fpx(sty.nameFontSize || def.nameFontSize);
      textEl.style.color = sty.nameColor || def.nameColor;
      window.KIOSK_applyFontFamily(textEl, sty.nameFontFamily || def.nameFontFamily, 'display');
    }
    if (srcEl) {
      srcEl.style.fontSize = fpx(sty.srcFontSize || def.srcFontSize);
      srcEl.style.color = sty.srcColor || def.srcColor;
      window.KIOSK_applyFontFamily(srcEl, sty.srcFontFamily || def.srcFontFamily, 'latin');
    }
    if (Object.prototype.hasOwnProperty.call(sty, 'bgOpacity') && typeof sty.bgOpacity === 'number') {
      const rgba = 'rgba(13,20,38,' + (sty.bgOpacity / 100).toFixed(2) + ')';
      if (window.KIOSK_setTileTint) window.KIOSK_setTileTint(el, rgba);
      else el.style.background = rgba;
    } else if (window.KIOSK_setTileTint) {
      window.KIOSK_setTileTint(el, '');
    } else {
      el.style.background = '';
    }
  }

  applyBackground() {
    const bg = this.container.querySelector('[data-role="bg"]');
    if (!bg) return;
    const piBase = this._getPiBase();
    if (this.state.background && piBase) {
      const url = piBase + '/mediathek/' + encodeURIComponent(this.state.background) + '?t=' + Date.now();
      if (window.KIOSK_invalidateTileGlassImageCache) {
        window.KIOSK_invalidateTileGlassImageCache();
      }
      bg.style.backgroundImage = "url('" + url + "')";
      bg.classList.remove('default');
      this._scheduleTileGlass();
      const img = new Image();
      img.onload = () => {
        this._scheduleTileGlass();
        requestAnimationFrame(() => this._scheduleTileGlass());
      };
      img.src = url;
    } else {
      bg.style.backgroundImage = 'none';
      bg.classList.add('default');
      if (window.KIOSK_invalidateTileGlassImageCache) {
        window.KIOSK_invalidateTileGlassImageCache();
      }
      this._scheduleTileGlass();
    }
  }

  // ═══════════════════════════════════════════════════════════
  // 4. INTERAKTION: DRAG & RESIZE
  // ═══════════════════════════════════════════════════════════

  attachEventListeners() {
    this.container.querySelectorAll('.ds-el').forEach(el => {
      el.addEventListener('pointerdown', e => this._onPointerDown(el, e));
      el.addEventListener('dblclick', e => this._onDblClick(el, e));
    });
    const viewport = this.container.querySelector('.sr-viewport');
    if (viewport) {
      viewport.addEventListener('pointerdown', e => {
        if (this.state.locked) return;
        if (e.target.closest('.ds-el')) return;
        this._clearGroupSelection();
      });
    }
    if (!this._listenersAttached) {
      window.addEventListener('pointermove', this._boundMove);
      window.addEventListener('pointerup', this._boundUp);
      this._listenersAttached = true;
    }
    if (!this._escGroupAttached) {
      window.addEventListener('keydown', this._boundEsc);
      this._escGroupAttached = true;
    }
  }

  _isPrayerTile(id) {
    return SR_PRAYER_TILE_IDS.includes(id);
  }

  _clearGroupSelection() {
    this._selectedGroup.clear();
    this._updateGroupVisuals();
  }

  _updateGroupVisuals() {
    this.container.querySelectorAll('.ds-tile').forEach(el => {
      const id = this._elementId(el);
      el.classList.toggle('ds-selected', this._selectedGroup.has(id));
    });
    document.querySelectorAll('.ds-group-badge').forEach(b => b.remove());
    const ro = document.getElementById('dsLayoutReadout');
    if (!ro) return;
    const count = this._selectedGroup.size;
    if (count > 0) {
      ro.textContent = count + ' Kachel' + (count === 1 ? '' : 'n') + ' ausgewählt';
      ro.classList.add('ds-group-active');
    } else {
      ro.classList.remove('ds-group-active');
      const n = Object.keys(this.state.overrides || {}).length;
      ro.textContent = 'Einzeln · ' + n + ' Elemente frei platziert';
    }
  }

  _onKeyDown(e) {
    if (e.key !== 'Escape' || this.state.locked || this._modalEl) return;
    if (this._selectedGroup.size) this._clearGroupSelection();
  }

  _boxSnapshot(id) {
    const src = this.state.overrides[id] || SR_OVERRIDE_DEFAULTS[id];
    if (!src) return null;
    const snap = { x: src.x, y: src.y, w: src.w, h: src.h };
    if (src.style) snap.style = { ...src.style };
    return snap;
  }

  _clampGroupDelta(dxPct, dyPct, groupStartBoxes) {
    let minDx = -Infinity, maxDx = Infinity;
    let minDy = -Infinity, maxDy = Infinity;
    Object.values(groupStartBoxes).forEach(startBox => {
      const w = this._clampNum(startBox.w, 3, 100);
      const h = this._clampNum(startBox.h, 3, 100);
      minDx = Math.max(minDx, -startBox.x);
      maxDx = Math.min(maxDx, 100 - w - startBox.x);
      minDy = Math.max(minDy, -startBox.y);
      maxDy = Math.min(maxDy, 100 - h - startBox.y);
    });
    return {
      dx: Math.max(minDx, Math.min(maxDx, dxPct)),
      dy: Math.max(minDy, Math.min(maxDy, dyPct)),
    };
  }

  _bboxAfterDelta(groupStartBoxes, dx, dy) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    Object.values(groupStartBoxes).forEach(b => {
      minX = Math.min(minX, b.x + dx);
      minY = Math.min(minY, b.y + dy);
      maxX = Math.max(maxX, b.x + dx + b.w);
      maxY = Math.max(maxY, b.y + dy + b.h);
    });
    if (!isFinite(minX)) return { cx: SR_GUIDE_CENTER, cy: SR_GUIDE_CENTER };
    return { cx: (minX + maxX) / 2, cy: (minY + maxY) / 2 };
  }

  _snapDeltaToCenter(groupStartBoxes, dx, dy) {
    let snapDx = dx;
    let snapDy = dy;
    const bbox = this._bboxAfterDelta(groupStartBoxes, dx, dy);
    if (Math.abs(bbox.cx - SR_GUIDE_CENTER) <= SR_GUIDE_SNAP) {
      snapDx += SR_GUIDE_CENTER - bbox.cx;
    }
    if (Math.abs(bbox.cy - SR_GUIDE_CENTER) <= SR_GUIDE_SNAP) {
      snapDy += SR_GUIDE_CENTER - bbox.cy;
    }
    return this._clampGroupDelta(snapDx, snapDy, groupStartBoxes);
  }

  _centerGuideFlags(cx, cy) {
    return {
      v: Math.abs(cx - SR_GUIDE_CENTER) <= SR_GUIDE_SHOW,
      h: Math.abs(cy - SR_GUIDE_CENTER) <= SR_GUIDE_SHOW,
    };
  }

  _excludeIdSet(exclude) {
    const ex = new Set();
    if (exclude == null) return ex;
    if (typeof exclude === 'string') ex.add(exclude);
    else if (exclude instanceof Set) exclude.forEach(id => ex.add(id));
    else if (Array.isArray(exclude)) exclude.forEach(id => ex.add(id));
    return ex;
  }

  _boxToPeer(id) {
    const b = this.state.overrides[id] || SR_OVERRIDE_DEFAULTS[id];
    if (!b || typeof b.h !== 'number') return null;
    return {
      x: b.x, y: b.y, w: b.w, h: b.h,
      bottom: b.y + b.h,
      right: b.x + b.w,
    };
  }

  _peerBoxes(exclude) {
    const ex = this._excludeIdSet(exclude);
    const peers = [];
    const ids = new Set([
      ...Object.keys(SR_OVERRIDE_DEFAULTS),
      ...Object.keys(this.state.overrides || {}),
    ]);
    ids.forEach(id => {
      if (ex.has(id)) return;
      const p = this._boxToPeer(id);
      if (p) peers.push(p);
    });
    return peers;
  }

  /* Beim Verschieben von Gebetskacheln nur gegen andere Gebetskacheln snappen. */
  _movePeers(exclude, movingId) {
    const ex = this._excludeIdSet(exclude);
    const isPrayerDrag = this._isPrayerTile(movingId)
      || SR_PRAYER_TILE_IDS.some(id => ex.has(id));
    if (isPrayerDrag) {
      return SR_PRAYER_TILE_IDS
        .filter(id => !ex.has(id))
        .map(id => this._boxToPeer(id))
        .filter(Boolean);
    }
    return this._peerBoxes(ex);
  }

  _groupBboxStart(groupStartBoxes) {
    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    Object.values(groupStartBoxes).forEach(b => {
      minX = Math.min(minX, b.x);
      minY = Math.min(minY, b.y);
      maxX = Math.max(maxX, b.x + b.w);
      maxY = Math.max(maxY, b.y + b.h);
    });
    if (!isFinite(minX)) return null;
    return { minX, minY, maxX, maxY };
  }

  _snapMoveXY(x, y, w, h, peers) {
    let alignH = null;
    let alignV = null;
    if (Math.abs(x + w / 2 - SR_GUIDE_CENTER) <= SR_GUIDE_SNAP) x = SR_GUIDE_CENTER - w / 2;
    if (Math.abs(y + h / 2 - SR_GUIDE_CENTER) <= SR_GUIDE_SNAP) y = SR_GUIDE_CENTER - h / 2;

    if (peers.length) {
      let bestY = null;
      let bestYd = SR_GUIDE_SNAP;
      peers.forEach(p => {
        [
          { apply: p.y, guide: p.y },
          { apply: p.bottom, guide: p.bottom },
          { apply: p.bottom - h, guide: p.bottom },
          { apply: p.y - h, guide: p.y },
        ].forEach(c => {
          const d = Math.abs(y - c.apply);
          if (d <= bestYd) { bestYd = d; bestY = c; }
        });
      });
      if (bestY) { y = bestY.apply; alignH = bestY.guide; }

      let bestX = null;
      let bestXd = SR_GUIDE_SNAP;
      peers.forEach(p => {
        [
          { apply: p.x, guide: p.x },
          { apply: p.right, guide: p.right },
          { apply: p.right - w, guide: p.right },
          { apply: p.x - w, guide: p.x },
        ].forEach(c => {
          const d = Math.abs(x - c.apply);
          if (d <= bestXd) { bestXd = d; bestX = c; }
        });
      });
      if (bestX) { x = bestX.apply; alignV = bestX.guide; }
    }
    return { x, y, alignH, alignV };
  }

  _snapGroupDeltaToPeers(groupStartBoxes, dx, dy, peers) {
    let alignH = null;
    let alignV = null;
    const bb = this._groupBboxStart(groupStartBoxes);
    if (!bb || !peers.length) return { dx, dy, alignH, alignV };

    let bestDy = dy;
    let bestYd = SR_GUIDE_SNAP;
    peers.forEach(p => {
      [
        { ndy: p.y - bb.minY, guide: p.y },
        { ndy: p.bottom - bb.minY, guide: p.bottom },
        { ndy: p.bottom - bb.maxY, guide: p.bottom },
        { ndy: p.y - bb.maxY, guide: p.y },
      ].forEach(c => {
        const d = Math.abs(dy - c.ndy);
        if (d <= bestYd) { bestYd = d; bestDy = c.ndy; alignH = c.guide; }
      });
    });
    dy = bestDy;

    let bestDx = dx;
    let bestXd = SR_GUIDE_SNAP;
    peers.forEach(p => {
      [
        { ndx: p.x - bb.minX, guide: p.x },
        { ndx: p.right - bb.minX, guide: p.right },
        { ndx: p.right - bb.maxX, guide: p.right },
        { ndx: p.x - bb.maxX, guide: p.x },
      ].forEach(c => {
        const d = Math.abs(dx - c.ndx);
        if (d <= bestXd) { bestXd = d; bestDx = c.ndx; alignV = c.guide; }
      });
    });
    dx = bestDx;

    return { dx, dy, alignH, alignV };
  }

  _nearestPeerValue(val, peers, pick, maxDist) {
    let best = null;
    let bestD = maxDist;
    peers.forEach(p => {
      const v = pick(p);
      const d = Math.abs(val - v);
      if (d <= bestD) { bestD = d; best = v; }
    });
    return best;
  }

  _updateGuides(opts) {
    opts = opts || {};
    const layer = this.container.querySelector('[data-role="guides"]');
    if (!layer) return;
    const v = layer.querySelector('[data-guide="v"]');
    const h = layer.querySelector('[data-guide="h"]');
    const ah = layer.querySelector('[data-guide="align-h"]');
    const av = layer.querySelector('[data-guide="align-v"]');
    if (v) v.classList.toggle('on', !!opts.centerV);
    if (h) h.classList.toggle('on', !!opts.centerH);
    if (ah) {
      const on = typeof opts.alignH === 'number' && isFinite(opts.alignH);
      ah.classList.toggle('on', on);
      ah.style.top = on ? opts.alignH + '%' : '';
    }
    if (av) {
      const on = typeof opts.alignV === 'number' && isFinite(opts.alignV);
      av.classList.toggle('on', on);
      av.style.left = on ? opts.alignV + '%' : '';
    }
  }

  _setGuides(vOn, hOn) {
    this._updateGuides({ centerV: vOn, centerH: hOn });
  }

  _hideGuides() {
    this._updateGuides({});
  }

  _alignmentGuideFlags(box, peers) {
    const flags = { alignH: null, alignV: null };
    if (!peers.length) return flags;
    const bottom = box.y + box.h;
    const right = box.x + box.w;
    peers.forEach(p => {
      if (flags.alignH === null && Math.abs(box.h - p.h) <= SR_GUIDE_SHOW) flags.alignH = bottom;
      if (flags.alignH === null && Math.abs(bottom - p.bottom) <= SR_GUIDE_SHOW) flags.alignH = bottom;
      if (flags.alignH === null && Math.abs(box.y - p.y) <= SR_GUIDE_SHOW) flags.alignH = box.y;
      if (flags.alignV === null && Math.abs(box.w - p.w) <= SR_GUIDE_SHOW) flags.alignV = right;
      if (flags.alignV === null && Math.abs(right - p.right) <= SR_GUIDE_SHOW) flags.alignV = right;
      if (flags.alignV === null && Math.abs(box.x - p.x) <= SR_GUIDE_SHOW) flags.alignV = box.x;
    });
    return flags;
  }

  _resizeBoxWithGuides(start, dx, dy, edge, excludeId) {
    let box = this._resizeBox(start, dx, dy, edge);
    const peers = this._peerBoxes(excludeId);
    const guide = { centerV: false, centerH: false, alignH: null, alignV: null };
    const affectsH = edge.includes('n') || edge.includes('s');
    const affectsW = edge.includes('e') || edge.includes('w');

    if (affectsH && peers.length) {
      const snapH = this._nearestPeerValue(box.h, peers, p => p.h, SR_GUIDE_SNAP);
      if (snapH !== null) {
        if (edge.includes('n')) box.y = start.y + start.h - snapH;
        box.h = snapH;
        guide.alignH = box.y + box.h;
      } else if (edge.includes('s') || edge === 'se' || edge === 'sw') {
        const snapBottom = this._nearestPeerValue(box.y + box.h, peers, p => p.bottom, SR_GUIDE_SNAP);
        if (snapBottom !== null) {
          box.h = snapBottom - box.y;
          guide.alignH = snapBottom;
        }
      } else if (edge.includes('n') || edge === 'ne' || edge === 'nw') {
        const snapTop = this._nearestPeerValue(box.y, peers, p => p.y, SR_GUIDE_SNAP);
        if (snapTop !== null) {
          box.h = start.y + start.h - snapTop;
          box.y = snapTop;
          guide.alignH = snapTop;
        }
      }
    }

    if (affectsW && peers.length) {
      const snapW = this._nearestPeerValue(box.w, peers, p => p.w, SR_GUIDE_SNAP);
      if (snapW !== null) {
        if (edge.includes('w')) box.x = start.x + start.w - snapW;
        box.w = snapW;
        guide.alignV = box.x + box.w;
      } else if (edge.includes('e') || edge === 'se' || edge === 'ne') {
        const snapRight = this._nearestPeerValue(box.x + box.w, peers, p => p.right, SR_GUIDE_SNAP);
        if (snapRight !== null) {
          box.w = snapRight - box.x;
          guide.alignV = snapRight;
        }
      } else if (edge.includes('w') || edge === 'sw' || edge === 'nw') {
        const snapLeft = this._nearestPeerValue(box.x, peers, p => p.x, SR_GUIDE_SNAP);
        if (snapLeft !== null) {
          box.w = start.x + start.w - snapLeft;
          box.x = snapLeft;
          guide.alignV = snapLeft;
        }
      }
    }

    box = this.clampBox({ ...start, ...box, style: start.style });

    if (guide.alignH === null || guide.alignV === null) {
      const show = this._alignmentGuideFlags(box, peers);
      if (guide.alignH === null) guide.alignH = show.alignH;
      if (guide.alignV === null) guide.alignV = show.alignV;
    }

    const cx = box.x + box.w / 2;
    const cy = box.y + box.h / 2;
    guide.centerV = Math.abs(cx - SR_GUIDE_CENTER) <= SR_GUIDE_SHOW;
    guide.centerH = Math.abs(cy - SR_GUIDE_CENTER) <= SR_GUIDE_SHOW;
    this._updateGuides(guide);
    return box;
  }

  _applySingleMoveWithGuides(startBox, dxPct, dyPct, excludeId) {
    let x = startBox.x + dxPct;
    let y = startBox.y + dyPct;
    const peers = this._movePeers(new Set([excludeId]), excludeId);
    let { x: sx, y: sy, alignH, alignV } = this._snapMoveXY(x, y, startBox.w, startBox.h, peers);
    const box = this.clampBox({ ...startBox, x: sx, y: sy });
    const flags = this._centerGuideFlags(box.x + box.w / 2, box.y + box.h / 2);
    if (alignH === null || alignV === null) {
      const show = this._alignmentGuideFlags(box, peers);
      if (alignH === null) alignH = show.alignH;
      if (alignV === null) alignV = show.alignV;
    }
    this._updateGuides({
      centerV: flags.v,
      centerH: flags.h,
      alignH,
      alignV,
    });
    return box;
  }

  _elementId(el) {
    return el.dataset.el || el.dataset.id;
  }

  _onPointerDown(el, e) {
    if (this.state.locked) return;
    if (e.button !== undefined && e.button !== 0) return;
    const id = this._elementId(el);
    const isResize = !!e.target.closest('.ds-rs');
    const rsEl = e.target.closest('.ds-rs');
    const resizeEdge = rsEl ? (rsEl.dataset.edge || 'se') : 'se';

    if (!isResize && e.shiftKey && this._isPrayerTile(id)) {
      e.preventDefault();
      e.stopPropagation();
      if (this._selectedGroup.has(id)) this._selectedGroup.delete(id);
      else this._selectedGroup.add(id);
      this._updateGroupVisuals();
      return;
    }

    if (!isResize && this._isPrayerTile(id)) {
      const keepGroup = this._selectedGroup.size > 1 && this._selectedGroup.has(id);
      if (!keepGroup) {
        this._selectedGroup.clear();
        this._selectedGroup.add(id);
        this._updateGroupVisuals();
      }
    } else if (!isResize) {
      this._clearGroupSelection();
    }

    e.preventDefault();
    e.stopPropagation();

    const stage = this.container.querySelector('.sr-viewport');
    const startBox = { ...(this.state.overrides[id] || SR_OVERRIDE_DEFAULTS[id] || { x: 10, y: 10, w: 20, h: 15 }) };
    if (this.state.overrides[id] && this.state.overrides[id].style) {
      startBox.style = { ...this.state.overrides[id].style };
    }
    this.state.overrides[id] = { ...startBox };

    const groupStartBoxes = {};
    if (!isResize && this._selectedGroup.size > 1 && this._selectedGroup.has(id)) {
      this._selectedGroup.forEach(gId => {
        const snap = this._boxSnapshot(gId);
        if (snap) groupStartBoxes[gId] = snap;
      });
    }

    this._drag = {
      id, mode: isResize ? 'resize' : 'move',
      resizeEdge,
      startX: e.clientX, startY: e.clientY,
      startBox, stageRect: stage.getBoundingClientRect(),
      groupStartBoxes,
    };
    el.classList.add('dragging');
    if (!isResize && this._selectedGroup.size > 1 && this._selectedGroup.has(id)) {
      this._selectedGroup.forEach(gId => {
        const gEl = this._findEl(gId);
        if (gEl) gEl.classList.add('dragging');
      });
    }
  }

  _onPointerMove(e) {
    const d = this._drag;
    if (!d) return;
    const r = d.stageRect;
    const dxPct = (e.clientX - d.startX) / r.width * 100;
    const dyPct = (e.clientY - d.startY) / r.height * 100;

    if (d.mode === 'move'
        && this._selectedGroup.size > 1
        && this._selectedGroup.has(d.id)
        && d.groupStartBoxes
        && Object.keys(d.groupStartBoxes).length > 1) {
      const groupIds = Object.keys(d.groupStartBoxes);
      const peers = this._movePeers(new Set(groupIds), d.id);
      let alignH = null;
      let alignV = null;
      let { dx, dy } = this._clampGroupDelta(dxPct, dyPct, d.groupStartBoxes);
      ({ dx, dy, alignH, alignV } = this._snapGroupDeltaToPeers(d.groupStartBoxes, dx, dy, peers));
      ({ dx, dy } = this._snapDeltaToCenter(d.groupStartBoxes, dx, dy));
      ({ dx, dy } = this._clampGroupDelta(dx, dy, d.groupStartBoxes));
      const bbox = this._bboxAfterDelta(d.groupStartBoxes, dx, dy);
      const flags = this._centerGuideFlags(bbox.cx, bbox.cy);
      if (alignH === null || alignV === null) {
        const bb = this._groupBboxStart(d.groupStartBoxes);
        if (bb) {
          const ghost = {
            x: bb.minX + dx, y: bb.minY + dy,
            w: bb.maxX - bb.minX, h: bb.maxY - bb.minY,
          };
          const show = this._alignmentGuideFlags(ghost, peers);
          if (alignH === null) alignH = show.alignH;
          if (alignV === null) alignV = show.alignV;
        }
      }
      this._updateGuides({ centerV: flags.v, centerH: flags.h, alignH, alignV });
      this._selectedGroup.forEach(gId => {
        const startBox = d.groupStartBoxes[gId];
        if (!startBox) return;
        const box = this.clampBox({
          ...startBox,
          x: startBox.x + dx,
          y: startBox.y + dy,
        });
        this.state.overrides[gId] = box;
        const gEl = this._findEl(gId);
        if (gEl) this._positionElement(gEl, box, null);
      });
      return;
    }

    let box;
    if (d.mode === 'move') {
      box = this._applySingleMoveWithGuides(d.startBox, dxPct, dyPct, d.id);
    } else {
      box = this._resizeBoxWithGuides(d.startBox, dxPct, dyPct, d.resizeEdge || 'se', d.id);
    }
    this.state.overrides[d.id] = box;

    const el = this._findEl(d.id);
    if (el) this._positionElement(el, box, null);
  }

  _onPointerUp() {
    const d = this._drag;
    if (!d) return;
    this._drag = null;
    this._hideGuides();
    const el = this._findEl(d.id);
    if (el) el.classList.remove('dragging');
    if (d.groupStartBoxes) {
      Object.keys(d.groupStartBoxes).forEach(gId => {
        const gEl = this._findEl(gId);
        if (gEl) gEl.classList.remove('dragging');
      });
    }
    this.saveToServer();
  }

  _findEl(id) {
    return this.container.querySelector(`[data-el="${id}"], [data-id="${id}"]`);
  }

  clampBox(box) {
    const w = this._clampNum(box.w, 3, 100);
    const h = this._clampNum(box.h, 3, 100);
    const result = {
      x: this._clampNum(box.x, 0, 100 - w),
      y: this._clampNum(box.y, 0, 100 - h),
      w, h,
    };
    if (box.style) result.style = box.style;
    return result;
  }

  _resizeBox(start, dx, dy, edge) {
    let x = start.x;
    let y = start.y;
    let w = start.w;
    let h = start.h;
    const minW = 3;
    const minH = 3;
    if (edge.includes('e')) w += dx;
    if (edge.includes('w')) { w -= dx; x += dx; }
    if (edge.includes('s')) h += dy;
    if (edge.includes('n')) { h -= dy; y += dy; }
    if (w < minW) {
      if (edge.includes('w')) x -= (minW - w);
      w = minW;
    }
    if (h < minH) {
      if (edge.includes('n')) y -= (minH - h);
      h = minH;
    }
    return this.clampBox({ ...start, x, y, w, h });
  }

  _clampNum(v, lo, hi) {
    return Math.max(lo, Math.min(hi, (typeof v === 'number' && isFinite(v)) ? v : lo));
  }

  // ═══════════════════════════════════════════════════════════
  // 5. INTERAKTION: STYLE-MODAL (Anforderung 6)
  // ═══════════════════════════════════════════════════════════

  _onDblClick(el, e) {
    if (this.state.locked) return;
    e.preventDefault();
    let initialPart = null;
    if (el.classList.contains('ds-info')) {
      initialPart = this._resolveInfoPartFromEvent(el, e);
    } else if (el.classList.contains('ds-tile')) {
      initialPart = this._resolveTilePartFromEvent(el, e);
    }
    this.openStyleEditor(el, initialPart);
  }

  /* Doppelklick auf Gebets-Kachel-Teil → passende Akkordeon-Ebene; Kachel-Rand → „Kachel“. */
  _resolveTilePartFromEvent(tileEl, e) {
    const partEl = e.target.closest('[data-part]');
    if (!partEl || !tileEl.contains(partEl)) return 'box';
    const part = partEl.dataset.part;
    const isFajr = tileEl.dataset.el === 'tile_fajr';
    const valid = new Set(['icon', 'nameDe', 'nameAr', 'time', 'countdown', 'box']);
    if (isFajr) valid.add('fajrSub');
    return valid.has(part) ? part : 'box';
  }

  /* Doppelklick auf Hadith-Textteil → passende Akkordeon-Ebene; Kachel-Rand → „Kachel“. */
  _resolveInfoPartFromEvent(infoEl, e) {
    const partEl = e.target.closest('[data-part]');
    if (!partEl || !infoEl.contains(partEl)) return 'box';
    let part = partEl.dataset.part;
    if (part === 'divider') part = 'title';
    const info = this.state.info || {};
    const hasContent = SR_INFO_SECTIONS.some(
      sec => sec.part === part && String(info[sec.field] || '').trim()
    );
    return hasContent ? part : 'box';
  }

  openStyleEditor(element, initialPart) {
    const id = this._elementId(element);
    if (!id) return;
    if (element.classList.contains('ds-info') && !this.hasInfoContent(this.state.info)) return;
    this.closeStyleEditor();

    if (element.classList.contains('ds-info')) {
      this._openInfoStyleEditor(element, initialPart);
      return;
    }

    if (element.classList.contains('ds-clock')) {
      this._openClockStyleEditor(element);
      return;
    }

    if (element.classList.contains('ds-tile')) {
      this._openTileStyleEditor(element, initialPart);
    }
  }

  /* Stil-Editor für die Hauptuhr (Doppelklick auf .ds-clock). */
  _openClockStyleEditor(element) {
    const id = 'clock';
    const box = this.state.overrides[id] || {};
    const style = { ...SR_CLOCK_STYLE_DEFAULTS, ...(box.style || {}) };

    const leftHTML =
      '<div class="te-title">Hauptuhr</div>' +
      this._teGroup('Stunden / Minuten', [
        this._teSlider('clockFontSize', 'Größe', style.clockFontSize, 80, 220, 'px'),
        this._teFontSelect('clockFontFamily', 'Schriftart', style.clockFontFamily, 'display'),
        this._teColor('clockColor', 'Farbe', style.clockColor),
      ]) +
      this._teGroup('Sekunden', [
        this._teSlider('secsFontSize', 'Größe', style.secsFontSize, 36, 120, 'px'),
        this._teColor('secsColor', 'Farbe', style.secsColor),
      ]) +
      '<div class="te-btn-row">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';

    const previewHTML =
      '<div class="te-clock-preview" id="srClockPreview">' +
        '<div class="ds-time-big">' +
          '<span class="ds-hm">12:45</span><span class="ds-secs">:00</span>' +
        '</div>' +
      '</div>';

    const overlay = document.createElement('div');
    overlay.className = 'te-overlay';
    overlay.innerHTML =
      '<div class="te-backdrop"></div>' +
      '<div class="te-glass te-glass-compact">' +
        '<div class="te-left te-clock-left">' + leftHTML + '</div>' +
        '<div class="te-right"><div class="te-canvas">' + previewHTML + '</div>' +
          '<div class="te-hint">Regler links · Vorschau entspricht der TV-Hauptuhr</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    this._modalEl = overlay;
    this._modalElementId = id;
    this._wireClockStyleModal(overlay, id);
    this._syncClockPreviewStyles(overlay, style);
  }

  _syncClockPreviewStyles(overlay, style) {
    const preview = overlay.querySelector('#srClockPreview');
    if (!preview) return;
    const s = { ...SR_CLOCK_STYLE_DEFAULTS, ...style };
    const big = preview.querySelector('.ds-time-big');
    const secs = preview.querySelector('.ds-secs');
    if (big) {
      big.style.fontSize = s.clockFontSize + 'px';
      big.style.color = s.clockColor;
      window.KIOSK_applyFontFamily(big, s.clockFontFamily, 'display');
    }
    if (secs) {
      secs.style.fontSize = s.secsFontSize + 'px';
      secs.style.color = s.secsColor;
      window.KIOSK_applyFontFamily(secs, s.clockFontFamily, 'display');
    }
  }

  _wireClockStyleModal(overlay, id) {
    const close = () => this.closeStyleEditor();
    overlay.querySelectorAll('input[type="range"], input[type="color"]').forEach(inp => {
      inp.addEventListener('input', () => {
        const prop = inp.dataset.prop;
        const val = inp.type === 'color' ? inp.value : parseInt(inp.value, 10);
        const row = inp.closest('.te-row');
        const valText = row && row.querySelector('.te-val');
        if (valText) valText.textContent = val + (inp.type === 'color' ? '' : 'px TV');
        this.updateElementStyle(id, prop, val);
        this._syncClockPreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });
    overlay.querySelectorAll('select.te-font-select[data-prop]').forEach(sel => {
      sel.addEventListener('change', () => {
        this.updateElementStyle(id, sel.dataset.prop, sel.value);
        this._syncClockPreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });
    overlay.querySelector('[data-action="reset"]').addEventListener('click', () => {
      this._resetElementStyle(id);
      this.applyAllStyles();
      close();
      this.saveToServer();
    });
    overlay.querySelector('[data-action="apply"]').addEventListener('click', () => { close(); this.saveToServer(); });
    overlay.querySelector('.te-backdrop').addEventListener('click', close);
    overlay._esc = e => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', overlay._esc);
  }

  /* v1.10: Akkordeon-Overlay für Gebets-Kacheln — Klick auf Vorschau-Teil
     wechselt die Regler links; Hover hebt den Teil hervor (wie Hadith-Kachel). */
  _openTileStyleEditor(element, initialPart) {
    const id = this._elementId(element);
    if (!id) return;
    const isFajr = id === 'tile_fajr';
    const isDhuhr = id === 'tile_dhuhr';
    const box = this.state.overrides[id] || {};
    const style = { ...SR_TILE_STYLE_DEFAULTS, ...(box.style || {}) };
    const key = id.replace('tile_', '');
    const idx = SR_KEYS.indexOf(key);
    const label = key.replace(/^./, c => c.toUpperCase());
    const names = isDhuhr
      ? this._prayerTileNames(key, idx, style, new Date(), true)
      : this._prayerTileNames(key, idx, style, new Date());
    const nameDe = names.nameDe;
    const nameAr = names.nameAr;
    const tt = this._tileTimes(key);
    const time = tt.main;
    const icon = SR_ICONS[key] || '';
    const now = new Date();
    const today = this.state.prayersToday || SR_demoPrayerRow();
    const np = SR_computeNextPrayer(now, today, this.state.prayersTomorrow, this.state.fokus);
    const isNextPrayer = key === np.key;
    const cdPreview = '<div class="ds-tile-countdown countdown-inset" data-part="countdown"></div>';

    const validParts = new Set(['icon', 'nameDe', 'nameAr', 'time', 'countdown', 'box']);
    if (isFajr) validParts.add('fajrSub');
    if (isDhuhr) validParts.add('jumuah');

    const iconPanel =
      '<div class="te-tile-panel" data-part="icon">' +
        '<div class="te-title">Symbol</div>' +
        this._teGroup('Symbol', [this._teSlider('iconScale', 'Größe', style.iconScale, 50, 250, '%')]) +
      '</div>';

    const nameDePanel =
      '<div class="te-tile-panel" data-part="nameDe">' +
        '<div class="te-title">Name (DE)</div>' +
        this._teGroup('Name (DE)', [
          this._teSlider('nameFontSize', 'Größe', style.nameFontSize, 4, 60, 'px'),
          this._teFontSelect('nameFontFamily', 'Schriftart', style.nameFontFamily, 'latin'),
          this._teColor('nameColor', 'Farbe', style.nameColor),
        ]) +
      '</div>';

    const nameArPanel =
      '<div class="te-tile-panel" data-part="nameAr">' +
        '<div class="te-title">Name (AR)</div>' +
        this._teGroup('Name (AR)', [
          this._teSlider('arFontSize', 'Größe', style.arFontSize, 6, 60, 'px'),
          this._teFontSelect('arFontFamily', 'Schriftart', style.arFontFamily, 'arabic'),
          this._teColor('arColor', 'Farbe', style.arColor),
        ]) +
      '</div>';

    const timePanel =
      '<div class="te-tile-panel" data-part="time">' +
        '<div class="te-title">Uhrzeit</div>' +
        this._teGroup('Uhrzeit', [
          this._teSlider('timeFontSize', 'Größe', style.timeFontSize, 8, 130, 'px'),
          this._teFontSelect('timeFontFamily', 'Schriftart', style.timeFontFamily, 'latin'),
          this._teColor('timeColor', 'Farbe', style.timeColor),
        ]) +
      '</div>';

    const countdownPanel =
      '<div class="te-tile-panel" data-part="countdown">' +
        '<div class="te-title">Countdown</div>' +
        this._teGroup('Countdown (aktive Kachel)', [
          this._teSlider('countdownFontSize', 'Größe', style.countdownFontSize, 16, 90, 'px'),
          this._teFontSelect('countdownFontFamily', 'Schriftart', style.countdownFontFamily, 'latin'),
          this._teColor('countdownColor', 'Farbe', style.countdownColor || '#ffd966'),
        ]) +
      '</div>';

    const fajrLb = this._fajrLabelTexts(style);
    const fajrLabelsOn = this._fajrLabelsVisible(style);

    const fajrPanel = isFajr
      ? '<div class="te-tile-panel" data-part="fajrSub">' +
          '<div class="te-title">Fajr Beginn / Aufgang</div>' +
          this._teToggle('fajrLabelsVisible', 'Beschriftungen anzeigen (Beginn / Aufgang)', fajrLabelsOn) +
          this._teGroup('Beschriftung', [
            this._teText('fajrBeginnLabel', 'Text links (Beginn)', style.fajrBeginnLabel || 'Beginn'),
            this._teText('fajrAufgangLabel', 'Text rechts (Aufgang)', style.fajrAufgangLabel || 'Aufgang'),
            this._teSlider('fajrLabelSize', 'Text-Größe', style.fajrLabelSize, 4, 30, 'px'),
            this._teFontSelect('fajrLabelFontFamily', 'Schriftart', style.fajrLabelFontFamily, 'latin'),
            this._teColor('fajrLabelColor', 'Text-Farbe', style.fajrLabelColor),
          ]) +
          this._teGroup('Uhrzeiten', [
            this._teSlider('fajrTimeSize', 'Zeit-Größe', style.fajrTimeSize, 6, 70, 'px'),
            this._teFontSelect('fajrTimeFontFamily', 'Schriftart', style.fajrTimeFontFamily, 'latin'),
            this._teColor('fajrTimeColor', 'Zeit-Farbe', style.fajrTimeColor),
          ]) +
        '</div>'
      : '';

    const jumuahPanel = isDhuhr
      ? '<div class="te-tile-panel" data-part="jumuah">' +
          '<div class="te-title">Freitag (Jumu\u02bfah)</div>' +
          '<p class="te-hint" style="margin:0 0 10px;line-height:1.35">An Freitagen ersetzt diese Kachel das Mittagsgebet. Schriftgr\u00f6\u00dfe/Farbe wie bei Name (DE/AR).</p>' +
          this._teGroup('Namen am Freitag', [
            this._teText('jumuahNameDe', 'Deutsch', style.jumuahNameDe || SR_JUMUAH_DEFAULTS.de),
            this._teText('jumuahNameAl', 'Albanisch', style.jumuahNameAl || SR_JUMUAH_DEFAULTS.al),
            this._teText('jumuahNameEn', 'Englisch', style.jumuahNameEn || SR_JUMUAH_DEFAULTS.en),
            this._teText('jumuahNameAr', 'Arabisch', style.jumuahNameAr || SR_JUMUAH_DEFAULTS.arLine),
          ]) +
        '</div>'
      : '';

    const boxPanel =
      '<div class="te-tile-panel" data-part="box">' +
        '<div class="te-title">Kachel</div>' +
        this._teGroup('Hintergrund', [
          this._teSlider('bgOpacity', 'Deckkraft', style.bgOpacity, 0, 100, '%'),
        ]) +
      '</div>';

    const leftHTML = boxPanel + iconPanel + nameDePanel + nameArPanel + timePanel + countdownPanel + fajrPanel + jumuahPanel +
      '<div class="te-btn-row te-btn-row-3">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn te-sync" data-action="sync">⟳ Sync</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';

    const fajrSubHTML = isFajr
      ? '<div class="te-tile-part te-fajr-sub-wrap" data-part="fajrSub">' +
          '<div class="te-fajr-sub-inner">' +
            '<div class="te-fajr-sub-cell te-fajr-sub-begin">' +
              '<span class="te-fsub-time">' + this.escape(tt.sub.beginn) + '</span>' +
              '<span class="te-fsub-label">' + this.escape(fajrLb.beginn) + '</span></div>' +
            '<div class="te-fajr-sub-cell te-fajr-sub-rise">' +
              '<span class="te-fsub-time">' + this.escape(tt.sub.aufgang) + '</span>' +
              '<span class="te-fsub-label">' + this.escape(fajrLb.aufgang) + '</span></div>' +
          '</div></div>'
      : '';

    const previewHTML =
      '<div class="te-tile-preview' + (isNextPrayer ? ' demo-active' : '') + '" id="srPreview">' +
        '<div class="te-tile-part" data-part="icon"><div class="te-icon-inner">' + icon + '</div></div>' +
        '<div class="te-tile-part" data-part="nameDe"><div class="te-name-de-txt">' + this.escape(nameDe) + '</div></div>' +
        '<div class="te-tile-part" data-part="nameAr"><div class="te-name-ar-txt">' + nameAr + '</div></div>' +
        '<div class="te-tile-part" data-part="time"><div class="te-ptime-txt">' + this.escape(time) + '</div></div>' +
        '<div class="te-tile-part" data-part="countdown">' + cdPreview + '</div>' +
        fajrSubHTML +
      '</div>';

    const overlay = document.createElement('div');
    overlay.className = 'te-overlay';
    overlay.innerHTML =
      '<div class="te-backdrop"></div>' +
      '<div class="te-glass">' +
        '<div class="te-left te-tile-left">' + leftHTML + '</div>' +
        '<div class="te-right"><div class="te-canvas">' + previewHTML + '</div>' +
          '<div class="te-hint">Teil anklicken · Kachel-Rand für Hintergrund · Regler links</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    this._modalEl = overlay;
    this._modalElementId = id;
    this._tileActivePart = (initialPart && validParts.has(initialPart))
      ? initialPart
      : 'box';

    this._wireTileStyleModal(overlay, id, isFajr);
    this._showTilePanel(overlay, this._tileActivePart);
    this._syncTilePreviewStyles(overlay, style);
  }

  _showTilePanel(overlay, part) {
    this._tileActivePart = part;
    overlay.querySelectorAll('.te-tile-panel').forEach(p => {
      p.classList.toggle('is-active', p.dataset.part === part);
    });
    overlay.querySelectorAll('.te-tile-part[data-part]').forEach(p => {
      p.classList.toggle('active', p.dataset.part === part);
    });
    const preview = overlay.querySelector('#srPreview');
    if (preview) preview.classList.toggle('active', part === 'box');
  }

  _syncTilePreviewStyles(overlay, style) {
    const preview = overlay.querySelector('#srPreview');
    if (!preview) return;
    const s = { ...SR_TILE_STYLE_DEFAULTS, ...style };

    const iconInner = preview.querySelector('[data-part="icon"] .te-icon-inner');
    if (iconInner) {
      const isc = (typeof s.iconScale === 'number') ? s.iconScale : SR_TILE_STYLE_DEFAULTS.iconScale;
      const dim = Math.round(SR_ICON_BASE_PX * isc / 100) + 'px';
      iconInner.style.transform = '';
      const svg = iconInner.querySelector('svg');
      if (svg) { svg.style.width = dim; svg.style.height = dim; }
    }

    const nameDe = preview.querySelector('[data-part="nameDe"] .te-name-de-txt');
    if (nameDe) {
      nameDe.style.fontSize = s.nameFontSize + 'px';
      nameDe.style.color = s.nameColor;
      window.KIOSK_applyFontFamily(nameDe, s.nameFontFamily, 'latin');
      if (this._modalElementId === 'tile_dhuhr') {
        nameDe.textContent = this._jumuahLabelTexts(s).nameDe;
      }
    }

    const nameAr = preview.querySelector('[data-part="nameAr"] .te-name-ar-txt');
    if (nameAr) {
      nameAr.style.fontSize = s.arFontSize + 'px';
      nameAr.style.color = s.arColor;
      window.KIOSK_applyFontFamily(nameAr, s.arFontFamily, 'arabic');
      if (this._modalElementId === 'tile_dhuhr') {
        nameAr.textContent = this._jumuahLabelTexts(s).nameAr;
      }
    }

    const ptime = preview.querySelector('[data-part="time"] .te-ptime-txt');
    if (ptime) {
      ptime.style.fontSize = s.timeFontSize + 'px';
      ptime.style.color = s.timeColor;
      window.KIOSK_applyFontFamily(ptime, s.timeFontFamily, 'latin');
    }

    const cd = preview.querySelector('[data-part="countdown"]');
    if (cd) {
      cd.textContent = '00:12:34';
      cd.style.fontSize = s.countdownFontSize + 'px';
      cd.style.minHeight = Math.round(s.countdownFontSize * 1.25) + 'px';
      if (s.countdownColor) cd.style.color = s.countdownColor;
      window.KIOSK_applyFontFamily(cd, s.countdownFontFamily, 'latin');
    }

    preview.querySelectorAll('[data-part="fajrSub"] .te-fsub-label').forEach(lb => {
      lb.style.fontSize = s.fajrLabelSize + 'px';
      lb.style.color = s.fajrLabelColor;
      lb.style.display = this._fajrLabelsVisible(s) ? '' : 'none';
      window.KIOSK_applyFontFamily(lb, s.fajrLabelFontFamily, 'latin');
    });
    const lbL = preview.querySelector('.te-fajr-sub-begin .te-fsub-label');
    const lbR = preview.querySelector('.te-fajr-sub-rise .te-fsub-label');
    if (lbL) lbL.textContent = String(s.fajrBeginnLabel || '').trim() || 'Beginn';
    if (lbR) lbR.textContent = String(s.fajrAufgangLabel || '').trim() || 'Aufgang';
    preview.querySelectorAll('[data-part="fajrSub"] .te-fsub-time').forEach(tm => {
      tm.style.fontSize = s.fajrTimeSize + 'px';
      tm.style.color = s.fajrTimeColor;
      window.KIOSK_applyFontFamily(tm, s.fajrTimeFontFamily, 'latin');
    });

    preview.style.backgroundColor = 'rgba(13,20,38,' + (s.bgOpacity / 100).toFixed(2) + ')';
  }

  /* v1.10: Akkordeon-Overlay für die Hadith-Kachel — Klick auf Vorschau-Teil
     wechselt die Regler links; Hover hebt den Teil hervor. */
  _openInfoStyleEditor(element, initialPart) {
    if (!this.hasInfoContent(this.state.info)) return;
    const id = 'info';
    const box = this.state.overrides[id] || {};
    const style = { ...SR_INFO_STYLE_DEFAULTS, ...(box.style || {}) };
    const info = this.state.info || {};
    const visibleSections = SR_INFO_SECTIONS.filter(sec => String(info[sec.field] || '').trim());
    const validParts = new Set(visibleSections.map(sec => sec.part));
    validParts.add('box');

    const buildPanel = (sec) => {
      const fs = typeof style[sec.fontField] === 'number' ? style[sec.fontField] : sec.defaultSize;
      const col = style[sec.colorField] || sec.defaultColor;
      const weightOn = sec.weightField ? (style[sec.weightField] || 'bold') === 'bold' : false;
      return '<div class="te-info-panel" data-part="' + sec.part + '">' +
        '<div class="te-title">' + this.escape(sec.label) + '</div>' +
        this._teGroup('Schrift', [
          this._teSlider(sec.fontField, 'Größe', fs, sec.min, sec.max, 'px'),
          this._teFontSelect(sec.fontFamilyField, 'Schriftart',
            style[sec.fontFamilyField], sec.fontCategory || 'latin'),
          this._teColor(sec.colorField, 'Farbe', col),
        ] + (sec.weightField ? this._teToggle(sec.weightField, 'Fett', weightOn) : '')) +
      '</div>';
    };

    const boxPanel =
      '<div class="te-info-panel" data-part="box">' +
        '<div class="te-title">Kachel</div>' +
        this._teGroup('Hintergrund', [
          this._teSlider('bgOpacity', 'Deckkraft', style.bgOpacity, 0, 100, '%'),
        ]) +
      '</div>';

    const leftHTML = boxPanel + visibleSections.map(buildPanel).join('') +
      '<div class="te-btn-row">' +
        '<button class="btn te-rst" data-action="reset">↺ Standard</button>' +
        '<button class="btn gold te-ok" data-action="apply">✓ Übernehmen</button>' +
      '</div>';

    const previewParts = visibleSections.map(sec => {
      const val = String(info[sec.field] || '').trim();
      const rtl = sec.rtl ? ' dir="rtl"' : '';
      const cls = 'te-info-part te-info-' + sec.part;
      let extra = '';
      if (sec.part === 'text') extra = ' te-info-quote';
      if (sec.part === 'title') return '<div class="' + cls + '" data-part="' + sec.part + '"' + rtl + '>' + this.escape(val) + '</div>' +
        '<div class="te-info-divider" data-part="divider"></div>';
      return '<div class="' + cls + extra + '" data-part="' + sec.part + '"' + rtl + '>' + this.escape(val) + '</div>';
    }).join('');

    const previewHTML =
      '<div class="te-info-preview" id="srInfoPreview">' +
        previewParts +
      '</div>';

    const overlay = document.createElement('div');
    overlay.className = 'te-overlay';
    overlay.innerHTML =
      '<div class="te-backdrop"></div>' +
      '<div class="te-glass">' +
        '<div class="te-left te-info-left">' + leftHTML + '</div>' +
        '<div class="te-right"><div class="te-canvas">' + previewHTML + '</div>' +
          '<div class="te-hint">Textteil anklicken · Kachel-Rand für Hintergrund · Regler links</div>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    this._modalEl = overlay;
    this._modalElementId = id;
    this._infoActivePart = (initialPart && validParts.has(initialPart))
      ? initialPart
      : 'box';

    this._wireInfoStyleModal(overlay, id, visibleSections);
    this._showInfoPanel(overlay, this._infoActivePart);
    this._syncInfoPreviewStyles(overlay, style);
  }

  _showInfoPanel(overlay, part) {
    this._infoActivePart = part;
    overlay.querySelectorAll('.te-info-panel').forEach(p => {
      p.classList.toggle('is-active', p.dataset.part === part);
    });
    overlay.querySelectorAll('.te-info-part[data-part]').forEach(p => {
      p.classList.toggle('active', p.dataset.part === part);
    });
    const preview = overlay.querySelector('#srInfoPreview');
    if (preview) preview.classList.toggle('active', part === 'box');
  }

  _syncInfoPreviewStyles(overlay, style) {
    const preview = overlay.querySelector('#srInfoPreview');
    if (!preview) return;
    SR_INFO_SECTIONS.forEach(sec => {
      const el = preview.querySelector('[data-part="' + sec.part + '"]');
      if (!el) return;
      const fs = typeof style[sec.fontField] === 'number' ? style[sec.fontField] : sec.defaultSize;
      el.style.fontSize = fs + 'px';
      el.style.color = style[sec.colorField] || sec.defaultColor;
      if (sec.weightField) el.style.fontWeight = style[sec.weightField] || 'bold';
      if (sec.fontFamilyField) {
        window.KIOSK_applyFontFamily(el, style[sec.fontFamilyField], sec.fontCategory || 'latin');
      }
    });
    preview.style.backgroundColor = 'rgba(13,20,38,' + ((style.bgOpacity || SR_INFO_STYLE_DEFAULTS.bgOpacity) / 100).toFixed(2) + ')';
  }

  _wireInfoStyleModal(overlay, id, visibleSections) {
    const close = () => this.closeStyleEditor();

    overlay.querySelectorAll('.te-info-part[data-part]').forEach(partEl => {
      partEl.addEventListener('click', e => {
        e.stopPropagation();
        this._showInfoPanel(overlay, partEl.dataset.part);
      });
    });

    const preview = overlay.querySelector('#srInfoPreview');
    if (preview) {
      preview.addEventListener('click', e => {
        if (e.target.closest('.te-info-part')) return;
        this._showInfoPanel(overlay, 'box');
      });
    }

    overlay.querySelectorAll('input[type="range"], input[type="color"]').forEach(inp => {
      inp.addEventListener('input', () => {
        const prop = inp.dataset.prop;
        const val = inp.type === 'color' ? inp.value : parseInt(inp.value, 10);
        const row = inp.closest('.te-row');
        const valText = row && row.querySelector('.te-val');
        if (valText) {
          valText.textContent = val + (inp.type === 'color' ? '' : (prop === 'bgOpacity' ? '%' : 'px'));
        }
        this.updateElementStyle(id, prop, val);
        this._syncInfoPreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    overlay.querySelectorAll('select.te-font-select[data-prop]').forEach(sel => {
      sel.addEventListener('change', () => {
        this.updateElementStyle(id, sel.dataset.prop, sel.value);
        this._syncInfoPreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    overlay.querySelectorAll('[data-toggle]').forEach(tg => {
      tg.addEventListener('click', () => {
        const prop = tg.dataset.toggle;
        const isOn = !tg.classList.contains('on');
        tg.classList.toggle('on', isOn);
        this.updateElementStyle(id, prop, isOn ? 'bold' : 'normal');
        this._syncInfoPreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    overlay.querySelector('[data-action="reset"]').addEventListener('click', () => {
      this._resetElementStyle(id);
      this.applyAllStyles();
      close();
      this.saveToServer();
    });

    overlay.querySelector('[data-action="apply"]').addEventListener('click', () => {
      close();
      this.saveToServer();
    });

    overlay.querySelector('.te-backdrop').addEventListener('click', close);
    overlay._esc = e => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', overlay._esc);
  }

  _wireTileStyleModal(overlay, id, isFajr) {
    const close = () => this.closeStyleEditor();

    overlay.querySelectorAll('.te-tile-part[data-part]').forEach(partEl => {
      partEl.addEventListener('click', e => {
        e.stopPropagation();
        this._showTilePanel(overlay, partEl.dataset.part);
      });
    });

    const preview = overlay.querySelector('#srPreview');
    if (preview) {
      preview.addEventListener('click', e => {
        if (e.target.closest('.te-tile-part')) return;
        this._showTilePanel(overlay, 'box');
      });
    }

    overlay.querySelectorAll('input[type="range"], input[type="color"]').forEach(inp => {
      const handler = () => {
        const prop = inp.dataset.prop;
        const val = inp.type === 'color' ? inp.value : parseInt(inp.value, 10);
        const valText = overlay.querySelector('input[data-prop="' + prop + '"]')
          .closest('.te-row').querySelector('.te-val');
        if (valText) valText.textContent = val + (inp.type === 'color' ? '' : (prop.toLowerCase().includes('opacity') || prop === 'iconScale' ? '%' : 'px'));
        this._setTileStyleField(id, prop, val);
        this._syncTilePreviewStyles(overlay, this._ensureOverrideStyle(id));
      };
      inp.addEventListener('input', handler);
    });

    overlay.querySelectorAll('input.te-text-inp[data-prop]').forEach(inp => {
      inp.addEventListener('input', () => {
        this._setTileStyleField(id, inp.dataset.prop, inp.value);
        this._syncTilePreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    overlay.querySelectorAll('select.te-font-select[data-prop]').forEach(sel => {
      sel.addEventListener('change', () => {
        this._setTileStyleField(id, sel.dataset.prop, sel.value);
        this._syncTilePreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    overlay.querySelectorAll('[data-toggle]').forEach(tg => {
      tg.addEventListener('click', () => {
        const prop = tg.dataset.toggle;
        const isOn = !tg.classList.contains('on');
        tg.classList.toggle('on', isOn);
        this._setTileStyleField(id, prop, isOn ? 1 : 0);
        this._syncTilePreviewStyles(overlay, this._ensureOverrideStyle(id));
      });
    });

    const resetBtn = overlay.querySelector('[data-action="reset"]');
    if (resetBtn) resetBtn.addEventListener('click', () => {
      this._resetElementStyle(id);
      this.applyAllStyles();
      close();
      this.saveToServer();
    });

    const applyBtn = overlay.querySelector('[data-action="apply"]');
    if (applyBtn) applyBtn.addEventListener('click', () => { close(); this.saveToServer(); });

    const syncBtn = overlay.querySelector('[data-action="sync"]');
    if (syncBtn) syncBtn.addEventListener('click', () => {
      this._syncTileStyleToAll(id);
      syncBtn.textContent = '✓ Synchronisiert';
      syncBtn.classList.add('te-sync-done');
      setTimeout(() => { syncBtn.textContent = '⟳ Sync'; syncBtn.classList.remove('te-sync-done'); }, 1200);
    });

    overlay.querySelector('.te-backdrop').addEventListener('click', close);
    overlay._esc = e => { if (e.key === 'Escape') close(); };
    window.addEventListener('keydown', overlay._esc);
  }

  _teGroup(title, rowsHTML) {
    const rows = Array.isArray(rowsHTML) ? rowsHTML.join('') : rowsHTML;
    return '<div class="te-grp"><span class="te-grp-label">' + this.escape(title) + '</span>' + rows + '</div>';
  }
  _teSlider(prop, label, val, min, max, unit) {
    return '<div class="te-row"><label>' + this.escape(label) + '</label>' +
      '<input type="range" data-prop="' + prop + '" min="' + min + '" max="' + max + '" value="' + val + '">' +
      '<span class="te-val">' + val + unit + (unit === 'px' ? ' TV' : '') + '</span></div>';
  }
  _teColor(prop, label, val) {
    return '<div class="te-row"><label>' + this.escape(label) + '</label>' +
      '<input type="color" data-prop="' + prop + '" value="' + (val || '#ffffff') + '"></div>';
  }
  _teText(prop, label, val) {
    return '<div class="te-row te-row-text"><label>' + this.escape(label) + '</label>' +
      '<input type="text" class="te-text-inp" data-prop="' + prop + '" value="' +
      this.escape(val || '') + '" maxlength="24"></div>';
  }
  _teToggle(prop, label, isOn) {
    return '<div class="te-toggle-row"><label>' + this.escape(label) + '</label>' +
      '<div class="te-toggle' + (isOn ? ' on' : '') + '" data-toggle="' + prop + '"></div></div>';
  }
  _teFontSelect(prop, label, val, category) {
    const fonts = category === 'arabic'
      ? (_KBD.arabicFonts || {})
      : category === 'display'
        ? (_KBD.displayFonts || _KBD.latinFonts || {})
        : (_KBD.latinFonts || {});
    const current = val || 'default';
    let opts = '';
    Object.keys(fonts).forEach(key => {
      const f = fonts[key];
      if (!f) return;
      opts += '<option value="' + key + '"' + (key === current ? ' selected' : '') +
        ' style="font-family:' + f.stack + '">' + this.escape(f.label) + '</option>';
    });
    return '<div class="te-row te-row-font"><label>' + this.escape(label) + '</label>' +
      '<select class="te-font-select" data-prop="' + prop + '">' + opts + '</select></div>';
  }

  _resetElementStyle(id) {
    const baseEl = SR_baseOverrideElement(id);
    if (!baseEl) {
      if (this.state.overrides[id]) delete this.state.overrides[id].style;
      return;
    }
    this.state.overrides[id] = { ...baseEl, style: { ...baseEl.style } };
  }

  closeStyleEditor() {
    if (!this._modalEl) return;
    if (this._modalEl._esc) window.removeEventListener('keydown', this._modalEl._esc);
    this._modalEl.remove();
    this._modalEl = null;
    this._modalElementId = null;
    this._infoActivePart = null;
    this._tileActivePart = null;
  }

  _ensureOverrideStyle(id) {
    if (!this.state.overrides[id]) this.state.overrides[id] = { ...SR_OVERRIDE_DEFAULTS[id] };
    if (!this.state.overrides[id].style) this.state.overrides[id].style = {};
    return this.state.overrides[id].style;
  }

  updateElementStyle(elementId, styleKey, value) {
    const style = this._ensureOverrideStyle(elementId);
    style[styleKey] = value;
    const el = this._findEl(elementId);
    if (!el) return;
    if (el.classList.contains('ds-info')) {
      this._applyInfoStyle(el, style);
    } else if (el.classList.contains('ds-clock')) {
      this._applyClockStyle(el, style);
    } else {
      this._applyTileStyle(el, style);
    }
  }

  _setTileStyleField(id, prop, value) {
    this.updateElementStyle(id, prop, value);
    this._updateTilePreview(id);
    if (prop === 'fajrLabelsVisible') this._applyFajrLabelsLayout();
    if (this._fitPrayerTileHeights()) {
      SR_PRAYER_TILE_IDS.forEach(tid => {
        const el = this.container.querySelector('[data-el="' + tid + '"]');
        if (el) this._positionElement(el, this.state.overrides[tid], SR_OVERRIDE_DEFAULTS[tid]);
      });
      this.saveToServer();
    }
  }

  _updateTilePreview(id) {
    if (!this._modalEl) return;
    const preview = this._modalEl.querySelector('#srPreview');
    if (!preview) return;
    const style = this._ensureOverrideStyle(id);
    this._syncTilePreviewStyles(this._modalEl, { ...SR_TILE_STYLE_DEFAULTS, ...style });
  }

  /* "Sync"-Knopf: überträgt den Stil der aktuellen Kachel auf alle anderen
     Gebets-Kacheln (Fajr-exklusive Felder bleiben unberührt) — 1:1-Verhalten
     wie die bisherige main.js-Funktion, jetzt Teil der Klasse. */
  _syncTileStyleToAll(sourceId) {
    const src = { ...this._ensureOverrideStyle(sourceId) };
    SR_FAJR_ONLY_PROPS.forEach(p => delete src[p]);
    SR_KEYS.forEach(key => {
      const targetId = 'tile_' + key;
      if (targetId === sourceId) return;
      const tgt = this._ensureOverrideStyle(targetId);
      Object.keys(src).forEach(k => {
        if (targetId === 'tile_fajr' && SR_FAJR_ONLY_PROPS.includes(k)) return;
        tgt[k] = src[k];
      });
    });
    this.applyAllStyles();
    this.saveToServer();
  }

  // ═══════════════════════════════════════════════════════════
  // 7. SPEICHERN & SERVER-SYNC
  // ═══════════════════════════════════════════════════════════

  /* Debounced async Speichern — wird nach Drag-Ende / Slider-Input (debounced
     über _scheduleSave) aufgerufen, NIE bei jedem Pixel (Performance-Hinweis
     aus dem Pitch). */
  async saveToServer() {
    clearTimeout(this._saveTimer);
    return new Promise(resolve => {
      this._saveTimer = setTimeout(async () => {
        try {
          const payload = { enabled: true, elements: this._ensureCompleteOverrides(this.state.overrides) };
          const result = await pywebview.api.set_override_layout(payload);
          if (this.onOverrideChange) this.onOverrideChange(result);
          resolve(result);
        } catch (e) {
          console.error('StudioRenderer: Speichern fehlgeschlagen', e);
          if (this.onOverrideChange) this.onOverrideChange({ ok: false, error: String(e) });
          resolve({ ok: false, error: String(e) });
        }
      }, 120);
    });
  }

  // ═══════════════════════════════════════════════════════════
  // 8. UTILITIES
  // ═══════════════════════════════════════════════════════════

  escape(text) {
    const div = document.createElement('div');
    div.textContent = text == null ? '' : String(text);
    return div.innerHTML;
  }

  hasInfoContent(info) {
    return !!(info && (
      String(info.titel || '').trim() ||
      String(info.text || '').trim() ||
      String(info.arabisch || '').trim() ||
      String(info.quelle || '').trim()
    ));
  }

  resetLayout() {
    if (!this._sessionSnapshot) return false;
    const s = this._sessionSnapshot;
    this.state.overrides = JSON.parse(JSON.stringify(s.overrides));
    this.state.design = { ...s.design };
    this.state.background = s.background;
    this._clearGroupSelection();
    this.closeStyleEditor();
    this.render();
    return true;
  }

  /* Referenz für ⟲: Editor-Stand beim Öffnen des Design-Studios merken. */
  captureSessionSnapshot() {
    this._sessionSnapshot = {
      overrides: JSON.parse(JSON.stringify(
        this._ensureCompleteOverrides(this.state.overrides)
      )),
      design: { ...this.state.design },
      background: this.state.background,
    };
  }

  /* Gebetskacheln: nur horizontalen Zwischenabstand korrigieren — y bleibt immer. */
  restorePrayerTileSpacing() {
    const ids = SR_PRAYER_TILE_IDS;
    const defFajr = SR_OVERRIDE_DEFAULTS.tile_fajr;
    const defDhuhr = SR_OVERRIDE_DEFAULTS.tile_dhuhr;
    const defaultGap = defDhuhr.x - (defFajr.x + defFajr.w);
    const TOL = 0.2;

    const getBox = (id) => ({ ...(this.state.overrides[id] || SR_OVERRIDE_DEFAULTS[id]) });

    const expectedX = (index) => {
      const b = getBox(ids[index]);
      if (index > 0) {
        const prev = getBox(ids[index - 1]);
        return prev.x + prev.w + defaultGap;
      }
      if (index < ids.length - 1) {
        const next = getBox(ids[index + 1]);
        return next.x - b.w - defaultGap;
      }
      return b.x;
    };

    let onlyIds = null;
    if (this._selectedGroup.size === 1) {
      const sel = [...this._selectedGroup][0];
      if (this._isPrayerTile(sel)) onlyIds = new Set([sel]);
    }

    const needsXFix = (index) => {
      const id = ids[index];
      const b = getBox(id);
      const exp = expectedX(index);
      const xOff = Math.abs(b.x - exp) > TOL;
      if (onlyIds) return onlyIds.has(id) && xOff;
      return xOff;
    };

    for (let i = 0; i < ids.length; i++) {
      if (!needsXFix(i)) continue;
      const id = ids[i];
      const box = getBox(id);
      const cur = this.state.overrides[id] || {};
      this.state.overrides[id] = this.clampBox({
        ...cur,
        x: expectedX(i),
        y: box.y,
        w: box.w,
        h: box.h,
      });
    }

    this._clearGroupSelection();
    this._repositionPrayerTiles();
    return this.saveToServer();
  }

  /* Gleiche Zwischenräume zwischen allen 5 Kacheln in der aktuellen Reihenbreite. */
  equalizePrayerTileGaps() {
    const ids = SR_PRAYER_TILE_IDS;
    const boxes = ids.map(id => ({
      id,
      box: { ...(this.state.overrides[id] || SR_OVERRIDE_DEFAULTS[id]) },
    }));
    const left = Math.min(...boxes.map(b => b.box.x));
    const right = Math.max(...boxes.map(b => b.box.x + b.box.w));
    const totalW = boxes.reduce((s, b) => s + b.box.w, 0);
    const gap = (right - left - totalW) / (ids.length - 1);
    let x = left;
    boxes.forEach(({ id, box }) => {
      const cur = this.state.overrides[id] || {};
      this.state.overrides[id] = this.clampBox({
        ...cur,
        x, y: box.y, w: box.w, h: box.h,
      });
      x += box.w + gap;
    });
    this._clearGroupSelection();
    this._repositionPrayerTiles();
    return this.saveToServer();
  }

  rescale() {
    this.applyAllStyles();
  }

  destroy() {
    this.closeStyleEditor();
    this._clearGroupSelection();
    if (this._listenersAttached) {
      window.removeEventListener('pointermove', this._boundMove);
      window.removeEventListener('pointerup', this._boundUp);
      this._listenersAttached = false;
    }
    if (this._escGroupAttached) {
      window.removeEventListener('keydown', this._boundEsc);
      this._escGroupAttached = false;
    }
  }
}

window.StudioRenderer = StudioRenderer;
window.SR_OVERRIDE_DEFAULTS = SR_OVERRIDE_DEFAULTS;
window.SR_buildBaseOverrides = SR_buildBaseOverrides;
window.SR_baseStyleFor = SR_baseStyleFor;
window.SR_baseOverrideElement = SR_baseOverrideElement;
window.migrateSplitInfoOverrides = migrateSplitInfoOverrides;
