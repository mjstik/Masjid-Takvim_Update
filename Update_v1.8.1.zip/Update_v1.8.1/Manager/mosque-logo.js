/* ═══════════════════════════════════════════════════════════════════════════
   Moschee-Takvim · Logo (einheitliche SVG-Quelle)
   Wird von Manager, Kiosk, Design-Studio und Pi-Platzhalter verwendet.
   ═══════════════════════════════════════════════════════════════════════════ */
(function (global) {
  'use strict';

  const GOLD = '#c9a962';
  const GOLD_FILL = 'rgba(201,169,98,0.14)';

  const MOSQUE_LOGO_MARKUP = `
  <path d="M3 54h58"/>
  <path d="M8 54v-1.5h48v1.5" opacity="0.45"/>
  <path d="M9 54V30"/>
  <path d="M7 30h4"/>
  <path d="M8.5 30V26"/>
  <circle cx="8.5" cy="24.2" r="1.3" fill="${GOLD}" stroke="none"/>
  <path d="M55 54V30"/>
  <path d="M53 30h4"/>
  <path d="M54.5 30V26"/>
  <circle cx="54.5" cy="24.2" r="1.3" fill="${GOLD}" stroke="none"/>
  <path d="M15 54V42"/>
  <path d="M13 38h4"/>
  <path d="M49 54V42"/>
  <path d="M47 38h4"/>
  <path d="M15 42c0-13.5 17-26 17-26s17 12.5 17 26" fill="${GOLD_FILL}"/>
  <path d="M21 42c0-8.5 11-16.5 11-16.5s11 8 11 16.5"/>
  <path d="M26.5 54v-4.8c0-2.8 2.5-5 5.5-5s5.5 2.2 5.5 5v4.8"/>
  <path d="M32 16V9.5"/>
  <path d="M35.2 7.2C35.2 5.1 33.4 3.3 31 3c2.5.7 3.8 2.7 3.2 4.8-.4 1.6 1.3 2.6 2.8 1.8 1-.6 1.2-1.8.2-2.4" fill="${GOLD}" stroke="none"/>
  <circle cx="28.8" cy="5.8" r="0.85" fill="${GOLD}" stroke="none"/>`;

  function mosqueLogoHtml(opts) {
    opts = opts || {};
    var cls = opts.className || '';
    var sw = opts.strokeWidth != null ? opts.strokeWidth : 2.2;
    var w = opts.width;
    var h = opts.height != null ? opts.height : w;
    var size = w ? ' width="' + w + '" height="' + h + '"' : '';
    var aria = opts.ariaHidden !== false ? ' aria-hidden="true"' : '';
    return '<svg class="' + cls + '" viewBox="0 0 64 64"' + size +
      ' fill="none" stroke="' + GOLD + '" stroke-width="' + sw +
      '" stroke-linecap="round" stroke-linejoin="round"' + aria + '>' +
      MOSQUE_LOGO_MARKUP + '</svg>';
  }

  global.MOSQUE_LOGO_MARKUP = MOSQUE_LOGO_MARKUP;
  global.MOSQUE_LOGO_GOLD = GOLD;
  global.mosqueLogoHtml = mosqueLogoHtml;
})(typeof window !== 'undefined' ? window : globalThis);
